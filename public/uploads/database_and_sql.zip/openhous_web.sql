-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 21, 2023 at 04:16 AM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `openhous_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_principals`
--

CREATE TABLE `about_principals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_principals`
--

INSERT INTO `about_principals` (`id`, `name`, `designation`, `image`, `title`, `description`, `sort`, `status`, `created_at`, `updated_at`) VALUES
(3, 'FARHANA NAZRUL', 'CEO/ FOUNDEr', 'uploads/about_principal/98a1c030-fe14-11ed-8a51-525400dd40c4.jpeg', 'EDUCATIONAL BACKGROUND: BSC IN ME (KU)', '<p>Address: Eastern Panthachaya, 152/2/G-1&amp;G-2, Panthapath,&nbsp;&nbsp;Dhaka 1205</p>\r\n\r\n<p>DOB:25.11.1974</p>\r\n\r\n<p>Blood Group: B+</p>\r\n\r\n<p>Contact No: 01715109057</p>\r\n\r\n<p>Email Address:</p>', 1, 1, '2023-05-01 07:23:51', '2023-05-29 22:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `thumbs_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `description`, `thumbs_image`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, '<p>We are an architecture and engineering firm that provides a full array of services from building design and construction to interior design and all the structural, electrical, and plumbing design needs of a building.</p>\r\n\r\n<p>Our company takes pride in its commitment to customer satisfaction and our team of experienced professionals places a high value on quality work.</p>', 'uploads/about_us/thumbs/d26756c6-336c-11ee-b26b-525400dd40c4.jpg', 'uploads/about_us/d26756c6-336c-11ee-b26b-525400dd40c4.jpg', 1, '2023-07-12 06:47:00', '2023-08-05 19:48:17');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=project,2=portfolio',
  `sort` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `type`, `sort`, `name`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(11, 1, 2, 'Interior Design', 'interior-design', 1, '2023-05-10 18:48:28', '2023-05-10 18:48:28'),
(12, 1, 3, 'Construction', 'construction', 1, '2023-05-10 18:48:48', '2023-08-20 21:32:26'),
(14, 1, 1, 'Architecture', 'architecture', 1, '2023-05-10 19:06:06', '2023-05-10 19:06:06'),
(15, 1, 4, 'Under Construction', 'under-construction', 1, '2023-05-23 22:03:41', '2023-05-23 22:03:41');

-- --------------------------------------------------------

--
-- Table structure for table `client_queries`
--

CREATE TABLE `client_queries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `approx_area` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client_queries`
--

INSERT INTO `client_queries` (`id`, `name`, `email`, `mobile_no`, `service`, `location`, `approx_area`, `message`, `created_at`, `updated_at`) VALUES
(1, 'me', 'abhilklk@kjkb.com', '01309090041', '1', 'kujyfjghfjmfh', '12255', '.k,jbkjghgdsgfesaf', '2023-07-04 23:47:49', '2023-07-04 23:47:49');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_04_26_092419_create_news_table', 2),
(6, '2023_04_27_100351_create_projects_table', 3),
(7, '2023_04_27_100417_create_categories_table', 3),
(8, '2023_04_27_101046_create_project_images_table', 3),
(9, '2023_04_30_161631_create_portfolios_table', 4),
(10, '2023_05_01_113608_create_about_principals_table', 5),
(11, '2023_05_01_143933_create_team_members_table', 6),
(12, '2023_05_01_150609_create_teams_table', 6),
(13, '2023_05_01_180523_create_team_headings_table', 7),
(14, '2023_02_06_094841_create_sliders_table', 8),
(16, '2023_05_13_165217_create_services_table', 9),
(17, '2023_05_13_172736_create_testimonials_table', 10),
(18, '2023_05_30_180154_create_trackers_table', 11),
(19, '2023_07_12_122443_create_about_us_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `thumbs_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `big_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `author`, `posted_at`, `description`, `thumbs_image`, `big_image`, `status`, `created_at`, `updated_at`) VALUES
(6, 'Feature an article about our project \'KHAN BARI JAME MASJID \' in  \"SHOWCASE MAGAZINE\"', 'feature-an-article-about-our-project-\'khan-bari-jame-masjid-\'-in-\"showcase-magazine\"', NULL, '2023-09-17 21:44:00', '<p>SHOWCASE MAGAZINE featured our project KHAN BARI JAME MASJID.Click the link to read more-&nbsp; &nbsp;</p>\r\n\r\n<p><a href=\"https://www.showcase.com.bd/there-back/an-aspiring-minimal-haven/?fbclid=IwAR3-1455AfSJKrNzVxyfGNG6JW5Sa4U6jbRylmmI-pa-hxuxUbTT46ODXow\">SHOWCASE MAGAZINE</a></p>', 'uploads/news/thumbs/d4823282-554f-11ee-8db7-525400dd40c4.jpg', 'uploads/news/d4823282-554f-11ee-8db7-525400dd40c4.jpg', 1, '2023-09-17 22:46:25', '2023-09-17 22:50:31');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '2=complete',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_location_link` text COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `category_id`, `project_id`, `type`, `name`, `address`, `project_location_link`, `latitude`, `longitude`, `status`, `created_at`, `updated_at`) VALUES
(7, 14, 21, '1', 'Rim Mariya Apartment', 'PLOT 305, ROAD-9, BLOCK-l, BASHUNDHARA R/A, DHAKA', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.2178405637515!2d90.3693448144556!3d23.73960999510656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf349f34c913%3A0xd14640753649c557!2sBest%20Care%20Pharmacy!5e0!3m2!1sen!2sbd!4v1678268700540!5m2!1sen!2sbd\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 23.82515381, 90.44701934, 1, '2023-05-02 09:15:02', '2023-06-24 04:00:06'),
(8, 15, 25, NULL, 'Basupara, Bajrajugini, Munshigonj', 'Shukhbaspur road,Basupara, Bajrajugini, Munshigonj', NULL, 23.52891516, 90.48974734, 1, '2023-09-23 21:54:42', '2023-09-23 21:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `feature_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_link` varchar(555) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_location_link` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `category_id`, `name`, `description`, `feature_image`, `youtube_link`, `project_location_link`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(19, 15, 'Madinatul Ulum Kaumy Madrasha', '<p><strong>Project Name: </strong>Madinatul Ulum Kaumy Madrasha</p>\r\n\r\n<p><strong>Location: </strong>Aduar Char, Pashchim Kandy, Shibchar Upazilla, Dist: Madaripur</p>\r\n\r\n<p><strong>Client:</strong> Md. Kamrul Hasan</p>\r\n\r\n<p><strong>Area: </strong>7496.19 square ft</p>\r\n\r\n<p><strong>Year:&nbsp; </strong>2022</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>General Description:</strong></p>\r\n\r\n<p>The main idea is to create a transparent, open environment within a basic rectangular form where children can learn and relate to their surroundings in order to function in the current world.</p>\r\n\r\n<p>Only one and a half hours drive distances the madrasa from the heart of Dhaka, which is located in Aduar Char, Shibchar Upazilla. The madrasa is found adjacent to an existing mosque on the south and is encircled by a beautiful natural setting with a cemetery on the north. Users mainly enter from the east next to an open green area that serves as both an additional space for Eid Jamat and a playfield for Madrasa students. The madrasa and mosque are additionally connected via a rear entry from the south.</p>\r\n\r\n<p>Being located in a char area, this four-story madrasa is designed to maximize the amount of cross ventilation and natural light throughout the interior. In order to provide protection from the harshness of the sun, verandas are suggested on both the east and west sides. The repeated characteristics of arches that wrap the veranda from the front give the madrasa a distinctive aspect while blocking the sunlight from the east.</p>\r\n\r\n<p>Designed to be completed over a period of 24 months, the course accommodates a total of 400-500 students. Each floor of the madrasa corresponds to a distinct specific function. The ground floor consists of a kitchen, dining hall, and an administrative block on the north. The rest of the floors are equipped with the students&rsquo; classroom cum accommodation with toilet blocks on the north. To monitor the students&rsquo; with their activity, teachers&rsquo; rooms are provided next to their classrooms. On the first and second levels, respectively, there are libraries and computer labs available to help students get ready for the modern world. However, sick beds are available on the third level owing to emergencies to give the students additional attention.</p>\r\n\r\n<p>Through conducting environmentally conscious site planning, the construction system gives priority to the quality of the materials. It adopts the remarkable characteristics of the structure and provides modern, intriguing materials and finishes to cover each floor, accommodating the char climate.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>The objective of the Madrasa :</strong></p>\r\n\r\n<p>As a no profitable organization, the academic system has been adjusted to accommodate the new modern education and lifestyle program while still honoring the persisting Islamic education and culture. A progressive learning curriculum is developed, combining elements of both the conventional school and the Arabic educational systems. Students reside in the Madrassa for the duration of their course and are taught life skills, social studies, and the study of Islam, along with its applications in everyday life.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>Future provision:</strong></p>\r\n\r\n<p>The madrasa complex will be further developed according to a visionary strategy by the authority. The current site has a 75-decimal area. The area will be expanded up to 200 decimals. A separate administration building, renovation of the current mosque, primary healthcare facilities, and guest house amenities are all part of the future design.</p>\r\n\r\n<p>&nbsp;</p>', 'uploads/project/b032a132-f960-11ed-a5eb-525400dd40c4.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/82iVlcwoJdk\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>', NULL, 'madinatul-ulum-kaumy-madrasha', 1, '2023-05-23 22:45:02', '2023-06-22 13:01:36'),
(20, 14, 'KHAN BARI JAME MASJID', '<p><strong>Project Name: </strong>Khan Bari Jame Masjid</p>\r\n\r\n<p><strong>Location: </strong>Monohordi <strong>,</strong>Narashingdhi</p>\r\n\r\n<p><strong>Client:</strong> Anamul Hauqe Khan</p>\r\n\r\n<p><strong>Area: </strong>1800 square ft</p>\r\n\r\n<p><strong>Year:&nbsp; </strong>2020</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>General Description:</strong></p>\r\n\r\n<p>The Khan Bari Jame Masjid, an architectural masterpiece meticulously designed by our esteemed firm. Situated in the enchanting village of Monohordi, nestled within the Narashingdhi district, this mosque stands as a testament to our commitment to creating a harmonious bond among the village community. With a focus on providing a serene environment for prayer and congregation, the Khan Bari Jame Masjid is constructed using a full solid parabolic concrete cast, symbolizing the unbreakable unity and strength shared by the villagers. This project, situated on ancestral land in the historic Katabaria village, carries the legacy of the Khan family, who have resided here for nearly 180 years. Inspired by the commitment of the late Afazuddin Khan, a socialist and dedicated member of the political party, his son, Enamul Haque Khan, has taken up the mantle to enhance the lives of the countryside people and uplift the community.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The mosque, initially built in the 1970s as a mud structure with a thatched shed, has undergone significant development. Initiated by Enamul Haque&#39;s uncle, Lieutenant General Nuruddin Khan, the mosque was expanded and improved to better serve the needs of the community.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The Khan Bari Jame Masjid, along with the family&#39;s vacation house, has become a gathering place for family members, visitors, and community members, where laughter, hardship, grief, cultural exchange, and rituals are shared. With its concise and simplistic design language, the mosque offers a tranquil environment that provides solace for both the body and mind, allowing emotions to take root and flourish.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>The objective of the Mosque:</strong></p>\r\n\r\n<p>The objective of the Khan Bari Jame Masjid is to serve as a spiritual sanctuary and a center for community bonding and growth. The mosque aims to create an environment where individuals can stand and pray under the protection of a full solid concrete block, fostering a sense of unity and solidarity among the village people. It seeks to provide a sacred space where worshippers can connect with their faith, find solace, and cultivate a deeper spiritual connection. By offering regular congregational prayers, religious sermons, and Islamic teachings, the mosque aims to enhance the spiritual well-being of the community and strengthen their collective bond.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Furthermore, the mosque serves as a platform for fostering social cohesion, cultural exchange, and community engagement. It provides a venue for community gatherings, festivals, and celebrations, where people can come together to share their joys and sorrows, exchange ideas, and reinforce the fabric of their community. By promoting inclusivity and harmony, the mosque acts as a unifying force, bringing people of different backgrounds and beliefs together.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Future Provision:</strong></p>\r\n\r\n<p>The Khan Bari Jame Masjid has been designed with future provisions in mind, aiming to cater to the evolving needs of the community. This forward-thinking approach ensures that the mosque remains a vibrant and relevant institution for generations to come. The future provisions may include the incorporation of educational facilities and programs within the mosque premises. This could involve the establishment of a madrasa, where children and adults can receive Islamic education, Quranic studies, and teachings on Islamic values and ethics. The madrasa would serve as a valuable resource for the community, nurturing a generation that is not only knowledgeable about their faith but also equipped with the tools to lead righteous and fulfilling lives.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>You can also visit the link to see the feature article about the project in Showcase Magazine:</p>\r\n\r\n<p><a href=\"https://www.showcase.com.bd/there-back/an-aspiring-minimal-haven/?fbclid=IwAR3-1455AfSJKrNzVxyfGNG6JW5Sa4U6jbRylmmI-pa-hxuxUbTT46ODXow\">KHAN BARI JAME MASJID</a></p>\r\n\r\n<p>(NOTE: Some photos are collected from the article to feature on our website)</p>', 'uploads/project/acaa9470-fc71-11ed-af7c-525400dd40c4.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/lzUj1gL9Vjk\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>', NULL, 'khan-bari-jame-masjid', 1, '2023-05-27 20:32:07', '2023-09-17 19:48:43'),
(21, 15, 'RIM-MARIA RESIDENCE', '<p><strong>Project Name: </strong>RIM-MARIYA RESIDENCE<strong>,</strong> SIX STORIED RESIDENTIAL BUILDING</p>\r\n\r\n<p><strong>Location: </strong>PLOT 305, ROAD-9, BLOCK-l, BASHUNDHARA R/A, DHAKA</p>\r\n\r\n<p><strong>Client:</strong> F.M. MAMTAZ UDDIN &amp; MOREUM TAZNEN RIME</p>\r\n\r\n<p><strong>Area: </strong>2143.60 sqm</p>\r\n\r\n<p><strong>Year:&nbsp; </strong>2022</p>\r\n\r\n<p><strong>General Description:</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Welcome to the Rim-Mariya Residence, a six-storied residential building designed by our esteemed architectural firm. Situated in the prestigious Bashundhara Residential Area of Dhaka, the building stands as a testament to modernity, comfort, and elegance. With a focus on incorporating the clients&#39; desires for glass, nature, purity, and light, the design of this project seamlessly blends architectural beauty with functionality.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The Rim-Mariya Residence boasts a rooftop swimming pool, providing a serene oasis of relaxation for the residents. As we understand the allure of Bashundhara R/A, Dhaka as the future face of the city, our clients dreamt of owning an apartment in this prestigious area. When they approached us for consultancy, they knew that our design would bring their vision to life, creating a perfect projection of their thoughts and aspirations.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Each floor of the building has been meticulously designed to meet the specific criteria outlined by our clients. Different functions and layouts have been incorporated on each floor, ensuring a diverse range of living spaces tailored to their unique requirements. The third and fourth floors offer a duplex arrangement, adding a touch of luxury and versatility to the overall design.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>One of the standout features of the Rim-Mariya Residence is the spacious swimming pool, capable of accommodating up to 50 people. Positioned on the rooftop, it offers breathtaking views that mesmerize all who visit. The building is a true embodiment of modernity, featuring advanced interior technologies that enhance the residents&#39; comfort and convenience.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The exterior design of the Rim-Mariya Residence showcases a harmonious blend of materials. The combination of fair-face concrete and front-facing glass panels creates a striking visual contrast, representing the fusion of modern and contemporary architectural styles. This aesthetic choice not only adds to the building&#39;s allure but also symbolizes the purity and elegance of its design.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Objective of the Building:</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The primary objective of the Rim-Mariya Residence is to create a luxurious and comfortable living space that surpasses the expectations of our clients. Every aspect of the design, from the choice of materials to the layout of each floor, has been carefully considered to ensure the utmost satisfaction of our esteemed clients.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The building aims to provide a harmonious living environment where residents can immerse themselves in the beauty of nature, bask in natural light, and experience a sense of serenity. The seamless integration of glass elements allows for ample daylight penetration, creating a vibrant and uplifting ambiance throughout the building. This design choice not only enhances the visual appeal but also promotes a connection with the surrounding natural landscape.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Client Satisfaction:</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>At our architectural firm, client satisfaction is our utmost priority. We understand that a residential building is not just a structure but a place where individuals and families create lasting memories. Therefore, we have worked closely with F.M. Mamtaz Uddin and Moreum Taznen Rime, the esteemed clients of the Rim-Mariya Residence, to ensure that their desires and aspirations have been met.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>From the initial consultation to the final stages of construction, our team has strived to incorporate the clients&#39; vision and preferences into the design. We have taken great care to listen to their needs, understand their lifestyle, and translate their dreams into a tangible reality. By combining our expertise with their aspirations, we have created a residence that not only meets their expectations but also surpasses them.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Throughout the design and construction process, we have maintained open and transparent communication with our clients, providing regular updates and seeking their input at every stage. Their satisfaction and happiness with the end result are the ultimate measures of our success.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>In conclusion, the Rim-Mariya Residence stands as a testament to our commitment to creating architectural masterpieces that reflect the desires and aspirations of our esteemed clients. With its blend of modernity, comfort, and elegance, this six-storied residential building is a true manifestation of our client&#39;s dreams and our unwavering dedication to their satisfaction.</p>', 'uploads/project/a5548516-2c62-11ee-9360-525400dd40c4.jpg', '<iframe width=\"560\" height=\"315\"src=\"https://www.youtube.com/embed/6tGCnkqUFqs\" title=\"RIM-MARIA RESIDENCE | Bashundhara R/A | 3d Animation | OPENHOUSE ARCHITECTS &amp; ENGINEERS\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3649.8177155171807!2d90.44444977605976!3d23.825080185903857!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7010568fe57%3A0x9256e5df36074a90!2sRim%20Mariya%20Apartment!5e0!3m2!1sen!2sbd!4v1692683672793!5m2!1sen!2sbd\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'rim-maria-residence', 1, '2023-05-27 23:05:11', '2023-08-22 16:54:48'),
(22, 14, 'INFINITY JENNIFER', '<p>PROJECT NAME: PROPOSED NINE (G+8) STORIED RESIDENTIAL &nbsp;APARTMENT BUILDING&nbsp;<br />\r\nPROJECT LOCATION: PLOT NO. # 392, &nbsp;SAVAR DOHS, DHAKA<br />\r\nLAND AREA: 3600 SFT ( 05 KATHA )<br />\r\nDEVELOPER&rsquo;S NAME : INFINITY ENGINEERING LIMITED&nbsp;<br />\r\nBUILDING VIEW: NORTH AND EAST FACING&nbsp;<br />\r\nDEVELOPMENT PLAN: ( G+8) NINE STORIED<br />\r\nFLAT TYPE: SINGLE AND DOUBLE UNIT</p>\r\n\r\n<p>TOTAL FLAT: 14 NOS&nbsp;<br />\r\nTOTAL PARKING: 10 NOS&nbsp;<br />\r\nOWNERS NAME : COMMANDER MD. ENAMUL HAQUE BN (RETD)<br />\r\n2700 sft<br />\r\nCONSULTANT : OPEN HOUSE ARCHITECTS &amp; ENGINEERS</p>', 'uploads/project/c720f6dc-2c5f-11ee-96d7-525400dd40c4.jpg', NULL, NULL, 'infinity-jennifer', 1, '2023-07-27 20:27:17', '2023-09-17 19:47:43'),
(23, 14, '(EIGHT) STORIED RESIDENTIAL BUILDING DESIGN FOR AMINUL HAIDER', '<p>ROJECT LOCATION: PLOT NO. # 340, &nbsp;ROAD NO: 14,&nbsp; BARIDHARA&nbsp;DOHS, DHAKA</p>\r\n\r\n<p>LAND AREA: 3600 SFT ( 05 KATHA )</p>\r\n\r\n<p>BUILDING VIEW: SOUTH AND EAST FACING&nbsp;</p>\r\n\r\n<p>DEVELOPMENT PLAN: ( G+8) NINE STORIED WITH &nbsp;(01) NOS BASEMENT</p>\r\n\r\n<p>FLAT TYPE: SINGLE AND DOUBLE UNIT<br />\r\n&nbsp;<br />\r\nTOTAL FLAT: 13 NOS&nbsp;</p>\r\n\r\n<p>TOTAL PARKING: 16 NOS&nbsp;<br />\r\n&nbsp;</p>', 'uploads/project/f80c2b8e-2c61-11ee-8126-525400dd40c4.jpg', NULL, NULL, '(eight)-storied-residential-building-design-for-aminul-haider', 1, '2023-07-27 20:42:58', '2023-09-19 22:01:59'),
(24, 11, 'RAJON GHOSH FLAT INTERIOR AT GLOD HOUSE', '<p>Rajon Ghosh Flat Interior at Gold House</p>', 'uploads/project/effe35f2-2ea7-11ee-85cd-525400dd40c4.jpeg', NULL, NULL, 'rajon-ghosh-flat-interior-at-glod-house', 1, '2023-07-30 18:08:52', '2023-09-17 19:50:11'),
(25, 15, 'BASUPARA TAKUA JAME MASJID', '<p>Project Name:Basupara Takua Jame Masjid</p>\r\n\r\n<p>Location: Basupara, Bajrajugini, Munshigonj</p>\r\n\r\n<p><strong>Area: 6700</strong>&nbsp;square ft</p>\r\n\r\n<p>Development Plan: 2-storied mosque with four&nbsp;domes.</p>\r\n\r\n<p><strong>General Description:</strong></p>\r\n\r\n<p>The construction of the mosque is presently underway in the serene and aesthetically appealing neighborhood of Basupara, Munshiganj. The project holds special significance for our client, as Basupara is his place of birth. This locality bears historical significance, with numerous ancient Bouddho mandirs and a Bouddho bihar ,Mosque coexisting alongside the ongoing construction of modern mosques. Our client has embarked on this endeavor as his mother asked, as she has a long-awaited dream in her mind to build a mosque in her native village.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The selected location for this mosque is indeed idyllic. At the forefront of the structure, one can discern the presence of three relatively smaller domes, while the central dome, a commanding feature, rises to an impressive height of 43 feet and spans 30 feet in diameter. This central dome stands as a monumental centerpiece, eclipsing the stature of the entire edifice. Flanking the north-south axis of the mosque are imposing minarets, meticulously designed to soar to a remarkable height of 100 feet. These minarets have been thoughtfully constructed to ensure that the call to prayer (adhan) resonates across a significant distance, reaching the ears of congregants far and wide.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The mosque&#39;s architectural style is characterized by a deliberate simplicity that does not compromise functionality. Exclusive provisions have been made for women, with their entrance situated along the southern facade, granting access to a designated area for ablution and prayer. The main entrance gate, a striking feature in its own right, spans an impressive width of approximately 20 feet. Ascending to the upper floor of the mosque reveals the Imam&#39;s residence, signifying the spiritual heart of the mosque.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Beyond the entrance gate lies a spacious hall designed to accommodate approximately 70 worshipers, fostering a sense of community and devotion. The mosque, in its entirety, possesses a capacity to host up to 500 individuals simultaneously. Strategically positioned large windows along the north-south axis ensure optimal airflow within the prayer space. The mosque&#39;s color palette and architectural elements purposefully evoke the classical Mughal architectural style, paying homage to the rich historical heritage of this revered site.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>An innovative running brick bond design graces the exterior wall of the mosque, while a pristine white hue adorns the gates, domes, and minarets, collectively imbuing the structure with a charming vintage aesthetic. In a deliberate nod to the rustic locale in which the mosque is situated, the decision has been made to retain the natural dark brown color of the bricks, eschewing the use of plaster or tiles.</p>\r\n\r\n<p>&nbsp;</p>', 'uploads/project/e61aa8f2-3908-11ee-a1cf-525400dd40c4.jpg', NULL, '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3658.1072709174546!2d90.49001980561788!3d23.52864390470779!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755afdaee52e5d3%3A0x482f6078895828f8!2sBasupara%20Takua%20Jame%20Masjid!5e0!3m2!1sen!2sbd!4v1694941950716!5m2!1sen!2sbd\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'basupara-takua-jame-masjid', 1, '2023-08-12 23:08:08', '2023-10-06 21:39:46'),
(26, 14, 'CHITTAGONG 4 STORIED APARTMENT BUILDING', '<p>Chittagong 4&nbsp;Storied Apartment Building&nbsp;</p>', 'uploads/project/ca5570c4-3909-11ee-9a3e-525400dd40c4.jpg', NULL, NULL, 'chittagong-4-storied-apartment-building', 1, '2023-08-12 23:14:31', '2023-09-17 19:54:09'),
(27, 14, 'PARASH KUTHIR AT SAVAR DOHS', '<p>Project Name: Parash Kuthir</p>\r\n\r\n<p>Location: Savar DOHS</p>\r\n\r\n<p>Client: Infinity<br />\r\n&nbsp;</p>', 'uploads/project/d5bedb42-390b-11ee-a7ff-525400dd40c4.jpg', NULL, NULL, 'parash-kuthir-at-savar-dohs', 1, '2023-08-12 23:29:09', '2023-09-17 19:55:43'),
(28, 14, 'SAVAR NOMAN PROJECT', '<p>Project Name: Savar Noman Project</p>\r\n\r\n<p>Location: Savar DOHS</p>', 'uploads/project/c7fa1848-399f-11ee-b65d-525400dd40c4.jpg', NULL, NULL, 'savar-noman-project', 1, '2023-08-13 17:08:11', '2023-09-17 19:56:30'),
(29, 11, 'UDDL OFFICE INTERIOR FOR MANAGING DIRECTOR', '<p>Project Name:&nbsp;UDDL OFFICE INTERIOR FOR MANAGING DIRECTOR<br />\r\nLocation Dhanmondi</p>', 'uploads/project/f8605e82-39a1-11ee-b2f7-525400dd40c4.jpg', NULL, NULL, 'uddl-office-interior-for-managing-director', 1, '2023-08-13 17:23:51', '2023-08-13 17:23:51'),
(30, 14, 'ATMAJA BHABAN', '<p>Project Name:&nbsp;Atmaja Bhaban</p>\r\n\r\n<p>Location: Location</p>', 'uploads/project/cfd7ecde-39c2-11ee-86bd-525400dd40c4.jpg', NULL, NULL, 'atmaja-bhaban', 1, '2023-08-13 21:18:57', '2023-09-17 19:57:08'),
(31, 14, 'FOUR STORIED RESIDENTIAL BUILDING', '<p>PROJECT :FOUR STORIED RESIDENTIAL BUILDING</p>\r\n\r\n<p>LOCATION: MAGURA</p>', 'uploads/project/b4e82af4-5229-11ee-bdcc-525400dd40c4.jpg', NULL, NULL, 'four-storied-residential-building', 1, '2023-09-13 22:35:57', '2023-09-13 22:35:57'),
(32, 11, 'INTERIOR DESIGN FOR SANANDA DIAMONDS(PVT.) LTD.', '<p>Project-&nbsp;Interior design for &nbsp;sananda diamonds (Pvt.) Ltd.</p>', 'uploads/project/bb645838-522b-11ee-a13b-525400dd40c4.jpg', NULL, 'Baitul Mukaram Gold Market.', 'interior-design-for-sananda-diamonds(pvt.)-ltd.', 1, '2023-09-13 22:50:27', '2023-09-17 19:58:50'),
(33, 11, 'TOILET INTERIOR', '<p>Project-&nbsp;TOILET INTERIOR</p>', 'uploads/project/ad6e77c8-52ed-11ee-8abf-525400dd40c4.jpg', NULL, NULL, 'toilet-interior', 1, '2023-09-14 21:58:46', '2023-09-14 21:58:46'),
(34, 12, 'A SCHOOL BUILDING  IN CUMILLA', '<p>Project:&nbsp;UNDER CONSTRUCTION SCHOOL BUILDING ,CUMILLA.</p>', 'uploads/project/44ac76e4-52ee-11ee-8de0-525400dd40c4.jpg', NULL, NULL, 'a-school-building-in-cumilla', 1, '2023-09-14 22:03:00', '2023-09-14 22:03:00'),
(35, 11, 'PERSPECTIVE VIEW OF CLIENT\'S MEETING ROOM FOR AN REPUTED DEVELOPER\'S OFFICE', '<p>Project:&nbsp;&nbsp;CLIENT&#39;S MEETING ROOM FOR AN REPUTED DEVELOPER&#39;S OFFICE</p>', 'uploads/project/d2889f60-52ee-11ee-9981-525400dd40c4.jpg', NULL, NULL, 'perspective-view-of-client\'s-meeting-room-for-an-reputed-developer\'s-office', 1, '2023-09-14 22:06:58', '2023-09-14 22:06:58'),
(36, 11, 'BEDROOM DESIGN PERSPECTIVE RENDERING', '<p>Project:&nbsp;BEDROOM DESIGN PERSPECTIVE RENDERING</p>', 'uploads/project/5056c796-52ef-11ee-abcc-525400dd40c4.jpg', NULL, NULL, 'bedroom-design-perspective-rendering', 1, '2023-09-14 22:10:29', '2023-09-14 22:10:29'),
(37, 11, 'SANGSHAPTAK INTERIOR DESIGN', '<p>Project:&nbsp;SANGSHAPTAK INTERIOR DESIGN&nbsp;</p>', 'uploads/project/3bddb80a-52f0-11ee-a3b7-525400dd40c4.jpg', NULL, NULL, 'sangshaptak-interior-design', 1, '2023-09-14 22:17:04', '2023-09-14 22:17:04'),
(38, 11, 'ZEBA INTERIOR DESIGN', '<p>Project:&nbsp;ZEBA INTERIOR DESIGN&nbsp;</p>', 'uploads/project/c6974404-52f3-11ee-8f59-525400dd40c4.jpg', NULL, NULL, 'zeba-interior-design', 1, '2023-09-14 22:42:25', '2023-09-14 22:42:25'),
(39, 11, 'BIRDCAGE DESIGN', '<p>Project:&nbsp;BIRDCAGE DESIGN PERSPECTIVE RENDER</p>', 'uploads/project/bbbaf8e0-52f4-11ee-a432-525400dd40c4.jpg', NULL, NULL, 'birdcage-design', 1, '2023-09-14 22:49:17', '2023-09-14 22:49:17');

-- --------------------------------------------------------

--
-- Table structure for table `project_images`
--

CREATE TABLE `project_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbs_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `big_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_images`
--

INSERT INTO `project_images` (`id`, `project_id`, `sort`, `path`, `thumbs_image`, `big_image`, `created_at`, `updated_at`) VALUES
(13, 8, 1, 'uploads/project_image/54481c20-e8e0-11ed-82bb-847beb205fc8.jpg', 'uploads/project_image/thumbs/578ce26c-e8e0-11ed-b977-847beb205fc8.jpg', 'uploads/project_image/54481c20-e8e0-11ed-82bb-847beb205fc8.jpg', '2023-05-02 11:56:10', '2023-05-02 11:56:15'),
(14, 8, 2, 'uploads/project_image/54481c20-e8e0-11ed-a027-847beb205fc8.jpg', 'uploads/project_image/thumbs/579cee0a-e8e0-11ed-aa8d-847beb205fc8.jpg', 'uploads/project_image/54481c20-e8e0-11ed-a027-847beb205fc8.jpg', '2023-05-02 11:56:10', '2023-05-02 11:56:15'),
(15, 8, 3, 'uploads/project_image/5489be1e-e8e0-11ed-a672-847beb205fc8.jpg', 'uploads/project_image/thumbs/57ad0b3c-e8e0-11ed-8931-847beb205fc8.jpg', 'uploads/project_image/5489be1e-e8e0-11ed-a672-847beb205fc8.jpg', '2023-05-02 11:56:10', '2023-05-02 11:56:16'),
(16, 9, 1, 'uploads/project_image/9fc4e6a2-e8e9-11ed-beef-847beb205fc8.jpeg', 'uploads/project_image/thumbs/a349df6c-e8e9-11ed-878c-847beb205fc8.jpeg', 'uploads/project_image/9fc4e6a2-e8e9-11ed-beef-847beb205fc8.jpeg', '2023-05-02 13:02:42', '2023-05-02 13:02:48'),
(17, 9, 2, 'uploads/project_image/9fc51fdc-e8e9-11ed-a09d-847beb205fc8.jpg', 'uploads/project_image/thumbs/a38d0fda-e8e9-11ed-be7c-847beb205fc8.jpg', 'uploads/project_image/9fc51fdc-e8e9-11ed-a09d-847beb205fc8.jpg', '2023-05-02 13:02:42', '2023-05-02 13:02:48'),
(18, NULL, NULL, 'uploads/project_image/e1ebec6a-e966-11ed-9fb1-ace2d39a9428.jpg', NULL, 'uploads/project_image/e1ebec6a-e966-11ed-9fb1-ace2d39a9428.jpg', '2023-05-03 03:59:20', '2023-05-03 03:59:20'),
(19, NULL, NULL, 'uploads/project_image/e1ebed50-e966-11ed-9a47-ace2d39a9428.jpg', NULL, 'uploads/project_image/e1ebed50-e966-11ed-9a47-ace2d39a9428.jpg', '2023-05-03 03:59:20', '2023-05-03 03:59:20'),
(20, NULL, NULL, 'uploads/project_image/e1ee3952-e966-11ed-8799-ace2d39a9428.png', NULL, 'uploads/project_image/e1ee3952-e966-11ed-8799-ace2d39a9428.png', '2023-05-03 03:59:20', '2023-05-03 03:59:20'),
(21, NULL, NULL, 'uploads/project_image/e1ee379a-e966-11ed-8de5-ace2d39a9428.png', NULL, 'uploads/project_image/e1ee379a-e966-11ed-8de5-ace2d39a9428.png', '2023-05-03 03:59:20', '2023-05-03 03:59:20'),
(22, NULL, NULL, 'uploads/project_image/ea851220-e966-11ed-b4f6-ace2d39a9428.jpeg', NULL, 'uploads/project_image/ea851220-e966-11ed-b4f6-ace2d39a9428.jpeg', '2023-05-03 03:59:34', '2023-05-03 03:59:34'),
(23, NULL, NULL, 'uploads/project_image/bc1b3aa4-f177-11ed-93dd-ace2d39a9428.jpg', NULL, 'uploads/project_image/bc1b3aa4-f177-11ed-93dd-ace2d39a9428.jpg', '2023-05-13 10:20:07', '2023-05-13 10:20:07'),
(24, NULL, NULL, 'uploads/project_image/bc1b377a-f177-11ed-9a5a-ace2d39a9428.jpg', NULL, 'uploads/project_image/bc1b377a-f177-11ed-9a5a-ace2d39a9428.jpg', '2023-05-13 10:20:07', '2023-05-13 10:20:07'),
(25, NULL, NULL, 'uploads/project_image/bc1b37ac-f177-11ed-9ea7-ace2d39a9428.jpg', NULL, 'uploads/project_image/bc1b37ac-f177-11ed-9ea7-ace2d39a9428.jpg', '2023-05-13 10:20:07', '2023-05-13 10:20:07'),
(26, NULL, NULL, 'uploads/project_image/bc1b3874-f177-11ed-9860-ace2d39a9428.jpg', NULL, 'uploads/project_image/bc1b3874-f177-11ed-9860-ace2d39a9428.jpg', '2023-05-13 10:20:07', '2023-05-13 10:20:07'),
(27, NULL, NULL, 'uploads/project_image/fd61f660-f177-11ed-84b0-ace2d39a9428.jpg', NULL, 'uploads/project_image/fd61f660-f177-11ed-84b0-ace2d39a9428.jpg', '2023-05-13 10:21:57', '2023-05-13 10:21:57'),
(28, NULL, NULL, 'uploads/project_image/fd61f3fe-f177-11ed-9310-ace2d39a9428.jpg', NULL, 'uploads/project_image/fd61f3fe-f177-11ed-9310-ace2d39a9428.jpg', '2023-05-13 10:21:57', '2023-05-13 10:21:57'),
(29, NULL, NULL, 'uploads/project_image/fd642e6c-f177-11ed-ae7f-ace2d39a9428.jpg', NULL, 'uploads/project_image/fd642e6c-f177-11ed-ae7f-ace2d39a9428.jpg', '2023-05-13 10:21:57', '2023-05-13 10:21:57'),
(30, NULL, NULL, 'uploads/project_image/26082bde-f178-11ed-a2ff-ace2d39a9428.jpg', NULL, 'uploads/project_image/26082bde-f178-11ed-a2ff-ace2d39a9428.jpg', '2023-05-13 10:23:05', '2023-05-13 10:23:05'),
(31, NULL, NULL, 'uploads/project_image/2611520e-f178-11ed-9393-ace2d39a9428.jpg', NULL, 'uploads/project_image/2611520e-f178-11ed-9393-ace2d39a9428.jpg', '2023-05-13 10:23:05', '2023-05-13 10:23:05'),
(32, NULL, NULL, 'uploads/project_image/2611520e-f178-11ed-9bc5-ace2d39a9428.jpg', NULL, 'uploads/project_image/2611520e-f178-11ed-9bc5-ace2d39a9428.jpg', '2023-05-13 10:23:05', '2023-05-13 10:23:05'),
(33, 17, 1, 'uploads/project_image/8261fffe-f178-11ed-b3b1-ace2d39a9428.png', 'uploads/project_image/thumbs/c5ee3184-f178-11ed-8ab1-ace2d39a9428.png', 'uploads/project_image/8261fffe-f178-11ed-b3b1-ace2d39a9428.png', '2023-05-13 10:25:40', '2023-05-13 10:27:33'),
(34, 17, 2, 'uploads/project_image/8262012a-f178-11ed-a71a-ace2d39a9428.png', 'uploads/project_image/thumbs/c601bc90-f178-11ed-80b1-ace2d39a9428.png', 'uploads/project_image/8262012a-f178-11ed-a71a-ace2d39a9428.png', '2023-05-13 10:25:40', '2023-05-13 10:27:33'),
(35, 17, 3, 'uploads/project_image/826a5320-f178-11ed-9f5e-ace2d39a9428.png', 'uploads/project_image/thumbs/c615e242-f178-11ed-8d33-ace2d39a9428.png', 'uploads/project_image/826a5320-f178-11ed-9f5e-ace2d39a9428.png', '2023-05-13 10:25:40', '2023-05-13 10:27:34'),
(36, 17, 4, 'uploads/project_image/f324edb8-f179-11ed-82ab-ace2d39a9428.png', 'uploads/project_image/thumbs/a3962432-f17a-11ed-a97a-ace2d39a9428.png', 'uploads/project_image/f324edb8-f179-11ed-82ab-ace2d39a9428.png', '2023-05-13 10:35:59', '2023-05-13 10:40:55'),
(37, 18, 1, 'uploads/project_image/4912461c-f229-11ed-a4bf-525400dd40c4.jpg', 'uploads/project_image/thumbs/5435078c-f229-11ed-9b94-525400dd40c4.jpg', 'uploads/project_image/4912461c-f229-11ed-a4bf-525400dd40c4.jpg', '2023-05-14 18:31:05', '2023-05-14 18:31:23'),
(38, 18, 2, 'uploads/project_image/495d490a-f229-11ed-8a46-525400dd40c4.jpg', 'uploads/project_image/thumbs/543a4ea4-f229-11ed-a55f-525400dd40c4.jpg', 'uploads/project_image/495d490a-f229-11ed-8a46-525400dd40c4.jpg', '2023-05-14 18:31:05', '2023-05-14 18:31:23'),
(39, 18, 3, 'uploads/project_image/4fa2c1f0-f229-11ed-8b18-525400dd40c4.jpg', 'uploads/project_image/thumbs/5441ebb4-f229-11ed-a717-525400dd40c4.jpg', 'uploads/project_image/4fa2c1f0-f229-11ed-8b18-525400dd40c4.jpg', '2023-05-14 18:31:16', '2023-05-14 18:31:23'),
(40, 18, 4, 'uploads/project_image/51b68c1a-f229-11ed-94f4-525400dd40c4.jpg', 'uploads/project_image/thumbs/5445fede-f229-11ed-8a43-525400dd40c4.jpg', 'uploads/project_image/51b68c1a-f229-11ed-94f4-525400dd40c4.jpg', '2023-05-14 18:31:19', '2023-05-14 18:31:24'),
(41, 19, 2, 'uploads/project_image/f07d919a-f95e-11ed-b29d-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc34d17a-feb1-11ed-8429-525400dd40c4.jpg', 'uploads/project_image/f07d919a-f95e-11ed-b29d-525400dd40c4.jpg', '2023-05-23 22:42:47', '2023-05-30 17:18:04'),
(42, 19, 1, 'uploads/project_image/f07d91c2-f95e-11ed-888a-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc1cae06-feb1-11ed-af73-525400dd40c4.jpg', 'uploads/project_image/f07d91c2-f95e-11ed-888a-525400dd40c4.jpg', '2023-05-23 22:42:47', '2023-05-30 17:18:03'),
(43, 19, 3, 'uploads/project_image/f091ccfa-f95e-11ed-aa49-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc4e1cde-feb1-11ed-8d20-525400dd40c4.jpg', 'uploads/project_image/f091ccfa-f95e-11ed-aa49-525400dd40c4.jpg', '2023-05-23 22:42:47', '2023-05-30 17:18:04'),
(44, 19, 4, 'uploads/project_image/f0925c88-f95e-11ed-843d-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc66b62c-feb1-11ed-8308-525400dd40c4.jpg', 'uploads/project_image/f0925c88-f95e-11ed-843d-525400dd40c4.jpg', '2023-05-23 22:42:47', '2023-05-30 17:18:04'),
(45, 19, 5, 'uploads/project_image/fb323e2e-f95e-11ed-b4b1-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc7e9454-feb1-11ed-bb55-525400dd40c4.jpg', 'uploads/project_image/fb323e2e-f95e-11ed-b4b1-525400dd40c4.jpg', '2023-05-23 22:43:05', '2023-05-30 17:18:04'),
(47, 19, 6, 'uploads/project_image/fbbbafe2-f95e-11ed-a2c9-525400dd40c4.jpg', 'uploads/project_image/thumbs/bc96892e-feb1-11ed-9097-525400dd40c4.jpg', 'uploads/project_image/fbbbafe2-f95e-11ed-a2c9-525400dd40c4.jpg', '2023-05-23 22:43:06', '2023-05-30 17:18:04'),
(49, 19, 7, 'uploads/project_image/fe2e3aa6-f95e-11ed-bdee-525400dd40c4.jpg', 'uploads/project_image/thumbs/bcac849a-feb1-11ed-ae7f-525400dd40c4.jpg', 'uploads/project_image/fe2e3aa6-f95e-11ed-bdee-525400dd40c4.jpg', '2023-05-23 22:43:10', '2023-05-30 17:18:04'),
(50, NULL, NULL, 'uploads/project_image/35f5dd4e-fa14-11ed-ac63-525400dd40c4.jpg', NULL, 'uploads/project_image/35f5dd4e-fa14-11ed-ac63-525400dd40c4.jpg', '2023-05-24 20:20:23', '2023-05-24 20:20:23'),
(51, NULL, NULL, 'uploads/project_image/40428342-fa14-11ed-a45c-525400dd40c4.jpg', NULL, 'uploads/project_image/40428342-fa14-11ed-a45c-525400dd40c4.jpg', '2023-05-24 20:20:40', '2023-05-24 20:20:40'),
(74, NULL, NULL, 'uploads/project_image/1e574392-feb2-11ed-8892-525400dd40c4.jpg', NULL, 'uploads/project_image/1e574392-feb2-11ed-8892-525400dd40c4.jpg', '2023-05-30 17:20:48', '2023-05-30 17:20:48'),
(79, NULL, NULL, 'uploads/project_image/344e0396-1b2e-11ee-b76e-525400dd40c4.jpg', NULL, 'uploads/project_image/344e0396-1b2e-11ee-b76e-525400dd40c4.jpg', '2023-07-05 23:19:35', '2023-07-05 23:19:35'),
(80, NULL, NULL, 'uploads/project_image/cb9b6720-1b2e-11ee-91b8-525400dd40c4.jpg', NULL, 'uploads/project_image/cb9b6720-1b2e-11ee-91b8-525400dd40c4.jpg', '2023-07-05 23:23:49', '2023-07-05 23:23:49'),
(81, NULL, NULL, 'uploads/project_image/cc09e916-1b2e-11ee-b661-525400dd40c4.jpg', NULL, 'uploads/project_image/cc09e916-1b2e-11ee-b661-525400dd40c4.jpg', '2023-07-05 23:23:50', '2023-07-05 23:23:50'),
(82, NULL, NULL, 'uploads/project_image/ce877d52-1b2e-11ee-bdf0-525400dd40c4.jpg', NULL, 'uploads/project_image/ce877d52-1b2e-11ee-bdf0-525400dd40c4.jpg', '2023-07-05 23:23:54', '2023-07-05 23:23:54'),
(83, NULL, NULL, 'uploads/project_image/d7070fc4-1b2e-11ee-a452-525400dd40c4.jpg', NULL, 'uploads/project_image/d7070fc4-1b2e-11ee-a452-525400dd40c4.jpg', '2023-07-05 23:24:08', '2023-07-05 23:24:08'),
(93, NULL, NULL, 'uploads/project_image/78a4901e-2c81-11ee-8cac-525400dd40c4.jpg', NULL, 'uploads/project_image/78a4901e-2c81-11ee-8cac-525400dd40c4.jpg', '2023-07-28 00:28:28', '2023-07-28 00:28:28'),
(94, NULL, NULL, 'uploads/project_image/78a496c2-2c81-11ee-98ff-525400dd40c4.jpg', NULL, 'uploads/project_image/78a496c2-2c81-11ee-98ff-525400dd40c4.jpg', '2023-07-28 00:28:28', '2023-07-28 00:28:28'),
(95, NULL, NULL, 'uploads/project_image/78a4a1ee-2c81-11ee-b840-525400dd40c4.jpg', NULL, 'uploads/project_image/78a4a1ee-2c81-11ee-b840-525400dd40c4.jpg', '2023-07-28 00:28:28', '2023-07-28 00:28:28'),
(96, NULL, NULL, 'uploads/project_image/78ac12da-2c81-11ee-80e2-525400dd40c4.jpg', NULL, 'uploads/project_image/78ac12da-2c81-11ee-80e2-525400dd40c4.jpg', '2023-07-28 00:28:28', '2023-07-28 00:28:28'),
(97, 24, 1, 'uploads/project_image/89ee2674-2ea6-11ee-b34b-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f09ce918-2ea7-11ee-b965-525400dd40c4.jpeg', 'uploads/project_image/89ee2674-2ea6-11ee-b34b-525400dd40c4.jpeg', '2023-07-30 17:58:51', '2023-07-30 18:08:53'),
(98, 24, 2, 'uploads/project_image/8cd3c448-2ea6-11ee-8e3e-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f0e39368-2ea7-11ee-a441-525400dd40c4.jpeg', 'uploads/project_image/8cd3c448-2ea6-11ee-8e3e-525400dd40c4.jpeg', '2023-07-30 17:58:56', '2023-07-30 18:08:53'),
(99, 24, 3, 'uploads/project_image/8dbfa566-2ea6-11ee-8ecb-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f1399af6-2ea7-11ee-86f4-525400dd40c4.jpeg', 'uploads/project_image/8dbfa566-2ea6-11ee-8ecb-525400dd40c4.jpeg', '2023-07-30 17:58:57', '2023-07-30 18:08:54'),
(100, 24, 4, 'uploads/project_image/91cf91f2-2ea6-11ee-8aa4-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f185ac16-2ea7-11ee-88ec-525400dd40c4.jpeg', 'uploads/project_image/91cf91f2-2ea6-11ee-8aa4-525400dd40c4.jpeg', '2023-07-30 17:59:04', '2023-07-30 18:08:54'),
(101, 24, 5, 'uploads/project_image/9586df8a-2ea6-11ee-9aff-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f1d68faa-2ea7-11ee-b64b-525400dd40c4.jpeg', 'uploads/project_image/9586df8a-2ea6-11ee-9aff-525400dd40c4.jpeg', '2023-07-30 17:59:10', '2023-07-30 18:08:55'),
(102, 24, 6, 'uploads/project_image/98298c74-2ea6-11ee-8cfa-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f23dfbae-2ea7-11ee-b8ee-525400dd40c4.jpeg', 'uploads/project_image/98298c74-2ea6-11ee-8cfa-525400dd40c4.jpeg', '2023-07-30 17:59:15', '2023-07-30 18:08:55'),
(103, 24, 7, 'uploads/project_image/99f5da8a-2ea6-11ee-8d55-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f29716a8-2ea7-11ee-84bd-525400dd40c4.jpeg', 'uploads/project_image/99f5da8a-2ea6-11ee-8d55-525400dd40c4.jpeg', '2023-07-30 17:59:18', '2023-07-30 18:08:56'),
(104, 24, 8, 'uploads/project_image/9c2d5a26-2ea6-11ee-aa9c-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f2e667ee-2ea7-11ee-a3dc-525400dd40c4.jpeg', 'uploads/project_image/9c2d5a26-2ea6-11ee-aa9c-525400dd40c4.jpeg', '2023-07-30 17:59:22', '2023-07-30 18:08:57'),
(105, 24, 9, 'uploads/project_image/9c8104aa-2ea6-11ee-835b-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f3387700-2ea7-11ee-a445-525400dd40c4.jpeg', 'uploads/project_image/9c8104aa-2ea6-11ee-835b-525400dd40c4.jpeg', '2023-07-30 17:59:22', '2023-07-30 18:08:57'),
(106, 24, 10, 'uploads/project_image/9fd79dbc-2ea6-11ee-a37b-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f3a42f86-2ea7-11ee-9c33-525400dd40c4.jpeg', 'uploads/project_image/9fd79dbc-2ea6-11ee-a37b-525400dd40c4.jpeg', '2023-07-30 17:59:28', '2023-07-30 18:08:58'),
(107, 24, 11, 'uploads/project_image/a0896998-2ea6-11ee-8abe-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f3fc8eba-2ea7-11ee-9451-525400dd40c4.jpeg', 'uploads/project_image/a0896998-2ea6-11ee-8abe-525400dd40c4.jpeg', '2023-07-30 17:59:29', '2023-07-30 18:08:58'),
(108, 24, 12, 'uploads/project_image/a08ae6ce-2ea6-11ee-a368-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f456c182-2ea7-11ee-b74f-525400dd40c4.jpeg', 'uploads/project_image/a08ae6ce-2ea6-11ee-a368-525400dd40c4.jpeg', '2023-07-30 17:59:29', '2023-07-30 18:08:59'),
(109, 24, 13, 'uploads/project_image/a3dc098e-2ea6-11ee-b2e9-525400dd40c4.jpeg', 'uploads/project_image/thumbs/f4beb0d0-2ea7-11ee-832e-525400dd40c4.jpeg', 'uploads/project_image/a3dc098e-2ea6-11ee-b2e9-525400dd40c4.jpeg', '2023-07-30 17:59:35', '2023-07-30 18:09:00'),
(110, 24, 14, 'uploads/project_image/c11155fe-2ea6-11ee-8d8c-525400dd40c4.jpg', 'uploads/project_image/thumbs/f52a971e-2ea7-11ee-bdb7-525400dd40c4.jpg', 'uploads/project_image/c11155fe-2ea6-11ee-8d8c-525400dd40c4.jpg', '2023-07-30 18:00:24', '2023-07-30 18:09:01'),
(111, 24, 15, 'uploads/project_image/d4bc2b46-2ea7-11ee-a6ed-525400dd40c4.jpg', 'uploads/project_image/thumbs/f5a2397c-2ea7-11ee-a0b5-525400dd40c4.jpg', 'uploads/project_image/d4bc2b46-2ea7-11ee-a6ed-525400dd40c4.jpg', '2023-07-30 18:08:06', '2023-07-30 18:09:01'),
(112, 23, 1, 'uploads/project_image/e93ebcae-2ea8-11ee-a61d-525400dd40c4.jpg', 'uploads/project_image/thumbs/041ce6e0-2ea9-11ee-8c89-525400dd40c4.jpg', 'uploads/project_image/e93ebcae-2ea8-11ee-a61d-525400dd40c4.jpg', '2023-07-30 18:15:49', '2023-07-30 18:16:34'),
(113, 23, 2, 'uploads/project_image/e963f8b6-2ea8-11ee-b952-525400dd40c4.jpg', 'uploads/project_image/thumbs/04334bba-2ea9-11ee-9ce6-525400dd40c4.jpg', 'uploads/project_image/e963f8b6-2ea8-11ee-b952-525400dd40c4.jpg', '2023-07-30 18:15:50', '2023-07-30 18:16:35'),
(114, 23, 3, 'uploads/project_image/ebd90e7e-2ea8-11ee-aad5-525400dd40c4.jpg', 'uploads/project_image/thumbs/04433d40-2ea9-11ee-becc-525400dd40c4.jpg', 'uploads/project_image/ebd90e7e-2ea8-11ee-aad5-525400dd40c4.jpg', '2023-07-30 18:15:54', '2023-07-30 18:16:35'),
(115, 23, 4, 'uploads/project_image/ed6750e8-2ea8-11ee-ac45-525400dd40c4.jpg', 'uploads/project_image/thumbs/045d0388-2ea9-11ee-af52-525400dd40c4.jpg', 'uploads/project_image/ed6750e8-2ea8-11ee-ac45-525400dd40c4.jpg', '2023-07-30 18:15:56', '2023-07-30 18:16:35'),
(116, NULL, NULL, 'uploads/project_image/3f08bf14-311e-11ee-b96e-525400dd40c4.jpg', NULL, 'uploads/project_image/3f08bf14-311e-11ee-b96e-525400dd40c4.jpg', '2023-08-02 21:20:47', '2023-08-02 21:20:47'),
(117, NULL, NULL, 'uploads/project_image/402d9c34-311e-11ee-9288-525400dd40c4.jpg', NULL, 'uploads/project_image/402d9c34-311e-11ee-9288-525400dd40c4.jpg', '2023-08-02 21:20:49', '2023-08-02 21:20:49'),
(118, NULL, NULL, 'uploads/project_image/405887e6-311e-11ee-a6bb-525400dd40c4.jpg', NULL, 'uploads/project_image/405887e6-311e-11ee-a6bb-525400dd40c4.jpg', '2023-08-02 21:20:49', '2023-08-02 21:20:49'),
(119, NULL, NULL, 'uploads/project_image/40592f48-311e-11ee-a8d8-525400dd40c4.jpg', NULL, 'uploads/project_image/40592f48-311e-11ee-a8d8-525400dd40c4.jpg', '2023-08-02 21:20:49', '2023-08-02 21:20:49'),
(120, NULL, NULL, 'uploads/project_image/4059eb4a-311e-11ee-9252-525400dd40c4.jpg', NULL, 'uploads/project_image/4059eb4a-311e-11ee-9252-525400dd40c4.jpg', '2023-08-02 21:20:49', '2023-08-02 21:20:49'),
(121, 22, 1, 'uploads/project_image/eecceec0-311e-11ee-8d89-525400dd40c4.jpg', 'uploads/project_image/thumbs/1ad3d6aa-311f-11ee-9b38-525400dd40c4.jpg', 'uploads/project_image/eecceec0-311e-11ee-8d89-525400dd40c4.jpg', '2023-08-02 21:25:42', '2023-08-02 21:26:55'),
(122, 22, 2, 'uploads/project_image/f00d52d4-311e-11ee-89fc-525400dd40c4.jpg', 'uploads/project_image/thumbs/1adc5c8a-311f-11ee-95c9-525400dd40c4.jpg', 'uploads/project_image/f00d52d4-311e-11ee-89fc-525400dd40c4.jpg', '2023-08-02 21:25:44', '2023-08-02 21:26:55'),
(123, 22, 3, 'uploads/project_image/f00e4266-311e-11ee-9fb8-525400dd40c4.jpg', 'uploads/project_image/thumbs/1ae46fa6-311f-11ee-806d-525400dd40c4.jpg', 'uploads/project_image/f00e4266-311e-11ee-9fb8-525400dd40c4.jpg', '2023-08-02 21:25:44', '2023-08-02 21:26:56'),
(124, 22, 5, 'uploads/project_image/f039a668-311e-11ee-8575-525400dd40c4.jpg', 'uploads/project_image/thumbs/1af4ebf6-311f-11ee-a1b4-525400dd40c4.jpg', 'uploads/project_image/f039a668-311e-11ee-8575-525400dd40c4.jpg', '2023-08-02 21:25:44', '2023-08-02 21:26:56'),
(125, 22, 4, 'uploads/project_image/f039b626-311e-11ee-9050-525400dd40c4.jpg', 'uploads/project_image/thumbs/1aecbfc6-311f-11ee-8c5c-525400dd40c4.jpg', 'uploads/project_image/f039b626-311e-11ee-9050-525400dd40c4.jpg', '2023-08-02 21:25:44', '2023-08-02 21:26:56'),
(126, 21, 1, 'uploads/project_image/cf2fdb80-311f-11ee-b849-525400dd40c4.jpg', 'uploads/project_image/thumbs/47c2df02-3120-11ee-890b-525400dd40c4.jpg', 'uploads/project_image/cf2fdb80-311f-11ee-b849-525400dd40c4.jpg', '2023-08-02 21:31:58', '2023-08-02 21:35:20'),
(127, 21, 2, 'uploads/project_image/cf57a91c-311f-11ee-8911-525400dd40c4.jpg', 'uploads/project_image/thumbs/47d3e1c6-3120-11ee-ba05-525400dd40c4.jpg', 'uploads/project_image/cf57a91c-311f-11ee-8911-525400dd40c4.jpg', '2023-08-02 21:31:58', '2023-08-02 21:35:20'),
(128, 21, 3, 'uploads/project_image/d2a3dadc-311f-11ee-9bfd-525400dd40c4.jpg', 'uploads/project_image/thumbs/47e19622-3120-11ee-a4c4-525400dd40c4.jpg', 'uploads/project_image/d2a3dadc-311f-11ee-9bfd-525400dd40c4.jpg', '2023-08-02 21:32:04', '2023-08-02 21:35:21'),
(129, 21, 4, 'uploads/project_image/d6846216-311f-11ee-b2c4-525400dd40c4.jpg', 'uploads/project_image/thumbs/47f48b2e-3120-11ee-b133-525400dd40c4.jpg', 'uploads/project_image/d6846216-311f-11ee-b2c4-525400dd40c4.jpg', '2023-08-02 21:32:10', '2023-08-02 21:35:21'),
(130, 21, 5, 'uploads/project_image/d74fedbe-311f-11ee-bdad-525400dd40c4.jpg', 'uploads/project_image/thumbs/4808d8ea-3120-11ee-9e51-525400dd40c4.jpg', 'uploads/project_image/d74fedbe-311f-11ee-bdad-525400dd40c4.jpg', '2023-08-02 21:32:12', '2023-08-02 21:35:21'),
(131, 21, 6, 'uploads/project_image/dbc7b30e-311f-11ee-8f69-525400dd40c4.jpg', 'uploads/project_image/thumbs/482fab82-3120-11ee-abac-525400dd40c4.jpg', 'uploads/project_image/dbc7b30e-311f-11ee-8f69-525400dd40c4.jpg', '2023-08-02 21:32:19', '2023-08-02 21:35:21'),
(132, 21, 7, 'uploads/project_image/dc49b7aa-311f-11ee-a1d9-525400dd40c4.jpg', 'uploads/project_image/thumbs/48595c70-3120-11ee-b017-525400dd40c4.jpg', 'uploads/project_image/dc49b7aa-311f-11ee-a1d9-525400dd40c4.jpg', '2023-08-02 21:32:20', '2023-08-02 21:35:22'),
(133, 21, 8, 'uploads/project_image/dd2b0a66-311f-11ee-8c09-525400dd40c4.jpg', 'uploads/project_image/thumbs/488350fc-3120-11ee-bb7d-525400dd40c4.jpg', 'uploads/project_image/dd2b0a66-311f-11ee-8c09-525400dd40c4.jpg', '2023-08-02 21:32:22', '2023-08-02 21:35:22'),
(134, 21, 9, 'uploads/project_image/dda83b76-311f-11ee-9d5e-525400dd40c4.jpg', 'uploads/project_image/thumbs/48ab0408-3120-11ee-a074-525400dd40c4.jpg', 'uploads/project_image/dda83b76-311f-11ee-9d5e-525400dd40c4.jpg', '2023-08-02 21:32:23', '2023-08-02 21:35:22'),
(135, 21, 10, 'uploads/project_image/dfddd0d6-311f-11ee-9901-525400dd40c4.jpg', 'uploads/project_image/thumbs/48d4358a-3120-11ee-8f5b-525400dd40c4.jpg', 'uploads/project_image/dfddd0d6-311f-11ee-9901-525400dd40c4.jpg', '2023-08-02 21:32:26', '2023-08-02 21:35:22'),
(136, 20, 10, 'uploads/project_image/7d5c36ae-3120-11ee-912a-525400dd40c4.jpg', 'uploads/project_image/thumbs/449841c2-3121-11ee-87bf-525400dd40c4.jpg', 'uploads/project_image/7d5c36ae-3120-11ee-912a-525400dd40c4.jpg', '2023-08-02 21:36:50', '2023-08-02 21:42:25'),
(137, 20, 4, 'uploads/project_image/7d8585f4-3120-11ee-a80a-525400dd40c4.jpg', 'uploads/project_image/thumbs/439a8b22-3121-11ee-97ef-525400dd40c4.jpg', 'uploads/project_image/7d8585f4-3120-11ee-a80a-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:42:23'),
(138, 20, 9, 'uploads/project_image/7d88f004-3120-11ee-8a86-525400dd40c4.jpg', 'uploads/project_image/thumbs/449174d2-3121-11ee-8848-525400dd40c4.jpg', 'uploads/project_image/7d88f004-3120-11ee-8a86-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:42:24'),
(139, 20, 11, 'uploads/project_image/7d8839e8-3120-11ee-9df6-525400dd40c4.jpg', 'uploads/project_image/thumbs/44b22f42-3121-11ee-99dc-525400dd40c4.jpg', 'uploads/project_image/7d8839e8-3120-11ee-9df6-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:42:25'),
(140, 20, 8, 'uploads/project_image/7df982b0-3120-11ee-8885-525400dd40c4.jpg', 'uploads/project_image/thumbs/448a5af8-3121-11ee-9aba-525400dd40c4.jpg', 'uploads/project_image/7df982b0-3120-11ee-8885-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:42:24'),
(141, 20, 2, 'uploads/project_image/7df8fab6-3120-11ee-8cf7-525400dd40c4.jpg', 'uploads/project_image/thumbs/4316afa0-3121-11ee-b939-525400dd40c4.jpg', 'uploads/project_image/7df8fab6-3120-11ee-8cf7-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:42:22'),
(142, NULL, NULL, 'uploads/project_image/7df698a2-3120-11ee-b592-525400dd40c4.jpg', NULL, 'uploads/project_image/7df698a2-3120-11ee-b592-525400dd40c4.jpg', '2023-08-02 21:36:51', '2023-08-02 21:36:51'),
(143, 20, 6, 'uploads/project_image/c930b852-3120-11ee-8dd3-525400dd40c4.jpg', 'uploads/project_image/thumbs/43a7a974-3121-11ee-8642-525400dd40c4.jpg', 'uploads/project_image/c930b852-3120-11ee-8dd3-525400dd40c4.jpg', '2023-08-02 21:38:58', '2023-08-02 21:42:24'),
(144, 20, 7, 'uploads/project_image/cd01a2fc-3120-11ee-8577-525400dd40c4.jpg', 'uploads/project_image/thumbs/4415ceae-3121-11ee-9fad-525400dd40c4.jpg', 'uploads/project_image/cd01a2fc-3120-11ee-8577-525400dd40c4.jpg', '2023-08-02 21:39:05', '2023-08-02 21:42:24'),
(145, 20, 3, 'uploads/project_image/cd06859c-3120-11ee-91d6-525400dd40c4.jpg', 'uploads/project_image/thumbs/431ed3e2-3121-11ee-8da5-525400dd40c4.jpg', 'uploads/project_image/cd06859c-3120-11ee-91d6-525400dd40c4.jpg', '2023-08-02 21:39:05', '2023-08-02 21:42:23'),
(146, 20, 5, 'uploads/project_image/09a8fb42-3121-11ee-8d3f-525400dd40c4.jpg', 'uploads/project_image/thumbs/43a12df6-3121-11ee-914d-525400dd40c4.jpg', 'uploads/project_image/09a8fb42-3121-11ee-8d3f-525400dd40c4.jpg', '2023-08-02 21:40:46', '2023-08-02 21:42:23'),
(147, 20, 1, 'uploads/project_image/18d775a8-3121-11ee-a608-525400dd40c4.jpg', 'uploads/project_image/thumbs/430f40da-3121-11ee-a3c5-525400dd40c4.jpg', 'uploads/project_image/18d775a8-3121-11ee-a608-525400dd40c4.jpg', '2023-08-02 21:41:11', '2023-08-02 21:42:22'),
(148, 25, 1, 'uploads/project_image/c11b05ac-3907-11ee-82fc-525400dd40c4.jpg', 'uploads/project_image/thumbs/e64592ce-3908-11ee-a47c-525400dd40c4.jpg', 'uploads/project_image/c11b05ac-3907-11ee-82fc-525400dd40c4.jpg', '2023-08-12 22:59:56', '2023-08-12 23:08:08'),
(149, 25, 2, 'uploads/project_image/c847d30a-3907-11ee-82bf-525400dd40c4.jpg', 'uploads/project_image/thumbs/e657f856-3908-11ee-a487-525400dd40c4.jpg', 'uploads/project_image/c847d30a-3907-11ee-82bf-525400dd40c4.jpg', '2023-08-12 23:00:08', '2023-08-12 23:08:08'),
(150, 25, 3, 'uploads/project_image/c871615c-3907-11ee-851d-525400dd40c4.jpg', 'uploads/project_image/thumbs/e66895c6-3908-11ee-a215-525400dd40c4.jpg', 'uploads/project_image/c871615c-3907-11ee-851d-525400dd40c4.jpg', '2023-08-12 23:00:08', '2023-08-12 23:08:08'),
(151, 25, 4, 'uploads/project_image/d0936a60-3907-11ee-b96b-525400dd40c4.jpg', 'uploads/project_image/thumbs/e67926f2-3908-11ee-8378-525400dd40c4.jpg', 'uploads/project_image/d0936a60-3907-11ee-b96b-525400dd40c4.jpg', '2023-08-12 23:00:22', '2023-08-12 23:08:08'),
(152, 25, 5, 'uploads/project_image/dbf2e8d6-3907-11ee-9361-525400dd40c4.jpg', 'uploads/project_image/thumbs/e68e02ca-3908-11ee-b4ea-525400dd40c4.jpg', 'uploads/project_image/dbf2e8d6-3907-11ee-9361-525400dd40c4.jpg', '2023-08-12 23:00:41', '2023-08-12 23:08:08'),
(153, 25, 6, 'uploads/project_image/dd59d5f4-3907-11ee-9d6e-525400dd40c4.jpg', 'uploads/project_image/thumbs/e69f8612-3908-11ee-a230-525400dd40c4.jpg', 'uploads/project_image/dd59d5f4-3907-11ee-9d6e-525400dd40c4.jpg', '2023-08-12 23:00:43', '2023-08-12 23:08:08'),
(154, 25, 7, 'uploads/project_image/ef431744-3907-11ee-9898-525400dd40c4.jpg', 'uploads/project_image/thumbs/e6b1a090-3908-11ee-8097-525400dd40c4.jpg', 'uploads/project_image/ef431744-3907-11ee-9898-525400dd40c4.jpg', '2023-08-12 23:01:13', '2023-08-12 23:08:08'),
(155, 25, 8, 'uploads/project_image/f4e1a0a8-3907-11ee-b4ca-525400dd40c4.jpg', 'uploads/project_image/thumbs/e6c45e38-3908-11ee-a64b-525400dd40c4.jpg', 'uploads/project_image/f4e1a0a8-3907-11ee-b4ca-525400dd40c4.jpg', '2023-08-12 23:01:23', '2023-08-12 23:08:09'),
(156, 26, 1, 'uploads/project_image/25a1325c-3909-11ee-815a-525400dd40c4.jpg', 'uploads/project_image/thumbs/ca93304e-3909-11ee-b75f-525400dd40c4.jpg', 'uploads/project_image/25a1325c-3909-11ee-815a-525400dd40c4.jpg', '2023-08-12 23:09:54', '2023-08-12 23:14:31'),
(157, 26, 2, 'uploads/project_image/29039e62-3909-11ee-a4ac-525400dd40c4.jpg', 'uploads/project_image/thumbs/caa84420-3909-11ee-926e-525400dd40c4.jpg', 'uploads/project_image/29039e62-3909-11ee-a4ac-525400dd40c4.jpg', '2023-08-12 23:10:00', '2023-08-12 23:14:31'),
(158, 26, 3, 'uploads/project_image/290329b4-3909-11ee-8610-525400dd40c4.jpg', 'uploads/project_image/thumbs/cabe38b6-3909-11ee-9a0a-525400dd40c4.jpg', 'uploads/project_image/290329b4-3909-11ee-8610-525400dd40c4.jpg', '2023-08-12 23:10:00', '2023-08-12 23:14:31'),
(159, 26, 4, 'uploads/project_image/2bc44ac0-3909-11ee-b89a-525400dd40c4.jpg', 'uploads/project_image/thumbs/cad4bff0-3909-11ee-b523-525400dd40c4.jpg', 'uploads/project_image/2bc44ac0-3909-11ee-b89a-525400dd40c4.jpg', '2023-08-12 23:10:04', '2023-08-12 23:14:31'),
(160, 26, 5, 'uploads/project_image/2d856a10-3909-11ee-8a07-525400dd40c4.jpg', 'uploads/project_image/thumbs/caea421c-3909-11ee-89c6-525400dd40c4.jpg', 'uploads/project_image/2d856a10-3909-11ee-8a07-525400dd40c4.jpg', '2023-08-12 23:10:07', '2023-08-12 23:14:31'),
(161, 27, 1, 'uploads/project_image/8abb0180-390a-11ee-b572-525400dd40c4.jpg', 'uploads/project_image/thumbs/d6089a5c-390b-11ee-afb0-525400dd40c4.jpg', 'uploads/project_image/8abb0180-390a-11ee-b572-525400dd40c4.jpg', '2023-08-12 23:19:53', '2023-08-12 23:29:09'),
(162, 27, 2, 'uploads/project_image/8b5182ea-390a-11ee-a9b6-525400dd40c4.jpg', 'uploads/project_image/thumbs/d628f748-390b-11ee-b79b-525400dd40c4.jpg', 'uploads/project_image/8b5182ea-390a-11ee-a9b6-525400dd40c4.jpg', '2023-08-12 23:19:54', '2023-08-12 23:29:09'),
(163, 27, 3, 'uploads/project_image/97749e86-390a-11ee-8507-525400dd40c4.jpg', 'uploads/project_image/thumbs/d649d7f6-390b-11ee-8ff3-525400dd40c4.jpg', 'uploads/project_image/97749e86-390a-11ee-8507-525400dd40c4.jpg', '2023-08-12 23:20:15', '2023-08-12 23:29:09'),
(164, 27, 4, 'uploads/project_image/a280d312-390a-11ee-aaa5-525400dd40c4.jpg', 'uploads/project_image/thumbs/d66bf76e-390b-11ee-bc67-525400dd40c4.jpg', 'uploads/project_image/a280d312-390a-11ee-aaa5-525400dd40c4.jpg', '2023-08-12 23:20:33', '2023-08-12 23:29:10'),
(165, 28, 2, 'uploads/project_image/b1cc8e8e-399f-11ee-9e25-525400dd40c4.jpg', 'uploads/project_image/thumbs/c816e81a-399f-11ee-9f74-525400dd40c4.jpg', 'uploads/project_image/b1cc8e8e-399f-11ee-9e25-525400dd40c4.jpg', '2023-08-13 17:07:34', '2023-08-13 17:08:11'),
(166, 28, 1, 'uploads/project_image/b1cc8e16-399f-11ee-8284-525400dd40c4.jpg', 'uploads/project_image/thumbs/c81158b4-399f-11ee-ab05-525400dd40c4.jpg', 'uploads/project_image/b1cc8e16-399f-11ee-8284-525400dd40c4.jpg', '2023-08-13 17:07:34', '2023-08-13 17:08:11'),
(167, 28, 3, 'uploads/project_image/b1cc8e84-399f-11ee-9103-525400dd40c4.jpg', 'uploads/project_image/thumbs/c81cc5aa-399f-11ee-b882-525400dd40c4.jpg', 'uploads/project_image/b1cc8e84-399f-11ee-9103-525400dd40c4.jpg', '2023-08-13 17:07:34', '2023-08-13 17:08:11'),
(168, 28, 4, 'uploads/project_image/b1f12e24-399f-11ee-84c9-525400dd40c4.jpg', 'uploads/project_image/thumbs/c821d2de-399f-11ee-b348-525400dd40c4.jpg', 'uploads/project_image/b1f12e24-399f-11ee-84c9-525400dd40c4.jpg', '2023-08-13 17:07:34', '2023-08-13 17:08:11'),
(169, 29, 1, 'uploads/project_image/e8400b9c-39a1-11ee-ae08-525400dd40c4.jpg', 'uploads/project_image/thumbs/f884b78c-39a1-11ee-ac1b-525400dd40c4.jpg', 'uploads/project_image/e8400b9c-39a1-11ee-ae08-525400dd40c4.jpg', '2023-08-13 17:23:24', '2023-08-13 17:23:51'),
(170, 29, 2, 'uploads/project_image/e8400b6a-39a1-11ee-b3e2-525400dd40c4.jpg', 'uploads/project_image/thumbs/f893568e-39a1-11ee-8c21-525400dd40c4.jpg', 'uploads/project_image/e8400b6a-39a1-11ee-b3e2-525400dd40c4.jpg', '2023-08-13 17:23:24', '2023-08-13 17:23:51'),
(171, 29, 3, 'uploads/project_image/e8400ba6-39a1-11ee-99c1-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8a25c42-39a1-11ee-9cbe-525400dd40c4.jpg', 'uploads/project_image/e8400ba6-39a1-11ee-99c1-525400dd40c4.jpg', '2023-08-13 17:23:24', '2023-08-13 17:23:51'),
(172, 29, 4, 'uploads/project_image/e85daa94-39a1-11ee-a7e5-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8b171a0-39a1-11ee-a217-525400dd40c4.jpg', 'uploads/project_image/e85daa94-39a1-11ee-a7e5-525400dd40c4.jpg', '2023-08-13 17:23:24', '2023-08-13 17:23:52'),
(173, 29, 5, 'uploads/project_image/e88d9a88-39a1-11ee-9d7b-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8c16920-39a1-11ee-adef-525400dd40c4.jpg', 'uploads/project_image/e88d9a88-39a1-11ee-9d7b-525400dd40c4.jpg', '2023-08-13 17:23:25', '2023-08-13 17:23:52'),
(174, 29, 6, 'uploads/project_image/e88ee6fe-39a1-11ee-85b9-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8d09206-39a1-11ee-8d1a-525400dd40c4.jpg', 'uploads/project_image/e88ee6fe-39a1-11ee-85b9-525400dd40c4.jpg', '2023-08-13 17:23:25', '2023-08-13 17:23:52'),
(175, 29, 7, 'uploads/project_image/ef5153d2-39a1-11ee-9538-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8dfa30e-39a1-11ee-a700-525400dd40c4.jpg', 'uploads/project_image/ef5153d2-39a1-11ee-9538-525400dd40c4.jpg', '2023-08-13 17:23:36', '2023-08-13 17:23:52'),
(176, 29, 8, 'uploads/project_image/ef7e858c-39a1-11ee-ab69-525400dd40c4.jpg', 'uploads/project_image/thumbs/f8ee9c7e-39a1-11ee-b299-525400dd40c4.jpg', 'uploads/project_image/ef7e858c-39a1-11ee-ab69-525400dd40c4.jpg', '2023-08-13 17:23:36', '2023-08-13 17:23:52'),
(177, 30, 1, 'uploads/project_image/ab019752-39c2-11ee-8667-525400dd40c4.jpg', 'uploads/project_image/thumbs/d010f86c-39c2-11ee-9381-525400dd40c4.jpg', 'uploads/project_image/ab019752-39c2-11ee-8667-525400dd40c4.jpg', '2023-08-13 21:17:55', '2023-08-13 21:18:57'),
(178, 30, 2, 'uploads/project_image/ab5a14c2-39c2-11ee-90c1-525400dd40c4.jpg', 'uploads/project_image/thumbs/d02b14e0-39c2-11ee-b2a3-525400dd40c4.jpg', 'uploads/project_image/ab5a14c2-39c2-11ee-90c1-525400dd40c4.jpg', '2023-08-13 21:17:55', '2023-08-13 21:18:57'),
(179, 30, 3, 'uploads/project_image/ade7f2d6-39c2-11ee-82b2-525400dd40c4.jpg', 'uploads/project_image/thumbs/d0436b4e-39c2-11ee-8de9-525400dd40c4.jpg', 'uploads/project_image/ade7f2d6-39c2-11ee-82b2-525400dd40c4.jpg', '2023-08-13 21:18:00', '2023-08-13 21:18:57'),
(180, 31, 1, 'uploads/project_image/b2cfddf2-5229-11ee-bf4f-525400dd40c4.jpg', 'uploads/project_image/thumbs/b4f87008-5229-11ee-b8e9-525400dd40c4.jpg', 'uploads/project_image/b2cfddf2-5229-11ee-bf4f-525400dd40c4.jpg', '2023-09-13 22:35:54', '2023-09-13 22:35:57'),
(181, 31, 2, 'uploads/project_image/b2e6ce36-5229-11ee-833a-525400dd40c4.jpg', 'uploads/project_image/thumbs/b4fbcc4e-5229-11ee-88c5-525400dd40c4.jpg', 'uploads/project_image/b2e6ce36-5229-11ee-833a-525400dd40c4.jpg', '2023-09-13 22:35:54', '2023-09-13 22:35:57'),
(182, 32, 1, 'uploads/project_image/a8a0ceca-522b-11ee-868f-525400dd40c4.jpg', 'uploads/project_image/thumbs/bb9377bc-522b-11ee-b11e-525400dd40c4.jpg', 'uploads/project_image/a8a0ceca-522b-11ee-868f-525400dd40c4.jpg', '2023-09-13 22:49:56', '2023-09-13 22:50:28'),
(183, 32, 2, 'uploads/project_image/aaf2748a-522b-11ee-92f6-525400dd40c4.jpg', 'uploads/project_image/thumbs/bbae8e12-522b-11ee-ae27-525400dd40c4.jpg', 'uploads/project_image/aaf2748a-522b-11ee-92f6-525400dd40c4.jpg', '2023-09-13 22:50:00', '2023-09-13 22:50:28'),
(184, 33, 1, 'uploads/project_image/a8427f56-52ed-11ee-886f-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad7e9612-52ed-11ee-ba35-525400dd40c4.jpg', 'uploads/project_image/a8427f56-52ed-11ee-886f-525400dd40c4.jpg', '2023-09-14 21:58:37', '2023-09-14 21:58:46'),
(185, 33, 2, 'uploads/project_image/a84282da-52ed-11ee-a784-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad815064-52ed-11ee-9f6a-525400dd40c4.jpg', 'uploads/project_image/a84282da-52ed-11ee-a784-525400dd40c4.jpg', '2023-09-14 21:58:37', '2023-09-14 21:58:46'),
(186, 33, 3, 'uploads/project_image/a8427ea2-52ed-11ee-ab73-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad83dac8-52ed-11ee-addd-525400dd40c4.jpg', 'uploads/project_image/a8427ea2-52ed-11ee-ab73-525400dd40c4.jpg', '2023-09-14 21:58:37', '2023-09-14 21:58:46'),
(187, 33, 4, 'uploads/project_image/a85a0f04-52ed-11ee-95b5-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad863e94-52ed-11ee-b9a3-525400dd40c4.jpg', 'uploads/project_image/a85a0f04-52ed-11ee-95b5-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(188, 33, 5, 'uploads/project_image/a85a8bf0-52ed-11ee-946b-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad899a12-52ed-11ee-9c5e-525400dd40c4.jpg', 'uploads/project_image/a85a8bf0-52ed-11ee-946b-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(189, 33, 6, 'uploads/project_image/a85b81e0-52ed-11ee-bd4d-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad8c61f2-52ed-11ee-8ee7-525400dd40c4.jpg', 'uploads/project_image/a85b81e0-52ed-11ee-bd4d-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(190, 33, 7, 'uploads/project_image/a85bb764-52ed-11ee-8d73-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad903c64-52ed-11ee-914b-525400dd40c4.jpg', 'uploads/project_image/a85bb764-52ed-11ee-8d73-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(191, 33, 8, 'uploads/project_image/a85d0600-52ed-11ee-bce1-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad929a68-52ed-11ee-8b28-525400dd40c4.jpg', 'uploads/project_image/a85d0600-52ed-11ee-bce1-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(192, 33, 9, 'uploads/project_image/a85cf08e-52ed-11ee-9143-525400dd40c4.jpg', 'uploads/project_image/thumbs/ad9514a0-52ed-11ee-86e4-525400dd40c4.jpg', 'uploads/project_image/a85cf08e-52ed-11ee-9143-525400dd40c4.jpg', '2023-09-14 21:58:38', '2023-09-14 21:58:46'),
(193, 34, 1, 'uploads/project_image/315e391a-52ee-11ee-9197-525400dd40c4.jpg', 'uploads/project_image/thumbs/44b9f116-52ee-11ee-bf8d-525400dd40c4.jpg', 'uploads/project_image/315e391a-52ee-11ee-9197-525400dd40c4.jpg', '2023-09-14 22:02:27', '2023-09-14 22:03:00'),
(194, 34, 2, 'uploads/project_image/315f08e0-52ee-11ee-9f69-525400dd40c4.jpg', 'uploads/project_image/thumbs/44bcfef6-52ee-11ee-9430-525400dd40c4.jpg', 'uploads/project_image/315f08e0-52ee-11ee-9f69-525400dd40c4.jpg', '2023-09-14 22:02:27', '2023-09-14 22:03:00'),
(195, 34, 3, 'uploads/project_image/31892ef4-52ee-11ee-bc9e-525400dd40c4.jpg', 'uploads/project_image/thumbs/44c01276-52ee-11ee-8724-525400dd40c4.jpg', 'uploads/project_image/31892ef4-52ee-11ee-bc9e-525400dd40c4.jpg', '2023-09-14 22:02:28', '2023-09-14 22:03:00'),
(196, 35, 1, 'uploads/project_image/cde836e6-52ee-11ee-8bf6-525400dd40c4.jpg', 'uploads/project_image/thumbs/d2975f1e-52ee-11ee-ae0a-525400dd40c4.jpg', 'uploads/project_image/cde836e6-52ee-11ee-8bf6-525400dd40c4.jpg', '2023-09-14 22:06:50', '2023-09-14 22:06:58'),
(197, 35, 2, 'uploads/project_image/cde83696-52ee-11ee-967d-525400dd40c4.jpg', 'uploads/project_image/thumbs/d29a56a6-52ee-11ee-849e-525400dd40c4.jpg', 'uploads/project_image/cde83696-52ee-11ee-967d-525400dd40c4.jpg', '2023-09-14 22:06:50', '2023-09-14 22:06:58'),
(198, 35, 3, 'uploads/project_image/cde836e6-52ee-11ee-9198-525400dd40c4.jpg', 'uploads/project_image/thumbs/d29dfbc6-52ee-11ee-947d-525400dd40c4.jpg', 'uploads/project_image/cde836e6-52ee-11ee-9198-525400dd40c4.jpg', '2023-09-14 22:06:50', '2023-09-14 22:06:58'),
(199, 36, 3, 'uploads/project_image/4e17d222-52ef-11ee-9f7a-525400dd40c4.jpg', 'uploads/project_image/thumbs/5069295e-52ef-11ee-b1b9-525400dd40c4.jpg', 'uploads/project_image/4e17d222-52ef-11ee-9f7a-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(200, 36, 1, 'uploads/project_image/4e17d132-52ef-11ee-8093-525400dd40c4.jpg', 'uploads/project_image/thumbs/50642544-52ef-11ee-a4f0-525400dd40c4.jpg', 'uploads/project_image/4e17d132-52ef-11ee-8093-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(201, 36, 6, 'uploads/project_image/4e17d1be-52ef-11ee-b957-525400dd40c4.jpg', 'uploads/project_image/thumbs/506fc9c6-52ef-11ee-a4fe-525400dd40c4.jpg', 'uploads/project_image/4e17d1be-52ef-11ee-b957-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(202, 36, 5, 'uploads/project_image/4e17d1f0-52ef-11ee-a71e-525400dd40c4.jpg', 'uploads/project_image/thumbs/506d5dee-52ef-11ee-a55d-525400dd40c4.jpg', 'uploads/project_image/4e17d1f0-52ef-11ee-a71e-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(203, 36, 2, 'uploads/project_image/4e17d664-52ef-11ee-a557-525400dd40c4.jpg', 'uploads/project_image/thumbs/5066a846-52ef-11ee-a4c0-525400dd40c4.jpg', 'uploads/project_image/4e17d664-52ef-11ee-a557-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(204, 36, 4, 'uploads/project_image/4e17d664-52ef-11ee-b525-525400dd40c4.jpg', 'uploads/project_image/thumbs/506b21e6-52ef-11ee-9819-525400dd40c4.jpg', 'uploads/project_image/4e17d664-52ef-11ee-b525-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(205, 36, 7, 'uploads/project_image/4e27a04e-52ef-11ee-bfb9-525400dd40c4.jpg', 'uploads/project_image/thumbs/50722810-52ef-11ee-bfd4-525400dd40c4.jpg', 'uploads/project_image/4e27a04e-52ef-11ee-bfb9-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(206, 36, 8, 'uploads/project_image/4e281506-52ef-11ee-81ce-525400dd40c4.jpg', 'uploads/project_image/thumbs/507449ba-52ef-11ee-be62-525400dd40c4.jpg', 'uploads/project_image/4e281506-52ef-11ee-81ce-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(207, 36, 9, 'uploads/project_image/4e286786-52ef-11ee-8025-525400dd40c4.jpg', 'uploads/project_image/thumbs/50767cf8-52ef-11ee-80f8-525400dd40c4.jpg', 'uploads/project_image/4e286786-52ef-11ee-8025-525400dd40c4.jpg', '2023-09-14 22:10:25', '2023-09-14 22:10:29'),
(208, NULL, NULL, 'uploads/project_image/8ff3aa9a-52ef-11ee-8d47-525400dd40c4.jpg', NULL, 'uploads/project_image/8ff3aa9a-52ef-11ee-8d47-525400dd40c4.jpg', '2023-09-14 22:12:16', '2023-09-14 22:12:16'),
(209, NULL, NULL, 'uploads/project_image/9019421e-52ef-11ee-bfd6-525400dd40c4.jpg', NULL, 'uploads/project_image/9019421e-52ef-11ee-bfd6-525400dd40c4.jpg', '2023-09-14 22:12:16', '2023-09-14 22:12:16'),
(210, 37, 1, 'uploads/project_image/2ea853a2-52f0-11ee-8cb6-525400dd40c4.jpg', 'uploads/project_image/thumbs/3be9fcf0-52f0-11ee-9f88-525400dd40c4.jpg', 'uploads/project_image/2ea853a2-52f0-11ee-8cb6-525400dd40c4.jpg', '2023-09-14 22:16:42', '2023-09-14 22:17:04'),
(211, 37, 2, 'uploads/project_image/2ea8538e-52f0-11ee-bed2-525400dd40c4.jpg', 'uploads/project_image/thumbs/3bec2552-52f0-11ee-ac72-525400dd40c4.jpg', 'uploads/project_image/2ea8538e-52f0-11ee-bed2-525400dd40c4.jpg', '2023-09-14 22:16:42', '2023-09-14 22:17:04'),
(212, 37, 3, 'uploads/project_image/2ed3f05c-52f0-11ee-b5e0-525400dd40c4.jpg', 'uploads/project_image/thumbs/3bee364e-52f0-11ee-8658-525400dd40c4.jpg', 'uploads/project_image/2ed3f05c-52f0-11ee-b5e0-525400dd40c4.jpg', '2023-09-14 22:16:42', '2023-09-14 22:17:04'),
(213, 37, 5, 'uploads/project_image/2ed3e80a-52f0-11ee-88fd-525400dd40c4.jpg', 'uploads/project_image/thumbs/3bf3070a-52f0-11ee-81a6-525400dd40c4.jpg', 'uploads/project_image/2ed3e80a-52f0-11ee-88fd-525400dd40c4.jpg', '2023-09-14 22:16:42', '2023-09-14 22:17:04'),
(214, 37, 4, 'uploads/project_image/2ed39f8a-52f0-11ee-b7f4-525400dd40c4.jpg', 'uploads/project_image/thumbs/3bf0349e-52f0-11ee-a583-525400dd40c4.jpg', 'uploads/project_image/2ed39f8a-52f0-11ee-b7f4-525400dd40c4.jpg', '2023-09-14 22:16:42', '2023-09-14 22:17:04'),
(215, 38, 1, 'uploads/project_image/c2fa3bf8-52f3-11ee-85db-525400dd40c4.jpg', 'uploads/project_image/thumbs/c6a7027c-52f3-11ee-b857-525400dd40c4.jpg', 'uploads/project_image/c2fa3bf8-52f3-11ee-85db-525400dd40c4.jpg', '2023-09-14 22:42:19', '2023-09-14 22:42:25'),
(216, 38, 2, 'uploads/project_image/c2fa2050-52f3-11ee-96b4-525400dd40c4.jpg', 'uploads/project_image/thumbs/c6aa18a4-52f3-11ee-99ab-525400dd40c4.jpg', 'uploads/project_image/c2fa2050-52f3-11ee-96b4-525400dd40c4.jpg', '2023-09-14 22:42:19', '2023-09-14 22:42:25'),
(217, 38, 3, 'uploads/project_image/c2fa2000-52f3-11ee-a40c-525400dd40c4.jpg', 'uploads/project_image/thumbs/c6accb6c-52f3-11ee-a0d8-525400dd40c4.jpg', 'uploads/project_image/c2fa2000-52f3-11ee-a40c-525400dd40c4.jpg', '2023-09-14 22:42:19', '2023-09-14 22:42:25'),
(218, 38, 4, 'uploads/project_image/c2fa2078-52f3-11ee-8a58-525400dd40c4.jpg', 'uploads/project_image/thumbs/c6af71aa-52f3-11ee-a2fe-525400dd40c4.jpg', 'uploads/project_image/c2fa2078-52f3-11ee-8a58-525400dd40c4.jpg', '2023-09-14 22:42:19', '2023-09-14 22:42:25'),
(219, 36, 10, 'uploads/project_image/eeaee488-52f3-11ee-9d64-525400dd40c4.jpg', 'uploads/project_image/thumbs/f08b9850-52f3-11ee-8ea0-525400dd40c4.jpg', 'uploads/project_image/eeaee488-52f3-11ee-9d64-525400dd40c4.jpg', '2023-09-14 22:43:33', '2023-09-14 22:43:36'),
(220, 36, 11, 'uploads/project_image/eed69d48-52f3-11ee-a26a-525400dd40c4.jpg', 'uploads/project_image/thumbs/f08f5684-52f3-11ee-803c-525400dd40c4.jpg', 'uploads/project_image/eed69d48-52f3-11ee-a26a-525400dd40c4.jpg', '2023-09-14 22:43:33', '2023-09-14 22:43:36'),
(221, 36, 12, 'uploads/project_image/eed873f2-52f3-11ee-bb65-525400dd40c4.jpg', 'uploads/project_image/thumbs/f09215a4-52f3-11ee-89f2-525400dd40c4.jpg', 'uploads/project_image/eed873f2-52f3-11ee-bb65-525400dd40c4.jpg', '2023-09-14 22:43:33', '2023-09-14 22:43:36'),
(222, 36, 13, 'uploads/project_image/eed95c18-52f3-11ee-9d6d-525400dd40c4.jpg', 'uploads/project_image/thumbs/f094d528-52f3-11ee-b9dd-525400dd40c4.jpg', 'uploads/project_image/eed95c18-52f3-11ee-9d6d-525400dd40c4.jpg', '2023-09-14 22:43:33', '2023-09-14 22:43:36'),
(223, 36, 14, 'uploads/project_image/eed9c0a4-52f3-11ee-bbe6-525400dd40c4.jpg', 'uploads/project_image/thumbs/f097a302-52f3-11ee-9461-525400dd40c4.jpg', 'uploads/project_image/eed9c0a4-52f3-11ee-bbe6-525400dd40c4.jpg', '2023-09-14 22:43:33', '2023-09-14 22:43:36'),
(224, 39, 1, 'uploads/project_image/b7d8ac0e-52f4-11ee-a1e6-525400dd40c4.jpg', 'uploads/project_image/thumbs/bbc9e742-52f4-11ee-9e70-525400dd40c4.jpg', 'uploads/project_image/b7d8ac0e-52f4-11ee-a1e6-525400dd40c4.jpg', '2023-09-14 22:49:10', '2023-09-14 22:49:17'),
(225, 39, 2, 'uploads/project_image/b7fd5a18-52f4-11ee-a767-525400dd40c4.jpg', 'uploads/project_image/thumbs/bbcdbd2c-52f4-11ee-81a5-525400dd40c4.jpg', 'uploads/project_image/b7fd5a18-52f4-11ee-a767-525400dd40c4.jpg', '2023-09-14 22:49:10', '2023-09-14 22:49:17'),
(226, 39, 3, 'uploads/project_image/b7fdf8ec-52f4-11ee-8a6c-525400dd40c4.jpg', 'uploads/project_image/thumbs/bbd1b044-52f4-11ee-8b31-525400dd40c4.jpg', 'uploads/project_image/b7fdf8ec-52f4-11ee-8a6c-525400dd40c4.jpg', '2023-09-14 22:49:10', '2023-09-14 22:49:17');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `sort`, `slug`, `description`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Construction', 3, NULL, '\"Building construction is the noble craft of turning blueprints into tangible reality. It is the dance of strength and precision, where skilled hands shape raw materials into structures that stand the test of time. It is the art of bringing dreams to life, building foundations for memories and creating spaces that leave an everlasting imprint on the world.\"', 'uploads/service/e5f6d94a-febb-11ed-a54e-525400dd40c4.jpg', 1, '2023-05-13 11:25:55', '2023-05-30 18:30:49'),
(2, 'Interior Design', 2, NULL, '\"Interior design is the art of creating harmony and inspiration within spaces, where every detail is carefully crafted to evoke emotions, ignite imagination, and transform a house into a home that truly reflects one\'s soul.\"', 'uploads/service/373420ac-fc5e-11ed-967e-525400dd40c4.jpg', 1, '2023-05-13 11:43:28', '2023-05-27 18:15:10'),
(3, 'Exterior Design', 1, NULL, '\"Building design is the marriage of imagination and functionality, where architecture becomes a canvas for innovation and purpose. It is the pursuit of spaces that not only shelter our bodies, but also inspire our minds, uplift our spirits, and shape the world we inhabit.\"', 'uploads/service/10005edc-febc-11ed-abb7-525400dd40c4.jpg', 1, '2023-05-13 11:43:56', '2023-05-30 18:32:00');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sort` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `sort`, `image`, `title`, `sub_title`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'uploads/slider/7ac46fbe-f3af-11ed-bf6a-525400dd40c4.jpg', 'OPENHOUSE ARCHITECTS & ENGINEERS', 'Open the door ;  Open the spirit', 1, '2023-05-03 05:55:12', '2023-06-01 18:38:12'),
(2, 2, 'uploads/slider/856e0ed4-f3af-11ed-9584-525400dd40c4.jpg', 'OPENHOUSE ARCHITECTS & ENGINEERS', 'Your lifelong Design Connection', 1, '2023-05-03 06:25:18', '2023-06-01 18:40:34'),
(3, 3, 'uploads/slider/aa0b5602-f3af-11ed-b586-525400dd40c4.jpg', 'OPENHOUSE ARCHITECTS & ENGINEERS', 'Open the doors to your perfect house', 1, '2023-05-03 06:25:26', '2023-06-01 18:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `title`, `created_at`, `updated_at`) VALUES
(2, 'Principal', '2023-05-02 05:15:23', '2023-05-02 05:26:01'),
(3, 'Architects', '2023-05-02 05:33:35', '2023-05-02 05:33:35');

-- --------------------------------------------------------

--
-- Table structure for table `team_headings`
--

CREATE TABLE `team_headings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_headings`
--

INSERT INTO `team_headings` (`id`, `title`, `subtitle`, `status`, `created_at`, `updated_at`) VALUES
(3, 'About Company', '<p>Openhouse Architects &amp; Engineers is an architecture and engineering firm that provides a full array of services from building design and construction to interior design and all the structural, electrical, and plumbing design needs of a building. Our company takes pride in its commitment to customer satisfaction and our team of experienced professionals places a high value on quality work. Our firm is distinguished by our dedication to sustainability. Our mission is to build with passion and creativity, to create spaces that are aesthetically pleasing, highly functional and energy efficient. With a team of experienced architects, engineers and building experts, we strive to deliver unparalleled service to our clients. Our goal is to create structures that are both beautiful and sustainable, and that serve their purpose for years to come.</p>', 1, '2023-05-24 16:28:52', '2023-05-24 16:28:52');

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `team_id`, `sort`, `image`, `name`, `designation`, `created_at`, `updated_at`) VALUES
(21, 3, 1, 'uploads/team/a11f3434-006e-11ee-8cc3-525400dd40c4.jpeg', 'ENGR. FARHANA NAZRUL', 'CEO/ FOUNDER, BSC IN ME (KU)', '2023-05-02 13:13:10', '2023-06-04 19:11:50'),
(22, 3, 2, 'uploads/team/a87d664c-006e-11ee-a9b8-525400dd40c4.jpeg', 'AR. UZZAL SINGHA', 'EXECUTIVE ARCHITECT , BARCH (BUET)', '2023-05-02 13:13:10', '2023-06-01 22:22:56'),
(23, 3, 3, 'uploads/team/b05d8e6e-006e-11ee-9a7c-525400dd40c4.jpeg', 'AR. SUSMITA SUMI', 'SENIOR ARCHITECT ,BARCH (AUST)', '2023-05-02 13:13:11', '2023-06-01 22:23:10'),
(24, 3, 4, 'uploads/team/bacaaecc-006e-11ee-9d4b-525400dd40c4.jpeg', 'AR. MALIHA AFROZ NITU', 'SENIOR ARCHITECT ,BARCH (BUET) , MARCH (USYD)', '2023-05-02 13:13:11', '2023-06-01 22:23:27'),
(26, 2, 6, 'uploads/team/ef19b718-006e-11ee-8635-525400dd40c4.jpg', 'AR. SHYCOT CHANDRA MANDAL', 'ARCHITECT(PART-TIME) , BARCH (BUET)', '2023-05-02 13:13:30', '2023-06-04 19:06:12'),
(27, 2, 7, 'uploads/team/f6e9cbae-006e-11ee-b2bd-525400dd40c4.jpg', 'AR. SUPEN CHAKMA', 'ARCHITECT(PART-TIME) ,BARCH (BUET)', '2023-05-02 13:13:30', '2023-06-04 19:06:48'),
(30, NULL, 9, 'uploads/team/a7c44344-0076-11ee-9dcb-525400dd40c4.jpg', 'ENGR. ABHISHEK SINGHA', 'ASST. QUANTITY SURVEYOR, Bsc In CE (MIST)', '2023-06-01 23:20:11', '2023-09-10 21:02:57'),
(31, NULL, 9, 'uploads/team/588edd68-02ae-11ee-983b-525400dd40c4.jpg', 'AR. MD. JASHIM UDDIN', 'JUNIOR ARCHITECT  ,BARCH (HSTU)', '2023-06-04 19:03:52', '2023-06-04 19:03:52'),
(32, NULL, 8, 'uploads/team/8ab0c98c-02ae-11ee-9198-525400dd40c4.jpeg', 'AR. MD. ABU ZAYED RIZAN', 'ASSOCIATE ARCHITECT  ,BARCH (STAMFORD UNIVERSITY)', '2023-06-04 19:05:17', '2023-07-08 17:03:22'),
(33, NULL, 10, 'uploads/team/1a242f28-4fc1-11ee-8b86-525400dd40c4.jpg', 'Sajal Kanti Singha', 'Junior Electrical Engineer, BSc in EEE (Metropoliton University)', '2023-09-10 21:02:08', '2023-09-10 21:15:21');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `designation`, `image`, `feedback`, `sort`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Enamul Haque Khan', 'Former General Secretary of Bangladesh Jewelers Association', 'uploads/testimonial/ab22fd22-f9f6-11ed-9c86-525400dd40c4.jpg', 'The house and the mosque use a consistent material palette throughout. The use of cast concrete and brick allows certain spaces to take on a cooler, utilitarian feel, while richly toned wooden details bring a feeling of warmth.', 1, 1, '2023-05-13 11:35:07', '2023-05-24 16:48:54');

-- --------------------------------------------------------

--
-- Table structure for table `trackers`
--

CREATE TABLE `trackers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_time` time NOT NULL,
  `visit_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trackers`
--

INSERT INTO `trackers` (`id`, `ip`, `hits`, `visit_time`, `visit_date`, `created_at`, `updated_at`) VALUES
(2, '45.127.245.82', '40', '19:57:49', '2023-05-30', '2023-05-30 23:22:43', '2023-05-31 00:57:49'),
(3, '103.232.100.205', '19', '23:56:15', '2023-05-30', '2023-05-30 23:39:49', '2023-05-31 04:56:15'),
(4, '119.30.41.87', '4', '19:31:22', '2023-05-30', '2023-05-31 00:22:00', '2023-05-31 00:31:22'),
(5, '119.30.41.71', '2', '20:02:05', '2023-05-30', '2023-05-31 01:01:14', '2023-05-31 01:02:05'),
(6, '40.77.167.83', '1', '20:36:25', '2023-05-30', '2023-05-31 01:36:25', '2023-05-31 01:36:25'),
(7, '173.252.83.13', '1', '21:45:51', '2023-05-30', '2023-05-31 02:45:51', '2023-05-31 02:45:51'),
(8, '173.252.83.11', '1', '21:45:52', '2023-05-30', '2023-05-31 02:45:52', '2023-05-31 02:45:52'),
(9, '193.186.4.159', '1', '23:32:07', '2023-05-30', '2023-05-31 04:32:07', '2023-05-31 04:32:07'),
(10, '66.249.66.11', '1', '02:18:14', '2023-05-31', '2023-05-31 07:18:14', '2023-05-31 07:18:14'),
(11, '66.249.66.41', '1', '02:18:14', '2023-05-31', '2023-05-31 07:18:14', '2023-05-31 07:18:14'),
(12, '45.127.245.82', '5', '13:43:12', '2023-05-31', '2023-05-31 18:39:31', '2023-05-31 18:43:12'),
(13, '31.13.103.5', '2', '13:40:05', '2023-05-31', '2023-05-31 18:40:03', '2023-05-31 18:40:05'),
(14, '31.13.103.20', '1', '13:40:03', '2023-05-31', '2023-05-31 18:40:03', '2023-05-31 18:40:03'),
(15, '40.77.167.231', '1', '16:29:07', '2023-05-31', '2023-05-31 21:29:07', '2023-05-31 21:29:07'),
(16, '27.147.205.147', '3', '22:56:33', '2023-05-31', '2023-06-01 03:53:43', '2023-06-01 03:56:33'),
(17, '103.232.100.205', '2', '17:38:11', '2023-06-01', '2023-06-01 16:08:59', '2023-06-01 22:38:11'),
(18, '103.113.208.37', '2', '13:27:14', '2023-06-01', '2023-06-01 18:27:02', '2023-06-01 18:27:14'),
(19, '45.127.245.82', '102', '17:48:01', '2023-06-01', '2023-06-01 18:33:59', '2023-06-01 22:48:01'),
(20, '119.40.93.75', '26', '17:47:06', '2023-06-01', '2023-06-01 22:42:52', '2023-06-01 22:47:06'),
(21, '103.21.42.197', '1', '17:42:54', '2023-06-01', '2023-06-01 22:42:54', '2023-06-01 22:42:54'),
(22, '103.230.106.9', '9', '18:20:15', '2023-06-01', '2023-06-01 23:14:40', '2023-06-01 23:20:15'),
(23, '223.187.121.38', '1', '18:20:53', '2023-06-01', '2023-06-01 23:20:53', '2023-06-01 23:20:53'),
(24, '66.249.66.11', '1', '21:58:06', '2023-06-01', '2023-06-02 02:58:06', '2023-06-02 02:58:06'),
(25, '37.111.201.98', '5', '19:07:48', '2023-06-02', '2023-06-03 00:01:51', '2023-06-03 00:07:48'),
(26, '103.252.226.12', '1', '19:49:12', '2023-06-02', '2023-06-03 00:49:12', '2023-06-03 00:49:12'),
(27, '103.232.100.205', '34', '18:35:10', '2023-06-03', '2023-06-03 15:45:26', '2023-06-03 23:35:10'),
(28, '45.127.245.82', '4', '19:49:45', '2023-06-03', '2023-06-03 16:06:42', '2023-06-04 00:49:45'),
(29, '37.111.201.19', '4', '16:00:21', '2023-06-03', '2023-06-03 20:57:49', '2023-06-03 21:00:21'),
(30, '37.111.201.147', '4', '16:23:06', '2023-06-03', '2023-06-03 20:59:43', '2023-06-03 21:23:06'),
(31, '119.40.93.75', '4', '17:24:47', '2023-06-03', '2023-06-03 22:20:01', '2023-06-03 22:24:47'),
(32, '173.252.79.8', '1', '17:45:19', '2023-06-03', '2023-06-03 22:45:19', '2023-06-03 22:45:19'),
(33, '173.252.79.119', '1', '17:45:20', '2023-06-03', '2023-06-03 22:45:20', '2023-06-03 22:45:20'),
(34, '103.230.104.36', '3', '20:45:37', '2023-06-03', '2023-06-04 01:45:07', '2023-06-04 01:45:37'),
(35, '74.208.2.151', '2', '10:02:51', '2023-06-04', '2023-06-04 15:02:44', '2023-06-04 15:02:51'),
(36, '74.208.2.141', '2', '10:02:49', '2023-06-04', '2023-06-04 15:02:46', '2023-06-04 15:02:49'),
(37, '74.208.2.131', '2', '10:02:57', '2023-06-04', '2023-06-04 15:02:50', '2023-06-04 15:02:57'),
(38, '74.208.2.171', '3', '10:02:56', '2023-06-04', '2023-06-04 15:02:53', '2023-06-04 15:02:56'),
(39, '74.208.2.161', '2', '10:02:58', '2023-06-04', '2023-06-04 15:02:54', '2023-06-04 15:02:58'),
(40, '103.232.100.205', '24', '18:59:59', '2023-06-04', '2023-06-04 15:14:02', '2023-06-04 23:59:59'),
(41, '45.127.245.82', '56', '15:14:09', '2023-06-04', '2023-06-04 16:56:16', '2023-06-04 20:14:09'),
(42, '37.111.214.138', '1', '14:03:46', '2023-06-04', '2023-06-04 19:03:46', '2023-06-04 19:03:46'),
(43, '66.102.6.245', '1', '15:15:09', '2023-06-04', '2023-06-04 20:15:09', '2023-06-04 20:15:09'),
(44, '66.102.6.241', '1', '15:15:10', '2023-06-04', '2023-06-04 20:15:10', '2023-06-04 20:15:10'),
(45, '188.43.68.132', '1', '15:15:12', '2023-06-04', '2023-06-04 20:15:12', '2023-06-04 20:15:12'),
(46, '66.249.89.213', '1', '15:15:13', '2023-06-04', '2023-06-04 20:15:13', '2023-06-04 20:15:13'),
(47, '66.249.89.211', '1', '15:15:14', '2023-06-04', '2023-06-04 20:15:14', '2023-06-04 20:15:14'),
(48, '62.149.104.132', '1', '15:15:14', '2023-06-04', '2023-06-04 20:15:14', '2023-06-04 20:15:14'),
(49, '69.63.189.117', '1', '18:05:54', '2023-06-04', '2023-06-04 23:05:54', '2023-06-04 23:05:54'),
(50, '69.171.249.9', '1', '21:36:43', '2023-06-04', '2023-06-05 02:36:43', '2023-06-05 02:36:43'),
(51, '45.127.245.82', '3', '14:19:04', '2023-06-05', '2023-06-05 19:07:56', '2023-06-05 19:19:04'),
(52, '173.252.79.18', '1', '21:34:28', '2023-06-05', '2023-06-06 02:34:28', '2023-06-06 02:34:28'),
(53, '173.252.107.24', '1', '21:50:57', '2023-06-05', '2023-06-06 02:50:57', '2023-06-06 02:50:57'),
(54, '27.147.205.147', '1', '23:56:13', '2023-06-05', '2023-06-06 04:56:13', '2023-06-06 04:56:13'),
(55, '103.127.5.181', '6', '14:06:33', '2023-06-06', '2023-06-06 18:51:30', '2023-06-06 19:06:33'),
(56, '40.77.167.231', '1', '16:38:26', '2023-06-06', '2023-06-06 21:38:26', '2023-06-06 21:38:26'),
(57, '103.232.100.205', '1', '12:38:12', '2023-06-07', '2023-06-07 17:38:12', '2023-06-07 17:38:12'),
(58, '103.232.100.205', '2', '11:25:16', '2023-06-08', '2023-06-08 16:24:13', '2023-06-08 16:25:16'),
(59, '103.179.128.138', '1', '11:25:27', '2023-06-08', '2023-06-08 16:25:27', '2023-06-08 16:25:27'),
(60, '157.55.39.213', '2', '23:22:21', '2023-06-08', '2023-06-09 00:59:47', '2023-06-09 04:22:21'),
(61, '223.178.83.108', '1', '21:47:11', '2023-06-09', '2023-06-10 02:47:11', '2023-06-10 02:47:11'),
(62, '52.167.144.49', '1', '06:57:47', '2023-06-12', '2023-06-12 11:57:47', '2023-06-12 11:57:47'),
(63, '52.167.144.81', '1', '17:35:26', '2023-06-12', '2023-06-12 22:35:26', '2023-06-12 22:35:26'),
(64, '173.252.83.1', '1', '18:23:58', '2023-06-12', '2023-06-12 23:23:58', '2023-06-12 23:23:58'),
(65, '173.252.83.22', '1', '18:23:58', '2023-06-12', '2023-06-12 23:23:58', '2023-06-12 23:23:58'),
(66, '66.249.66.73', '1', '18:28:48', '2023-06-12', '2023-06-12 23:28:48', '2023-06-12 23:28:48'),
(67, '40.117.185.219', '2', '04:57:30', '2023-06-13', '2023-06-13 09:42:56', '2023-06-13 09:57:30'),
(68, '178.62.82.141', '5', '07:16:38', '2023-06-13', '2023-06-13 12:16:35', '2023-06-13 12:16:38'),
(69, '52.167.144.20', '1', '15:59:26', '2023-06-13', '2023-06-13 20:59:26', '2023-06-13 20:59:26'),
(70, '149.56.150.251', '8', '23:05:12', '2023-06-13', '2023-06-14 04:05:05', '2023-06-14 04:05:12'),
(71, '52.167.144.48', '1', '04:48:15', '2023-06-14', '2023-06-14 09:48:15', '2023-06-14 09:48:15'),
(72, '157.55.39.220', '1', '14:27:09', '2023-06-14', '2023-06-14 19:27:09', '2023-06-14 19:27:09'),
(73, '45.127.245.82', '7', '15:51:01', '2023-06-14', '2023-06-14 20:43:37', '2023-06-14 20:51:01'),
(74, '5.188.62.21', '2', '18:25:36', '2023-06-14', '2023-06-14 23:25:15', '2023-06-14 23:25:36'),
(75, '66.249.66.72', '1', '21:43:14', '2023-06-14', '2023-06-15 02:43:14', '2023-06-15 02:43:14'),
(76, '103.55.146.208', '1', '01:50:21', '2023-06-15', '2023-06-15 06:50:21', '2023-06-15 06:50:21'),
(77, '173.252.83.19', '1', '08:57:32', '2023-06-15', '2023-06-15 13:57:32', '2023-06-15 13:57:32'),
(78, '45.127.245.82', '11', '16:57:16', '2023-06-15', '2023-06-15 21:45:28', '2023-06-15 21:57:16'),
(79, '66.249.64.200', '1', '22:21:26', '2023-06-15', '2023-06-16 03:21:26', '2023-06-16 03:21:26'),
(80, '51.158.104.74', '1', '06:13:26', '2023-06-16', '2023-06-16 11:13:26', '2023-06-16 11:13:26'),
(81, '51.15.132.144', '1', '06:13:38', '2023-06-16', '2023-06-16 11:13:38', '2023-06-16 11:13:38'),
(82, '212.47.251.123', '1', '06:13:41', '2023-06-16', '2023-06-16 11:13:41', '2023-06-16 11:13:41'),
(83, '163.172.138.70', '1', '06:13:56', '2023-06-16', '2023-06-16 11:13:56', '2023-06-16 11:13:56'),
(84, '51.158.73.116', '1', '06:14:03', '2023-06-16', '2023-06-16 11:14:03', '2023-06-16 11:14:03'),
(85, '51.15.253.73', '1', '06:14:06', '2023-06-16', '2023-06-16 11:14:06', '2023-06-16 11:14:06'),
(86, '163.172.135.200', '1', '06:14:41', '2023-06-16', '2023-06-16 11:14:41', '2023-06-16 11:14:41'),
(87, '51.158.100.94', '1', '06:14:52', '2023-06-16', '2023-06-16 11:14:52', '2023-06-16 11:14:52'),
(88, '51.15.254.22', '1', '06:14:59', '2023-06-16', '2023-06-16 11:14:59', '2023-06-16 11:14:59'),
(89, '51.15.198.172', '1', '06:15:12', '2023-06-16', '2023-06-16 11:15:12', '2023-06-16 11:15:12'),
(90, '163.172.169.131', '1', '06:15:21', '2023-06-16', '2023-06-16 11:15:21', '2023-06-16 11:15:21'),
(91, '212.47.252.158', '1', '06:16:12', '2023-06-16', '2023-06-16 11:16:12', '2023-06-16 11:16:12'),
(92, '212.47.245.58', '1', '06:16:21', '2023-06-16', '2023-06-16 11:16:21', '2023-06-16 11:16:21'),
(93, '51.158.111.206', '1', '06:17:11', '2023-06-16', '2023-06-16 11:17:11', '2023-06-16 11:17:11'),
(94, '51.158.115.147', '1', '06:17:16', '2023-06-16', '2023-06-16 11:17:16', '2023-06-16 11:17:16'),
(95, '163.172.165.102', '1', '06:17:53', '2023-06-16', '2023-06-16 11:17:53', '2023-06-16 11:17:53'),
(96, '163.172.129.20', '1', '06:20:09', '2023-06-16', '2023-06-16 11:20:09', '2023-06-16 11:20:09'),
(97, '15.204.182.106', '4', '08:01:25', '2023-06-16', '2023-06-16 12:54:34', '2023-06-16 13:01:25'),
(98, '66.249.66.163', '1', '00:41:59', '2023-06-17', '2023-06-17 05:41:59', '2023-06-17 05:41:59'),
(99, '40.77.167.124', '1', '20:56:34', '2023-06-17', '2023-06-18 01:56:34', '2023-06-18 01:56:34'),
(100, '66.249.66.163', '1', '01:01:28', '2023-06-18', '2023-06-18 06:01:28', '2023-06-18 06:01:28'),
(101, '20.15.133.166', '1', '04:46:03', '2023-06-18', '2023-06-18 09:46:03', '2023-06-18 09:46:03'),
(102, '207.46.13.220', '1', '06:23:26', '2023-06-18', '2023-06-18 11:23:26', '2023-06-18 11:23:26'),
(103, '207.46.13.212', '1', '20:43:22', '2023-06-18', '2023-06-19 01:43:22', '2023-06-19 01:43:22'),
(104, '66.249.66.164', '1', '04:39:29', '2023-06-19', '2023-06-19 09:39:29', '2023-06-19 09:39:29'),
(105, '40.77.167.215', '1', '09:17:29', '2023-06-19', '2023-06-19 14:17:29', '2023-06-19 14:17:29'),
(106, '27.147.202.175', '4', '13:04:17', '2023-06-19', '2023-06-19 18:01:28', '2023-06-19 18:04:17'),
(107, '45.127.245.82', '26', '17:18:28', '2023-06-19', '2023-06-19 18:21:29', '2023-06-19 22:18:28'),
(108, '66.249.66.164', '1', '05:55:45', '2023-06-20', '2023-06-20 10:55:45', '2023-06-20 10:55:45'),
(109, '43.255.113.232', '1', '06:12:59', '2023-06-20', '2023-06-20 11:12:59', '2023-06-20 11:12:59'),
(110, '27.147.202.175', '26', '15:54:13', '2023-06-20', '2023-06-20 15:38:12', '2023-06-20 20:54:13'),
(111, '160.202.147.6', '2', '10:40:44', '2023-06-20', '2023-06-20 15:40:42', '2023-06-20 15:40:44'),
(112, '103.15.42.68', '2', '10:40:48', '2023-06-20', '2023-06-20 15:40:46', '2023-06-20 15:40:48'),
(113, '45.127.245.82', '6', '15:53:50', '2023-06-20', '2023-06-20 18:51:42', '2023-06-20 20:53:50'),
(114, '174.138.50.75', '1', '03:10:09', '2023-06-21', '2023-06-21 08:10:09', '2023-06-21 08:10:09'),
(115, '134.122.103.248', '1', '05:59:45', '2023-06-21', '2023-06-21 10:59:45', '2023-06-21 10:59:45'),
(116, '66.249.66.163', '1', '07:51:19', '2023-06-21', '2023-06-21 12:51:19', '2023-06-21 12:51:19'),
(117, '52.167.144.85', '2', '12:21:42', '2023-06-21', '2023-06-21 13:08:28', '2023-06-21 17:21:42'),
(118, '157.245.64.106', '1', '08:10:04', '2023-06-21', '2023-06-21 13:10:04', '2023-06-21 13:10:04'),
(119, '143.110.166.75', '1', '08:46:00', '2023-06-21', '2023-06-21 13:46:00', '2023-06-21 13:46:00'),
(120, '161.35.23.44', '1', '09:01:42', '2023-06-21', '2023-06-21 14:01:42', '2023-06-21 14:01:42'),
(121, '165.227.44.97', '1', '09:05:22', '2023-06-21', '2023-06-21 14:05:22', '2023-06-21 14:05:22'),
(122, '157.245.71.172', '1', '09:40:42', '2023-06-21', '2023-06-21 14:40:42', '2023-06-21 14:40:42'),
(123, '164.92.202.204', '1', '09:42:10', '2023-06-21', '2023-06-21 14:42:10', '2023-06-21 14:42:10'),
(124, '27.147.202.175', '12', '15:25:32', '2023-06-21', '2023-06-21 14:46:08', '2023-06-21 20:25:32'),
(125, '165.227.42.13', '1', '09:57:02', '2023-06-21', '2023-06-21 14:57:02', '2023-06-21 14:57:02'),
(126, '106.222.132.90', '1', '11:58:28', '2023-06-21', '2023-06-21 16:58:28', '2023-06-21 16:58:28'),
(127, '45.127.245.82', '8', '15:12:54', '2023-06-21', '2023-06-21 17:16:22', '2023-06-21 20:12:54'),
(128, '37.111.217.105', '4', '13:39:57', '2023-06-21', '2023-06-21 18:23:56', '2023-06-21 18:39:57'),
(129, '40.77.167.91', '1', '14:24:51', '2023-06-21', '2023-06-21 19:24:51', '2023-06-21 19:24:51'),
(130, '103.136.159.237', '12', '16:20:53', '2023-06-21', '2023-06-21 21:02:24', '2023-06-21 21:20:53'),
(131, '119.30.32.226', '9', '17:25:21', '2023-06-21', '2023-06-21 21:05:38', '2023-06-21 22:25:21'),
(132, '66.249.66.163', '1', '08:42:00', '2023-06-22', '2023-06-22 13:42:00', '2023-06-22 13:42:00'),
(133, '45.127.245.82', '26', '15:46:21', '2023-06-22', '2023-06-22 17:14:46', '2023-06-22 20:46:21'),
(134, '27.147.202.175', '37', '20:09:13', '2023-06-22', '2023-06-22 23:50:12', '2023-06-23 01:09:13'),
(135, '203.76.223.6', '1', '18:53:52', '2023-06-22', '2023-06-22 23:53:52', '2023-06-22 23:53:52'),
(136, '167.172.33.39', '1', '08:22:21', '2023-06-23', '2023-06-23 13:22:21', '2023-06-23 13:22:21'),
(137, '66.249.77.164', '1', '10:49:16', '2023-06-23', '2023-06-23 15:49:16', '2023-06-23 15:49:16'),
(138, '174.138.56.139', '1', '13:24:09', '2023-06-23', '2023-06-23 18:24:09', '2023-06-23 18:24:09'),
(139, '137.184.189.81', '2', '20:52:59', '2023-06-23', '2023-06-23 21:14:59', '2023-06-24 01:52:59'),
(140, '137.184.189.88', '1', '17:25:08', '2023-06-23', '2023-06-23 22:25:08', '2023-06-23 22:25:08'),
(141, '173.252.83.4', '1', '17:57:42', '2023-06-23', '2023-06-23 22:57:42', '2023-06-23 22:57:42'),
(142, '78.138.99.182', '3', '03:39:36', '2023-06-24', '2023-06-24 08:39:35', '2023-06-24 08:39:36'),
(143, '167.172.37.255', '1', '08:28:49', '2023-06-24', '2023-06-24 13:28:49', '2023-06-24 13:28:49'),
(144, '137.184.189.81', '1', '08:48:31', '2023-06-24', '2023-06-24 13:48:31', '2023-06-24 13:48:31'),
(145, '27.147.202.175', '41', '10:13:08', '2023-06-24', '2023-06-24 14:28:09', '2023-06-24 15:13:08'),
(146, '66.249.74.41', '1', '11:05:24', '2023-06-24', '2023-06-24 16:05:24', '2023-06-24 16:05:24'),
(147, '45.127.245.82', '15', '13:29:45', '2023-06-24', '2023-06-24 17:56:36', '2023-06-24 18:29:45'),
(148, '137.184.189.103', '1', '14:58:32', '2023-06-24', '2023-06-24 19:58:32', '2023-06-24 19:58:32'),
(149, '161.35.27.165', '1', '15:29:04', '2023-06-24', '2023-06-24 20:29:04', '2023-06-24 20:29:04'),
(150, '164.92.202.75', '1', '20:49:32', '2023-06-24', '2023-06-25 01:49:32', '2023-06-25 01:49:32'),
(151, '174.138.58.62', '1', '03:14:43', '2023-06-25', '2023-06-25 08:14:43', '2023-06-25 08:14:43'),
(152, '167.71.2.63', '1', '07:31:40', '2023-06-25', '2023-06-25 12:31:40', '2023-06-25 12:31:40'),
(153, '137.184.189.105', '1', '08:38:40', '2023-06-25', '2023-06-25 13:38:40', '2023-06-25 13:38:40'),
(154, '27.147.202.175', '38', '12:28:16', '2023-06-25', '2023-06-25 16:26:57', '2023-06-25 17:28:16'),
(155, '167.71.12.89', '1', '12:07:55', '2023-06-25', '2023-06-25 17:07:55', '2023-06-25 17:07:55'),
(156, '66.249.66.164', '1', '12:22:14', '2023-06-25', '2023-06-25 17:22:14', '2023-06-25 17:22:14'),
(157, '202.134.14.147', '3', '16:55:18', '2023-06-25', '2023-06-25 21:55:11', '2023-06-25 21:55:18'),
(158, '202.134.10.142', '6', '17:11:17', '2023-06-25', '2023-06-25 22:10:25', '2023-06-25 22:11:17'),
(159, '40.77.167.91', '1', '04:51:24', '2023-06-26', '2023-06-26 09:51:24', '2023-06-26 09:51:24'),
(160, '165.227.238.36', '1', '09:08:45', '2023-06-26', '2023-06-26 14:08:45', '2023-06-26 14:08:45'),
(161, '66.249.66.164', '1', '13:37:15', '2023-06-26', '2023-06-26 18:37:15', '2023-06-26 18:37:15'),
(162, '164.92.124.235', '1', '14:52:37', '2023-06-26', '2023-06-26 19:52:37', '2023-06-26 19:52:37'),
(163, '27.147.202.175', '2', '17:11:34', '2023-06-26', '2023-06-26 22:11:06', '2023-06-26 22:11:34'),
(164, '165.22.72.218', '1', '18:07:29', '2023-06-26', '2023-06-26 23:07:29', '2023-06-26 23:07:29'),
(165, '40.77.167.157', '1', '18:20:15', '2023-06-26', '2023-06-26 23:20:15', '2023-06-26 23:20:15'),
(166, '45.127.245.82', '2', '19:14:44', '2023-06-26', '2023-06-27 00:12:44', '2023-06-27 00:14:44'),
(167, '40.117.185.219', '4', '04:34:43', '2023-06-27', '2023-06-27 08:57:54', '2023-06-27 09:34:43'),
(168, '206.189.123.243', '1', '05:38:45', '2023-06-27', '2023-06-27 10:38:45', '2023-06-27 10:38:45'),
(169, '157.245.71.172', '2', '17:11:04', '2023-06-27', '2023-06-27 12:30:48', '2023-06-27 22:11:04'),
(170, '66.249.66.164', '1', '15:07:39', '2023-06-27', '2023-06-27 20:07:39', '2023-06-27 20:07:39'),
(171, '40.77.167.222', '2', '17:16:41', '2023-06-27', '2023-06-27 22:12:00', '2023-06-27 22:16:41'),
(172, '164.92.200.223', '1', '00:15:55', '2023-06-28', '2023-06-28 05:15:55', '2023-06-28 05:15:55'),
(173, '45.127.245.82', '11', '12:41:58', '2023-06-28', '2023-06-28 17:00:14', '2023-06-28 17:41:58'),
(174, '163.53.140.69', '1', '12:00:17', '2023-06-28', '2023-06-28 17:00:17', '2023-06-28 17:00:17'),
(175, '165.22.72.79', '1', '22:44:41', '2023-06-28', '2023-06-29 03:44:41', '2023-06-29 03:44:41'),
(176, '50.21.188.90', '1', '05:04:13', '2023-06-29', '2023-06-29 10:04:13', '2023-06-29 10:04:13'),
(177, '191.101.209.153', '2', '11:42:15', '2023-06-29', '2023-06-29 16:42:14', '2023-06-29 16:42:15'),
(178, '66.249.74.40', '2', '20:37:35', '2023-06-29', '2023-06-29 16:55:56', '2023-06-30 01:37:35'),
(179, '66.249.74.42', '1', '12:18:11', '2023-06-29', '2023-06-29 17:18:11', '2023-06-29 17:18:11'),
(180, '161.35.35.161', '1', '21:22:12', '2023-06-29', '2023-06-30 02:22:12', '2023-06-30 02:22:12'),
(181, '52.167.144.171', '2', '22:39:31', '2023-06-29', '2023-06-30 02:43:57', '2023-06-30 03:39:31'),
(182, '207.46.13.213', '1', '05:49:04', '2023-06-30', '2023-06-30 10:49:04', '2023-06-30 10:49:04'),
(183, '134.122.44.189', '1', '11:27:22', '2023-06-30', '2023-06-30 16:27:22', '2023-06-30 16:27:22'),
(184, '66.249.74.42', '1', '12:46:11', '2023-06-30', '2023-06-30 17:46:11', '2023-06-30 17:46:11'),
(185, '66.249.74.40', '1', '13:30:45', '2023-06-30', '2023-06-30 18:30:45', '2023-06-30 18:30:45'),
(186, '66.249.74.41', '1', '14:37:35', '2023-06-30', '2023-06-30 19:37:35', '2023-06-30 19:37:35'),
(187, '40.77.167.138', '1', '16:13:03', '2023-06-30', '2023-06-30 21:13:03', '2023-06-30 21:13:03'),
(188, '40.77.167.138', '1', '06:12:09', '2023-07-01', '2023-07-01 11:12:09', '2023-07-01 11:12:09'),
(189, '66.249.66.72', '1', '09:51:41', '2023-07-01', '2023-07-01 14:51:41', '2023-07-01 14:51:41'),
(190, '66.249.66.163', '1', '15:04:31', '2023-07-01', '2023-07-01 20:04:31', '2023-07-01 20:04:31'),
(191, '161.35.65.21', '1', '15:42:04', '2023-07-01', '2023-07-01 20:42:04', '2023-07-01 20:42:04'),
(192, '134.122.97.159', '1', '16:03:07', '2023-07-01', '2023-07-01 21:03:07', '2023-07-01 21:03:07'),
(193, '174.138.50.190', '1', '19:47:37', '2023-07-01', '2023-07-02 00:47:37', '2023-07-02 00:47:37'),
(194, '66.249.66.10', '1', '00:56:23', '2023-07-02', '2023-07-02 05:56:23', '2023-07-02 05:56:23'),
(195, '137.184.189.105', '1', '03:25:23', '2023-07-02', '2023-07-02 08:25:23', '2023-07-02 08:25:23'),
(196, '66.249.66.163', '1', '09:02:23', '2023-07-02', '2023-07-02 14:02:23', '2023-07-02 14:02:23'),
(197, '66.249.66.165', '1', '16:02:53', '2023-07-02', '2023-07-02 21:02:53', '2023-07-02 21:02:53'),
(198, '174.138.60.28', '1', '02:24:25', '2023-07-03', '2023-07-03 07:24:25', '2023-07-03 07:24:25'),
(199, '165.22.72.218', '1', '04:55:05', '2023-07-03', '2023-07-03 09:55:05', '2023-07-03 09:55:05'),
(200, '157.55.39.213', '1', '08:07:59', '2023-07-03', '2023-07-03 13:07:59', '2023-07-03 13:07:59'),
(201, '40.77.167.163', '1', '16:52:25', '2023-07-03', '2023-07-03 21:52:25', '2023-07-03 21:52:25'),
(202, '66.249.66.164', '1', '17:48:25', '2023-07-03', '2023-07-03 22:48:25', '2023-07-03 22:48:25'),
(203, '5.78.75.151', '1', '18:56:02', '2023-07-03', '2023-07-03 23:56:02', '2023-07-03 23:56:02'),
(204, '206.189.119.247', '1', '19:47:23', '2023-07-03', '2023-07-04 00:47:23', '2023-07-04 00:47:23'),
(205, '161.35.31.20', '1', '19:57:04', '2023-07-03', '2023-07-04 00:57:04', '2023-07-04 00:57:04'),
(206, '5.78.41.21', '1', '21:14:34', '2023-07-03', '2023-07-04 02:14:34', '2023-07-04 02:14:34'),
(207, '164.92.124.235', '1', '21:46:33', '2023-07-03', '2023-07-04 02:46:33', '2023-07-04 02:46:33'),
(208, '157.245.64.106', '1', '23:43:43', '2023-07-03', '2023-07-04 04:43:43', '2023-07-04 04:43:43'),
(209, '137.184.189.104', '1', '04:18:12', '2023-07-04', '2023-07-04 09:18:12', '2023-07-04 09:18:12'),
(210, '134.122.44.126', '1', '07:28:17', '2023-07-04', '2023-07-04 12:28:17', '2023-07-04 12:28:17'),
(211, '45.127.245.82', '21', '18:48:40', '2023-07-04', '2023-07-04 17:10:05', '2023-07-04 23:48:40'),
(212, '173.252.83.120', '1', '15:34:05', '2023-07-04', '2023-07-04 20:34:05', '2023-07-04 20:34:05'),
(213, '173.252.83.1', '1', '15:34:05', '2023-07-04', '2023-07-04 20:34:05', '2023-07-04 20:34:05'),
(214, '174.138.50.190', '1', '15:57:44', '2023-07-04', '2023-07-04 20:57:44', '2023-07-04 20:57:44'),
(215, '66.249.77.163', '1', '18:42:30', '2023-07-04', '2023-07-04 23:42:30', '2023-07-04 23:42:30'),
(216, '66.249.77.164', '1', '23:47:18', '2023-07-04', '2023-07-05 04:47:18', '2023-07-05 04:47:18'),
(217, '103.46.202.20', '3', '00:21:30', '2023-07-05', '2023-07-05 05:16:42', '2023-07-05 05:21:30'),
(218, '164.92.124.235', '1', '01:40:50', '2023-07-05', '2023-07-05 06:40:50', '2023-07-05 06:40:50'),
(219, '20.15.133.170', '1', '10:12:20', '2023-07-05', '2023-07-05 15:12:20', '2023-07-05 15:12:20'),
(220, '40.77.167.163', '1', '12:33:53', '2023-07-05', '2023-07-05 17:33:53', '2023-07-05 17:33:53'),
(221, '45.127.245.82', '34', '21:45:25', '2023-07-05', '2023-07-05 20:28:58', '2023-07-06 02:45:25'),
(222, '72.14.201.159', '1', '19:21:15', '2023-07-05', '2023-07-06 00:21:15', '2023-07-06 00:21:15'),
(223, '27.147.202.175', '15', '17:00:14', '2023-07-06', '2023-07-06 18:56:34', '2023-07-06 22:00:14'),
(224, '66.249.64.200', '1', '14:51:21', '2023-07-06', '2023-07-06 19:51:21', '2023-07-06 19:51:21'),
(225, '66.249.64.201', '1', '14:51:22', '2023-07-06', '2023-07-06 19:51:22', '2023-07-06 19:51:22'),
(226, '66.249.64.202', '1', '18:57:47', '2023-07-06', '2023-07-06 23:57:47', '2023-07-06 23:57:47'),
(227, '40.77.167.163', '1', '10:08:00', '2023-07-07', '2023-07-07 15:08:00', '2023-07-07 15:08:00'),
(228, '52.167.144.167', '1', '10:10:48', '2023-07-07', '2023-07-07 15:10:48', '2023-07-07 15:10:48'),
(229, '40.77.167.156', '2', '04:42:11', '2023-07-08', '2023-07-08 05:48:09', '2023-07-08 09:42:11'),
(230, '45.127.245.82', '17', '13:46:39', '2023-07-08', '2023-07-08 16:23:32', '2023-07-08 18:46:39'),
(231, '66.249.64.202', '1', '11:30:25', '2023-07-08', '2023-07-08 16:30:25', '2023-07-08 16:30:25'),
(232, '52.167.144.167', '2', '21:01:31', '2023-07-09', '2023-07-09 10:35:29', '2023-07-10 02:01:31'),
(233, '86.106.74.250', '3', '10:10:47', '2023-07-09', '2023-07-09 15:10:46', '2023-07-09 15:10:47'),
(234, '45.127.245.82', '10', '17:01:21', '2023-07-09', '2023-07-09 17:23:46', '2023-07-09 22:01:21'),
(235, '40.77.167.156', '1', '17:41:51', '2023-07-09', '2023-07-09 22:41:51', '2023-07-09 22:41:51'),
(236, '14.169.180.158', '1', '23:02:04', '2023-07-09', '2023-07-10 04:02:04', '2023-07-10 04:02:04'),
(237, '52.167.144.167', '2', '15:22:53', '2023-07-10', '2023-07-10 08:25:17', '2023-07-10 20:22:53'),
(238, '66.249.64.204', '1', '10:01:11', '2023-07-10', '2023-07-10 15:01:11', '2023-07-10 15:01:11'),
(239, '45.127.245.82', '2', '11:42:58', '2023-07-10', '2023-07-10 16:42:58', '2023-07-10 16:42:58'),
(240, '52.167.144.167', '1', '03:19:10', '2023-07-11', '2023-07-11 08:19:10', '2023-07-11 08:19:10'),
(241, '40.77.167.156', '1', '09:05:52', '2023-07-11', '2023-07-11 14:05:52', '2023-07-11 14:05:52'),
(242, '143.110.156.182', '1', '11:04:31', '2023-07-11', '2023-07-11 16:04:31', '2023-07-11 16:04:31'),
(243, '192.53.126.23', '1', '11:04:33', '2023-07-11', '2023-07-11 16:04:33', '2023-07-11 16:04:33'),
(244, '104.164.173.123', '9', '11:25:44', '2023-07-11', '2023-07-11 16:25:43', '2023-07-11 16:25:44'),
(245, '37.111.210.176', '1', '13:22:07', '2023-07-11', '2023-07-11 18:22:07', '2023-07-11 18:22:07'),
(246, '40.77.167.163', '1', '01:39:41', '2023-07-12', '2023-07-12 06:39:41', '2023-07-12 06:39:41'),
(247, '45.127.245.82', '1', '11:33:53', '2023-07-12', '2023-07-12 16:33:53', '2023-07-12 16:33:53'),
(248, '40.77.167.156', '1', '11:46:53', '2023-07-12', '2023-07-12 16:46:53', '2023-07-12 16:46:53'),
(249, '27.147.202.175', '19', '15:39:53', '2023-07-12', '2023-07-12 17:01:19', '2023-07-12 20:39:53'),
(250, '66.249.64.204', '1', '05:39:57', '2023-07-13', '2023-07-13 10:39:57', '2023-07-13 10:39:57'),
(251, '184.94.240.88', '1', '09:22:53', '2023-07-13', '2023-07-13 14:22:53', '2023-07-13 14:22:53'),
(252, '27.147.202.175', '9', '17:50:56', '2023-07-13', '2023-07-13 20:08:01', '2023-07-13 22:50:56'),
(253, '45.127.245.82', '7', '17:39:45', '2023-07-13', '2023-07-13 22:11:54', '2023-07-13 22:39:45'),
(254, '27.147.205.147', '1', '23:43:07', '2023-07-13', '2023-07-14 04:43:07', '2023-07-14 04:43:07'),
(255, '184.94.240.88', '1', '01:47:54', '2023-07-14', '2023-07-14 06:47:54', '2023-07-14 06:47:54'),
(256, '149.56.150.187', '8', '08:12:24', '2023-07-14', '2023-07-14 13:12:17', '2023-07-14 13:12:24'),
(257, '157.55.39.253', '2', '20:55:57', '2023-07-14', '2023-07-14 21:18:40', '2023-07-15 01:55:57'),
(258, '66.249.64.225', '1', '23:24:29', '2023-07-14', '2023-07-15 04:24:29', '2023-07-15 04:24:29'),
(259, '52.167.144.68', '1', '03:57:38', '2023-07-15', '2023-07-15 08:57:38', '2023-07-15 08:57:38'),
(260, '45.127.245.82', '4', '11:15:25', '2023-07-15', '2023-07-15 15:52:02', '2023-07-15 16:15:25'),
(261, '45.127.247.3', '3', '10:56:03', '2023-07-15', '2023-07-15 15:55:22', '2023-07-15 15:56:03'),
(262, '103.49.114.220', '1', '12:10:03', '2023-07-15', '2023-07-15 17:10:03', '2023-07-15 17:10:03'),
(263, '172.58.27.123', '1', '12:15:10', '2023-07-15', '2023-07-15 17:15:10', '2023-07-15 17:15:10'),
(264, '119.30.39.102', '1', '12:27:52', '2023-07-15', '2023-07-15 17:27:52', '2023-07-15 17:27:52'),
(265, '86.97.80.21', '3', '12:35:34', '2023-07-15', '2023-07-15 17:35:09', '2023-07-15 17:35:34'),
(266, '151.192.177.237', '5', '13:15:30', '2023-07-15', '2023-07-15 18:00:02', '2023-07-15 18:15:30'),
(267, '37.111.242.18', '2', '13:07:38', '2023-07-15', '2023-07-15 18:06:30', '2023-07-15 18:07:38'),
(268, '58.182.140.132', '3', '13:08:58', '2023-07-15', '2023-07-15 18:07:33', '2023-07-15 18:08:58'),
(269, '37.19.223.104', '3', '15:44:13', '2023-07-15', '2023-07-15 20:44:12', '2023-07-15 20:44:13'),
(270, '181.214.218.248', '3', '17:53:50', '2023-07-15', '2023-07-15 22:53:49', '2023-07-15 22:53:50'),
(271, '27.147.202.175', '2', '18:42:11', '2023-07-15', '2023-07-15 23:41:32', '2023-07-15 23:42:11'),
(272, '66.249.64.202', '1', '02:05:55', '2023-07-16', '2023-07-16 07:05:55', '2023-07-16 07:05:55'),
(273, '37.111.203.42', '3', '12:45:57', '2023-07-16', '2023-07-16 17:39:39', '2023-07-16 17:45:57'),
(274, '27.147.202.175', '13', '12:46:30', '2023-07-16', '2023-07-16 17:43:57', '2023-07-16 17:46:30'),
(275, '43.250.82.230', '2', '12:44:19', '2023-07-16', '2023-07-16 17:44:16', '2023-07-16 17:44:19'),
(276, '103.144.200.168', '5', '12:59:03', '2023-07-16', '2023-07-16 17:55:29', '2023-07-16 17:59:03'),
(277, '52.167.144.68', '1', '20:24:17', '2023-07-16', '2023-07-17 01:24:17', '2023-07-17 01:24:17'),
(278, '37.19.223.122', '3', '23:25:42', '2023-07-16', '2023-07-17 04:25:41', '2023-07-17 04:25:42'),
(279, '173.252.87.3', '1', '23:31:14', '2023-07-16', '2023-07-17 04:31:14', '2023-07-17 04:31:14'),
(280, '173.252.87.117', '1', '23:31:14', '2023-07-16', '2023-07-17 04:31:14', '2023-07-17 04:31:14'),
(281, '45.127.245.82', '9', '11:32:42', '2023-07-17', '2023-07-17 16:28:52', '2023-07-17 16:32:42'),
(282, '15.204.182.106', '3', '15:38:33', '2023-07-17', '2023-07-17 20:30:15', '2023-07-17 20:38:33'),
(283, '15.204.182.106', '1', '15:30:15', '2023-07-17', '2023-07-17 20:30:15', '2023-07-17 20:30:15'),
(284, '139.144.120.47', '28', '04:13:32', '2023-07-18', '2023-07-18 09:08:09', '2023-07-18 09:13:32'),
(285, '103.228.202.61', '1', '11:17:56', '2023-07-18', '2023-07-18 16:17:56', '2023-07-18 16:17:56'),
(286, '45.127.245.82', '33', '15:47:08', '2023-07-18', '2023-07-18 17:53:11', '2023-07-18 20:47:08'),
(287, '27.147.202.175', '63', '18:31:06', '2023-07-18', '2023-07-18 17:56:09', '2023-07-18 23:31:06'),
(288, '114.31.31.69', '1', '12:56:30', '2023-07-18', '2023-07-18 17:56:30', '2023-07-18 17:56:30'),
(289, '103.15.244.134', '2', '12:56:49', '2023-07-18', '2023-07-18 17:56:47', '2023-07-18 17:56:49'),
(290, '37.111.210.123', '2', '15:10:23', '2023-07-18', '2023-07-18 20:10:13', '2023-07-18 20:10:23'),
(291, '103.113.152.14', '1', '15:45:38', '2023-07-18', '2023-07-18 20:45:38', '2023-07-18 20:45:38'),
(292, '66.249.65.232', '1', '15:53:10', '2023-07-18', '2023-07-18 20:53:10', '2023-07-18 20:53:10'),
(293, '103.124.226.26', '1', '14:49:27', '2023-07-19', '2023-07-19 19:49:27', '2023-07-19 19:49:27'),
(294, '45.127.245.82', '2', '19:52:24', '2023-07-20', '2023-07-21 00:52:11', '2023-07-21 00:52:24'),
(295, '37.111.214.85', '5', '20:03:54', '2023-07-20', '2023-07-21 01:02:07', '2023-07-21 01:03:54'),
(296, '66.249.74.45', '1', '20:49:03', '2023-07-20', '2023-07-21 01:49:03', '2023-07-21 01:49:03'),
(297, '40.77.167.156', '1', '02:09:26', '2023-07-21', '2023-07-21 07:09:26', '2023-07-21 07:09:26'),
(298, '68.146.144.13', '1', '06:42:24', '2023-07-21', '2023-07-21 11:42:24', '2023-07-21 11:42:24'),
(299, '45.127.245.82', '7', '15:36:19', '2023-07-21', '2023-07-21 20:34:02', '2023-07-21 20:36:19'),
(300, '40.77.167.196', '1', '02:40:14', '2023-07-22', '2023-07-22 07:40:14', '2023-07-22 07:40:14'),
(301, '103.197.50.9', '2', '02:51:12', '2023-07-22', '2023-07-22 07:50:47', '2023-07-22 07:51:12'),
(302, '103.73.197.34', '3', '01:04:09', '2023-07-23', '2023-07-23 06:03:26', '2023-07-23 06:04:09'),
(303, '213.168.210.76', '2', '03:56:19', '2023-07-23', '2023-07-23 08:56:02', '2023-07-23 08:56:19'),
(304, '52.167.144.70', '1', '10:18:25', '2023-07-23', '2023-07-23 15:18:25', '2023-07-23 15:18:25'),
(305, '27.147.202.175', '6', '15:38:40', '2023-07-23', '2023-07-23 19:47:16', '2023-07-23 20:38:40'),
(306, '20.15.133.177', '1', '03:11:06', '2023-07-24', '2023-07-24 08:11:06', '2023-07-24 08:11:06'),
(307, '74.208.2.178', '4', '04:41:00', '2023-07-24', '2023-07-24 09:40:49', '2023-07-24 09:41:00'),
(308, '74.208.2.148', '1', '04:40:50', '2023-07-24', '2023-07-24 09:40:50', '2023-07-24 09:40:50'),
(309, '74.208.2.168', '2', '04:40:53', '2023-07-24', '2023-07-24 09:40:52', '2023-07-24 09:40:53'),
(310, '74.208.2.138', '2', '04:40:59', '2023-07-24', '2023-07-24 09:40:57', '2023-07-24 09:40:59'),
(311, '69.160.160.52', '9', '08:02:29', '2023-07-24', '2023-07-24 13:02:27', '2023-07-24 13:02:29'),
(312, '27.147.202.175', '12', '19:28:10', '2023-07-24', '2023-07-25 00:16:08', '2023-07-25 00:28:10'),
(313, '84.17.60.102', '2', '07:28:10', '2023-07-27', '2023-07-27 12:28:09', '2023-07-27 12:28:10'),
(314, '40.77.167.196', '1', '08:43:04', '2023-07-27', '2023-07-27 13:43:04', '2023-07-27 13:43:04'),
(315, '84.17.47.21', '3', '13:09:57', '2023-07-27', '2023-07-27 18:09:56', '2023-07-27 18:09:57'),
(316, '45.127.245.82', '35', '20:11:42', '2023-07-27', '2023-07-27 20:23:48', '2023-07-28 01:11:42'),
(317, '173.252.83.1', '1', '00:14:08', '2023-07-28', '2023-07-28 05:14:08', '2023-07-28 05:14:08'),
(318, '173.252.83.119', '1', '00:14:08', '2023-07-28', '2023-07-28 05:14:08', '2023-07-28 05:14:08'),
(319, '52.167.144.26', '1', '04:33:56', '2023-07-29', '2023-07-29 09:33:56', '2023-07-29 09:33:56'),
(320, '27.147.202.175', '7', '17:28:09', '2023-07-29', '2023-07-29 21:59:16', '2023-07-29 22:28:09'),
(321, '27.147.202.175', '24', '12:22:42', '2023-07-30', '2023-07-30 14:46:33', '2023-07-30 17:22:42'),
(322, '103.15.42.196', '1', '09:46:38', '2023-07-30', '2023-07-30 14:46:38', '2023-07-30 14:46:38'),
(323, '45.127.245.82', '53', '18:27:38', '2023-07-30', '2023-07-30 17:21:40', '2023-07-30 23:27:38'),
(324, '142.93.149.179', '1', '21:22:29', '2023-07-30', '2023-07-31 02:22:29', '2023-07-31 02:22:29'),
(325, '5.161.209.105', '1', '01:36:09', '2023-07-31', '2023-07-31 06:36:09', '2023-07-31 06:36:09'),
(326, '146.190.79.184', '1', '02:53:31', '2023-07-31', '2023-07-31 07:53:31', '2023-07-31 07:53:31'),
(327, '66.249.66.139', '1', '03:45:14', '2023-07-31', '2023-07-31 08:45:14', '2023-07-31 08:45:14'),
(328, '142.93.149.179', '1', '04:18:34', '2023-07-31', '2023-07-31 09:18:34', '2023-07-31 09:18:34'),
(329, '143.198.43.36', '1', '04:23:54', '2023-07-31', '2023-07-31 09:23:54', '2023-07-31 09:23:54'),
(330, '66.249.66.165', '1', '05:44:31', '2023-07-31', '2023-07-31 10:44:31', '2023-07-31 10:44:31'),
(331, '72.13.46.5', '2', '07:27:43', '2023-07-31', '2023-07-31 12:27:42', '2023-07-31 12:27:43'),
(332, '52.167.144.66', '1', '08:56:40', '2023-07-31', '2023-07-31 13:56:40', '2023-07-31 13:56:40'),
(333, '24.199.87.36', '1', '14:28:17', '2023-07-31', '2023-07-31 19:28:17', '2023-07-31 19:28:17'),
(334, '45.127.245.82', '3', '19:03:39', '2023-07-31', '2023-07-31 19:43:07', '2023-08-01 00:03:39'),
(335, '66.249.66.163', '1', '16:08:39', '2023-07-31', '2023-07-31 21:08:39', '2023-07-31 21:08:39'),
(336, '27.147.202.175', '5', '16:28:18', '2023-07-31', '2023-07-31 21:27:22', '2023-07-31 21:28:18'),
(337, '138.68.174.16', '1', '18:55:46', '2023-07-31', '2023-07-31 23:55:46', '2023-07-31 23:55:46'),
(338, '65.109.128.242', '1', '20:12:43', '2023-07-31', '2023-08-01 01:12:43', '2023-08-01 01:12:43'),
(339, '159.223.201.55', '1', '20:33:25', '2023-07-31', '2023-08-01 01:33:25', '2023-08-01 01:33:25'),
(340, '135.181.194.43', '1', '20:33:58', '2023-07-31', '2023-08-01 01:33:58', '2023-08-01 01:33:58'),
(341, '138.197.140.228', '1', '20:48:44', '2023-07-31', '2023-08-01 01:48:44', '2023-08-01 01:48:44'),
(342, '103.55.146.212', '4', '21:57:50', '2023-07-31', '2023-08-01 02:52:39', '2023-08-01 02:57:50'),
(343, '95.217.1.184', '1', '01:57:42', '2023-08-01', '2023-08-01 06:57:42', '2023-08-01 06:57:42'),
(344, '167.71.254.228', '1', '02:20:21', '2023-08-01', '2023-08-01 07:20:21', '2023-08-01 07:20:21'),
(345, '46.101.80.123', '1', '02:54:55', '2023-08-01', '2023-08-01 07:54:55', '2023-08-01 07:54:55'),
(346, '37.27.0.243', '1', '06:12:29', '2023-08-01', '2023-08-01 11:12:29', '2023-08-01 11:12:29'),
(347, '40.77.167.196', '1', '08:36:56', '2023-08-01', '2023-08-01 13:36:56', '2023-08-01 13:36:56'),
(348, '27.147.202.175', '7', '11:41:40', '2023-08-01', '2023-08-01 16:19:28', '2023-08-01 16:41:40'),
(349, '159.223.193.57', '1', '12:08:36', '2023-08-01', '2023-08-01 17:08:36', '2023-08-01 17:08:36'),
(350, '45.127.245.82', '5', '12:22:40', '2023-08-01', '2023-08-01 17:10:09', '2023-08-01 17:22:40'),
(351, '37.111.214.5', '5', '14:07:45', '2023-08-01', '2023-08-01 19:03:52', '2023-08-01 19:07:45'),
(352, '159.223.197.178', '1', '16:00:38', '2023-08-01', '2023-08-01 21:00:38', '2023-08-01 21:00:38'),
(353, '37.27.3.212', '1', '03:06:22', '2023-08-02', '2023-08-02 08:06:22', '2023-08-02 08:06:22'),
(354, '46.101.93.233', '1', '03:31:00', '2023-08-02', '2023-08-02 08:31:00', '2023-08-02 08:31:00'),
(355, '95.217.130.175', '1', '08:51:07', '2023-08-02', '2023-08-02 13:51:07', '2023-08-02 13:51:07'),
(356, '159.223.193.196', '1', '13:07:10', '2023-08-02', '2023-08-02 18:07:10', '2023-08-02 18:07:10'),
(357, '45.127.245.82', '53', '17:34:56', '2023-08-02', '2023-08-02 18:12:36', '2023-08-02 22:34:56'),
(358, '24.199.87.70', '1', '18:45:58', '2023-08-02', '2023-08-02 23:45:58', '2023-08-02 23:45:58'),
(359, '24.199.125.15', '1', '01:34:01', '2023-08-03', '2023-08-03 06:34:01', '2023-08-03 06:34:01'),
(360, '109.122.221.11', '1', '02:16:53', '2023-08-03', '2023-08-03 07:16:53', '2023-08-03 07:16:53'),
(361, '24.199.117.246', '1', '04:44:01', '2023-08-03', '2023-08-03 09:44:01', '2023-08-03 09:44:01'),
(362, '37.111.219.171', '2', '12:45:01', '2023-08-03', '2023-08-03 17:44:53', '2023-08-03 17:45:01'),
(363, '5.161.194.92', '1', '15:40:40', '2023-08-03', '2023-08-03 20:40:40', '2023-08-03 20:40:40'),
(364, '167.71.241.14', '1', '17:15:12', '2023-08-03', '2023-08-03 22:15:12', '2023-08-03 22:15:12'),
(365, '24.199.101.189', '1', '18:00:21', '2023-08-03', '2023-08-03 23:00:21', '2023-08-03 23:00:21'),
(366, '45.127.245.82', '8', '18:41:10', '2023-08-03', '2023-08-03 23:10:21', '2023-08-03 23:41:10'),
(367, '161.35.43.156', '1', '03:24:21', '2023-08-04', '2023-08-04 08:24:21', '2023-08-04 08:24:21'),
(368, '95.217.155.224', '1', '04:27:49', '2023-08-04', '2023-08-04 09:27:49', '2023-08-04 09:27:49'),
(369, '165.22.233.4', '1', '15:29:31', '2023-08-04', '2023-08-04 20:29:31', '2023-08-04 20:29:31'),
(370, '146.190.79.183', '1', '22:44:11', '2023-08-04', '2023-08-05 03:44:11', '2023-08-05 03:44:11'),
(371, '165.22.237.57', '1', '01:17:22', '2023-08-05', '2023-08-05 06:17:22', '2023-08-05 06:17:22'),
(372, '159.223.193.57', '1', '01:51:25', '2023-08-05', '2023-08-05 06:51:25', '2023-08-05 06:51:25'),
(373, '167.71.241.14', '1', '08:53:12', '2023-08-05', '2023-08-05 13:53:12', '2023-08-05 13:53:12'),
(374, '52.167.144.26', '2', '11:47:05', '2023-08-05', '2023-08-05 16:43:57', '2023-08-05 16:47:05'),
(375, '138.197.112.12', '1', '14:30:53', '2023-08-05', '2023-08-05 19:30:53', '2023-08-05 19:30:53'),
(376, '45.127.245.82', '16', '14:48:17', '2023-08-05', '2023-08-05 19:42:18', '2023-08-05 19:48:17'),
(377, '167.71.241.6', '1', '15:50:10', '2023-08-05', '2023-08-05 20:50:10', '2023-08-05 20:50:10'),
(378, '66.249.74.40', '1', '00:55:54', '2023-08-06', '2023-08-06 05:55:54', '2023-08-06 05:55:54'),
(379, '66.249.74.42', '1', '01:15:54', '2023-08-06', '2023-08-06 06:15:54', '2023-08-06 06:15:54'),
(380, '24.199.125.18', '1', '09:35:26', '2023-08-06', '2023-08-06 14:35:26', '2023-08-06 14:35:26'),
(381, '49.37.99.87', '1', '13:27:44', '2023-08-06', '2023-08-06 18:27:44', '2023-08-06 18:27:44'),
(382, '24.199.117.238', '1', '15:37:00', '2023-08-06', '2023-08-06 20:37:00', '2023-08-06 20:37:00'),
(383, '40.83.2.76', '2', '18:50:12', '2023-08-06', '2023-08-06 23:50:01', '2023-08-06 23:50:12'),
(384, '178.62.218.31', '1', '21:53:40', '2023-08-06', '2023-08-07 02:53:40', '2023-08-07 02:53:40'),
(385, '52.167.144.26', '1', '23:38:26', '2023-08-06', '2023-08-07 04:38:26', '2023-08-07 04:38:26'),
(386, '34.140.112.115', '48', '05:12:50', '2023-08-07', '2023-08-07 10:10:21', '2023-08-07 10:12:50'),
(387, '163.172.24.191', '1', '09:12:27', '2023-08-07', '2023-08-07 14:12:27', '2023-08-07 14:12:27'),
(388, '159.223.201.55', '1', '13:35:24', '2023-08-07', '2023-08-07 18:35:24', '2023-08-07 18:35:24'),
(389, '52.167.144.26', '1', '17:59:40', '2023-08-07', '2023-08-07 22:59:40', '2023-08-07 22:59:40'),
(390, '142.93.153.208', '1', '23:58:11', '2023-08-07', '2023-08-08 04:58:11', '2023-08-08 04:58:11'),
(391, '5.9.55.228', '23', '02:44:50', '2023-08-08', '2023-08-08 06:39:14', '2023-08-08 07:44:50'),
(392, '24.199.117.246', '1', '06:20:29', '2023-08-08', '2023-08-08 11:20:29', '2023-08-08 11:20:29'),
(393, '24.199.87.48', '1', '15:32:55', '2023-08-08', '2023-08-08 20:32:55', '2023-08-08 20:32:55'),
(394, '45.127.245.82', '5', '16:34:37', '2023-08-08', '2023-08-08 21:32:55', '2023-08-08 21:34:37'),
(395, '64.225.69.111', '1', '19:17:22', '2023-08-08', '2023-08-09 00:17:22', '2023-08-09 00:17:22'),
(396, '173.252.83.120', '1', '19:19:38', '2023-08-08', '2023-08-09 00:19:38', '2023-08-09 00:19:38'),
(397, '173.252.83.111', '1', '19:19:39', '2023-08-08', '2023-08-09 00:19:39', '2023-08-09 00:19:39'),
(398, '178.62.210.67', '1', '00:11:13', '2023-08-09', '2023-08-09 05:11:13', '2023-08-09 05:11:13'),
(399, '181.214.218.145', '3', '08:02:08', '2023-08-09', '2023-08-09 13:02:07', '2023-08-09 13:02:08'),
(400, '159.223.201.55', '1', '12:23:49', '2023-08-09', '2023-08-09 17:23:49', '2023-08-09 17:23:49'),
(401, '146.190.141.5', '1', '14:10:41', '2023-08-09', '2023-08-09 19:10:41', '2023-08-09 19:10:41'),
(402, '45.127.245.82', '3', '15:52:15', '2023-08-09', '2023-08-09 20:45:28', '2023-08-09 20:52:15'),
(403, '52.167.144.80', '1', '16:14:46', '2023-08-09', '2023-08-09 21:14:46', '2023-08-09 21:14:46'),
(404, '135.181.47.105', '1', '03:16:38', '2023-08-10', '2023-08-10 08:16:38', '2023-08-10 08:16:38'),
(405, '65.109.172.245', '1', '03:31:43', '2023-08-10', '2023-08-10 08:31:43', '2023-08-10 08:31:43'),
(406, '37.19.223.117', '3', '05:38:49', '2023-08-10', '2023-08-10 10:38:46', '2023-08-10 10:38:49'),
(407, '40.77.167.196', '1', '17:51:58', '2023-08-10', '2023-08-10 22:51:58', '2023-08-10 22:51:58'),
(408, '24.199.99.134', '1', '21:25:47', '2023-08-10', '2023-08-11 02:25:47', '2023-08-11 02:25:47'),
(409, '178.62.82.141', '5', '23:34:22', '2023-08-10', '2023-08-11 04:34:19', '2023-08-11 04:34:22'),
(410, '52.167.144.89', '1', '01:19:25', '2023-08-11', '2023-08-11 06:19:25', '2023-08-11 06:19:25'),
(411, '5.188.62.21', '2', '01:45:18', '2023-08-11', '2023-08-11 06:44:36', '2023-08-11 06:45:18'),
(412, '165.227.110.161', '1', '01:45:01', '2023-08-11', '2023-08-11 06:45:01', '2023-08-11 06:45:01'),
(413, '52.167.144.223', '1', '04:32:51', '2023-08-11', '2023-08-11 09:32:51', '2023-08-11 09:32:51'),
(414, '138.197.136.39', '1', '05:55:23', '2023-08-11', '2023-08-11 10:55:23', '2023-08-11 10:55:23'),
(415, '50.19.32.43', '1', '12:52:49', '2023-08-11', '2023-08-11 17:52:49', '2023-08-11 17:52:49'),
(416, '173.252.83.9', '1', '19:12:56', '2023-08-11', '2023-08-12 00:12:56', '2023-08-12 00:12:56'),
(417, '103.94.135.12', '1', '10:03:14', '2023-08-12', '2023-08-12 15:03:14', '2023-08-12 15:03:14'),
(418, '45.127.245.82', '38', '18:29:10', '2023-08-12', '2023-08-12 22:57:42', '2023-08-12 23:29:10'),
(419, '45.127.245.82', '52', '21:15:38', '2023-08-13', '2023-08-13 16:59:48', '2023-08-14 02:15:38'),
(420, '52.167.144.89', '1', '13:42:45', '2023-08-13', '2023-08-13 18:42:45', '2023-08-13 18:42:45'),
(421, '202.134.10.132', '7', '19:51:33', '2023-08-13', '2023-08-14 00:48:43', '2023-08-14 00:51:33'),
(422, '52.167.144.152', '1', '10:43:44', '2023-08-14', '2023-08-14 15:43:44', '2023-08-14 15:43:44'),
(423, '45.127.245.82', '10', '15:48:30', '2023-08-14', '2023-08-14 19:12:08', '2023-08-14 20:48:30'),
(424, '66.249.66.26', '1', '01:30:41', '2023-08-15', '2023-08-15 06:30:41', '2023-08-15 06:30:41'),
(425, '52.167.144.152', '2', '08:29:18', '2023-08-15', '2023-08-15 13:29:17', '2023-08-15 13:29:18'),
(426, '40.77.167.202', '2', '08:29:21', '2023-08-15', '2023-08-15 13:29:21', '2023-08-15 13:29:21'),
(427, '52.167.144.125', '1', '08:29:26', '2023-08-15', '2023-08-15 13:29:26', '2023-08-15 13:29:26'),
(428, '149.56.160.175', '8', '09:03:46', '2023-08-15', '2023-08-15 14:03:39', '2023-08-15 14:03:46'),
(429, '50.21.188.94', '5', '17:11:10', '2023-08-15', '2023-08-15 22:09:12', '2023-08-15 22:11:10'),
(430, '50.21.188.64', '4', '17:11:10', '2023-08-15', '2023-08-15 22:10:57', '2023-08-15 22:11:10'),
(431, '50.21.188.104', '4', '17:11:12', '2023-08-15', '2023-08-15 22:10:57', '2023-08-15 22:11:12'),
(432, '50.21.188.84', '2', '17:11:00', '2023-08-15', '2023-08-15 22:10:59', '2023-08-15 22:11:00'),
(433, '50.21.188.74', '3', '17:11:08', '2023-08-15', '2023-08-15 22:11:03', '2023-08-15 22:11:08'),
(434, '157.55.39.219', '1', '17:39:41', '2023-08-15', '2023-08-15 22:39:41', '2023-08-15 22:39:41'),
(435, '40.77.167.107', '1', '23:38:08', '2023-08-15', '2023-08-16 04:38:08', '2023-08-16 04:38:08'),
(436, '52.167.144.151', '1', '00:32:04', '2023-08-16', '2023-08-16 05:32:04', '2023-08-16 05:32:04'),
(437, '52.167.144.232', '3', '00:32:08', '2023-08-16', '2023-08-16 05:32:08', '2023-08-16 05:32:08'),
(438, '40.77.167.202', '2', '00:32:13', '2023-08-16', '2023-08-16 05:32:13', '2023-08-16 05:32:13'),
(439, '34.70.1.206', '17', '04:22:37', '2023-08-16', '2023-08-16 09:20:12', '2023-08-16 09:22:37'),
(440, '40.77.167.107', '1', '20:26:11', '2023-08-16', '2023-08-17 01:26:11', '2023-08-17 01:26:11'),
(441, '40.77.167.107', '1', '01:23:08', '2023-08-17', '2023-08-17 06:23:08', '2023-08-17 06:23:08'),
(442, '40.77.167.79', '1', '08:50:10', '2023-08-17', '2023-08-17 13:50:10', '2023-08-17 13:50:10'),
(443, '66.249.66.163', '1', '11:33:26', '2023-08-17', '2023-08-17 16:33:26', '2023-08-17 16:33:26'),
(444, '52.167.144.231', '1', '14:21:50', '2023-08-18', '2023-08-18 19:21:50', '2023-08-18 19:21:50'),
(445, '52.167.144.141', '1', '23:39:12', '2023-08-18', '2023-08-19 04:39:12', '2023-08-19 04:39:12'),
(446, '103.197.153.17', '11', '17:36:03', '2023-08-19', '2023-08-19 22:28:30', '2023-08-19 22:36:03'),
(447, '15.204.182.106', '1', '18:23:09', '2023-08-19', '2023-08-19 23:23:09', '2023-08-19 23:23:09'),
(448, '15.204.182.106', '1', '18:23:09', '2023-08-19', '2023-08-19 23:23:09', '2023-08-19 23:23:09'),
(449, '31.171.155.14', '2', '20:03:04', '2023-08-19', '2023-08-20 01:03:03', '2023-08-20 01:03:04'),
(450, '40.77.167.79', '1', '08:05:29', '2023-08-20', '2023-08-20 13:05:29', '2023-08-20 13:05:29'),
(451, '45.127.245.82', '11', '16:57:30', '2023-08-20', '2023-08-20 17:52:10', '2023-08-20 21:57:30'),
(452, '103.197.153.17', '17', '16:34:02', '2023-08-20', '2023-08-20 20:55:13', '2023-08-20 21:34:02'),
(453, '52.167.144.141', '1', '16:27:04', '2023-08-20', '2023-08-20 21:27:04', '2023-08-20 21:27:04'),
(454, '163.53.140.69', '2', '16:29:47', '2023-08-20', '2023-08-20 21:29:45', '2023-08-20 21:29:47'),
(455, '202.173.122.5', '2', '16:29:59', '2023-08-20', '2023-08-20 21:29:57', '2023-08-20 21:29:59'),
(456, '69.171.231.116', '1', '16:41:50', '2023-08-20', '2023-08-20 21:41:50', '2023-08-20 21:41:50'),
(457, '69.171.231.5', '1', '16:41:52', '2023-08-20', '2023-08-20 21:41:52', '2023-08-20 21:41:52'),
(458, '66.249.73.72', '1', '10:14:02', '2023-08-21', '2023-08-21 15:14:02', '2023-08-21 15:14:02'),
(459, '103.197.153.17', '4', '10:17:20', '2023-08-21', '2023-08-21 15:14:37', '2023-08-21 15:17:20'),
(460, '37.111.200.181', '1', '13:24:13', '2023-08-21', '2023-08-21 18:24:13', '2023-08-21 18:24:13'),
(461, '84.17.47.118', '3', '16:39:02', '2023-08-21', '2023-08-21 21:39:01', '2023-08-21 21:39:02'),
(462, '45.127.245.82', '4', '17:45:40', '2023-08-21', '2023-08-21 22:45:35', '2023-08-21 22:45:40'),
(463, '154.6.94.136', '40', '01:44:27', '2023-08-22', '2023-08-22 06:43:16', '2023-08-22 06:44:27'),
(464, '211.97.2.197', '3', '04:18:45', '2023-08-22', '2023-08-22 09:18:42', '2023-08-22 09:18:45'),
(465, '45.127.245.82', '9', '11:54:57', '2023-08-22', '2023-08-22 16:49:31', '2023-08-22 16:54:57'),
(466, '162.240.75.37', '2', '03:52:17', '2023-08-23', '2023-08-23 08:52:16', '2023-08-23 08:52:17'),
(467, '103.159.72.79', '5', '00:17:34', '2023-08-24', '2023-08-24 05:14:46', '2023-08-24 05:17:34'),
(468, '52.167.144.190', '2', '06:36:10', '2023-08-24', '2023-08-24 09:19:37', '2023-08-24 11:36:10'),
(469, '103.85.159.193', '9', '11:41:16', '2023-08-24', '2023-08-24 16:37:22', '2023-08-24 16:41:16'),
(470, '118.179.51.33', '1', '16:39:13', '2023-08-24', '2023-08-24 21:39:13', '2023-08-24 21:39:13'),
(471, '45.127.245.82', '1', '18:07:23', '2023-08-24', '2023-08-24 23:07:23', '2023-08-24 23:07:23'),
(472, '173.252.83.1', '1', '09:20:20', '2023-08-25', '2023-08-25 14:20:20', '2023-08-25 14:20:20'),
(473, '173.252.83.9', '1', '09:20:20', '2023-08-25', '2023-08-25 14:20:20', '2023-08-25 14:20:20'),
(474, '40.77.167.10', '1', '17:23:58', '2023-08-25', '2023-08-25 22:23:58', '2023-08-25 22:23:58'),
(475, '52.167.144.215', '1', '16:25:48', '2023-08-26', '2023-08-26 21:25:48', '2023-08-26 21:25:48'),
(476, '98.212.205.106', '2', '19:21:25', '2023-08-26', '2023-08-27 00:21:11', '2023-08-27 00:21:25'),
(477, '157.55.39.220', '1', '04:50:26', '2023-08-27', '2023-08-27 09:50:26', '2023-08-27 09:50:26'),
(478, '40.77.167.36', '1', '09:25:54', '2023-08-27', '2023-08-27 14:25:54', '2023-08-27 14:25:54'),
(479, '40.77.167.79', '1', '00:21:06', '2023-08-28', '2023-08-28 05:21:06', '2023-08-28 05:21:06'),
(480, '40.77.167.50', '2', '12:11:41', '2023-08-28', '2023-08-28 09:40:40', '2023-08-28 17:11:41'),
(481, '187.190.189.164', '1', '08:50:15', '2023-08-28', '2023-08-28 13:50:15', '2023-08-28 13:50:15'),
(482, '45.127.245.82', '3', '12:38:05', '2023-08-28', '2023-08-28 17:34:02', '2023-08-28 17:38:05'),
(483, '52.167.144.206', '1', '15:10:03', '2023-08-28', '2023-08-28 20:10:03', '2023-08-28 20:10:03'),
(484, '52.167.144.234', '1', '21:09:22', '2023-08-28', '2023-08-29 02:09:22', '2023-08-29 02:09:22'),
(485, '40.77.167.9', '1', '21:59:22', '2023-08-28', '2023-08-29 02:59:22', '2023-08-29 02:59:22'),
(486, '52.167.144.211', '2', '20:44:42', '2023-08-29', '2023-08-29 12:05:29', '2023-08-30 01:44:42'),
(487, '157.55.39.220', '1', '14:11:38', '2023-08-29', '2023-08-29 19:11:38', '2023-08-29 19:11:38'),
(488, '40.77.167.67', '1', '17:50:55', '2023-08-29', '2023-08-29 22:50:55', '2023-08-29 22:50:55'),
(489, '40.77.167.27', '1', '18:48:10', '2023-08-29', '2023-08-29 23:48:10', '2023-08-29 23:48:10'),
(490, '52.167.144.206', '1', '02:43:53', '2023-08-30', '2023-08-30 07:43:53', '2023-08-30 07:43:53'),
(491, '117.40.176.42', '2', '09:17:54', '2023-08-30', '2023-08-30 14:17:51', '2023-08-30 14:17:54'),
(492, '157.55.39.220', '1', '12:40:29', '2023-08-30', '2023-08-30 17:40:29', '2023-08-30 17:40:29'),
(493, '40.77.167.64', '1', '18:12:44', '2023-08-30', '2023-08-30 23:12:44', '2023-08-30 23:12:44'),
(494, '52.167.144.185', '1', '22:26:23', '2023-08-30', '2023-08-31 03:26:23', '2023-08-31 03:26:23'),
(495, '40.77.167.27', '1', '09:13:40', '2023-08-31', '2023-08-31 14:13:40', '2023-08-31 14:13:40'),
(496, '103.78.224.53', '2', '13:13:24', '2023-08-31', '2023-08-31 14:52:14', '2023-08-31 18:13:24'),
(497, '66.249.66.163', '1', '11:28:57', '2023-08-31', '2023-08-31 16:28:57', '2023-08-31 16:28:57'),
(498, '40.77.167.143', '1', '12:05:37', '2023-08-31', '2023-08-31 17:05:37', '2023-08-31 17:05:37'),
(499, '66.249.66.164', '1', '12:09:43', '2023-08-31', '2023-08-31 17:09:43', '2023-08-31 17:09:43'),
(500, '157.55.39.220', '1', '20:04:50', '2023-08-31', '2023-09-01 01:04:50', '2023-09-01 01:04:50'),
(501, '180.148.212.58', '6', '22:34:28', '2023-08-31', '2023-09-01 03:29:03', '2023-09-01 03:34:28'),
(502, '157.55.39.220', '1', '00:29:47', '2023-09-01', '2023-09-01 05:29:47', '2023-09-01 05:29:47'),
(503, '40.77.167.248', '1', '11:09:45', '2023-09-01', '2023-09-01 16:09:45', '2023-09-01 16:09:45'),
(504, '45.61.165.140', '2', '22:20:45', '2023-09-01', '2023-09-01 16:29:26', '2023-09-02 03:20:45');
INSERT INTO `trackers` (`id`, `ip`, `hits`, `visit_time`, `visit_date`, `created_at`, `updated_at`) VALUES
(505, '40.77.167.5', '1', '13:53:54', '2023-09-01', '2023-09-01 18:53:54', '2023-09-01 18:53:54'),
(506, '52.167.144.210', '1', '17:22:11', '2023-09-01', '2023-09-01 22:22:11', '2023-09-01 22:22:11'),
(507, '66.249.66.163', '2', '14:24:10', '2023-09-02', '2023-09-02 15:45:10', '2023-09-02 19:24:10'),
(508, '66.249.66.164', '2', '11:15:10', '2023-09-02', '2023-09-02 16:00:10', '2023-09-02 16:15:10'),
(509, '66.249.66.165', '1', '11:45:10', '2023-09-02', '2023-09-02 16:45:10', '2023-09-02 16:45:10'),
(510, '157.55.39.220', '1', '07:01:21', '2023-09-03', '2023-09-03 12:01:21', '2023-09-03 12:01:21'),
(511, '40.77.167.14', '1', '03:59:00', '2023-09-04', '2023-09-04 08:59:00', '2023-09-04 08:59:00'),
(512, '69.171.230.7', '1', '13:07:20', '2023-09-04', '2023-09-04 18:07:20', '2023-09-04 18:07:20'),
(513, '69.171.230.5', '1', '13:07:20', '2023-09-04', '2023-09-04 18:07:20', '2023-09-04 18:07:20'),
(514, '40.77.167.49', '1', '14:10:55', '2023-09-04', '2023-09-04 19:10:55', '2023-09-04 19:10:55'),
(515, '157.55.39.214', '1', '17:50:35', '2023-09-04', '2023-09-04 22:50:35', '2023-09-04 22:50:35'),
(516, '40.77.167.18', '1', '19:57:30', '2023-09-04', '2023-09-05 00:57:30', '2023-09-05 00:57:30'),
(517, '52.167.144.22', '1', '21:28:08', '2023-09-04', '2023-09-05 02:28:08', '2023-09-05 02:28:08'),
(518, '52.167.144.195', '1', '05:38:27', '2023-09-05', '2023-09-05 10:38:27', '2023-09-05 10:38:27'),
(519, '27.147.205.147', '8', '10:32:56', '2023-09-06', '2023-09-06 15:26:40', '2023-09-06 15:32:56'),
(520, '40.77.167.49', '1', '15:49:40', '2023-09-06', '2023-09-06 20:49:40', '2023-09-06 20:49:40'),
(521, '40.77.167.76', '1', '21:53:04', '2023-09-06', '2023-09-07 02:53:04', '2023-09-07 02:53:04'),
(522, '51.15.224.83', '16', '22:52:26', '2023-09-06', '2023-09-07 03:52:14', '2023-09-07 03:52:26'),
(523, '51.158.114.195', '1', '23:16:25', '2023-09-06', '2023-09-07 04:16:25', '2023-09-07 04:16:25'),
(524, '51.158.102.169', '1', '23:26:43', '2023-09-06', '2023-09-07 04:26:43', '2023-09-07 04:26:43'),
(525, '51.158.70.10', '1', '23:31:56', '2023-09-06', '2023-09-07 04:31:56', '2023-09-07 04:31:56'),
(526, '163.172.129.138', '1', '23:55:50', '2023-09-06', '2023-09-07 04:55:50', '2023-09-07 04:55:50'),
(527, '163.172.165.102', '1', '02:31:32', '2023-09-07', '2023-09-07 07:31:32', '2023-09-07 07:31:32'),
(528, '52.167.144.195', '1', '16:27:58', '2023-09-07', '2023-09-07 21:27:58', '2023-09-07 21:27:58'),
(529, '216.137.184.252', '3', '12:50:30', '2023-09-08', '2023-09-08 17:50:27', '2023-09-08 17:50:30'),
(530, '45.127.245.82', '3', '11:45:37', '2023-09-09', '2023-09-09 16:45:09', '2023-09-09 16:45:37'),
(531, '103.87.136.226', '5', '16:38:27', '2023-09-09', '2023-09-09 21:31:52', '2023-09-09 21:38:27'),
(532, '167.99.82.63', '1', '21:35:35', '2023-09-09', '2023-09-10 02:35:35', '2023-09-10 02:35:35'),
(533, '45.248.151.55', '2', '21:38:55', '2023-09-09', '2023-09-10 02:38:52', '2023-09-10 02:38:55'),
(534, '40.77.167.59', '1', '23:26:09', '2023-09-09', '2023-09-10 04:26:09', '2023-09-10 04:26:09'),
(535, '167.99.89.238', '1', '02:14:05', '2023-09-10', '2023-09-10 07:14:05', '2023-09-10 07:14:05'),
(536, '146.190.160.249', '1', '03:51:39', '2023-09-10', '2023-09-10 08:51:39', '2023-09-10 08:51:39'),
(537, '154.28.229.19', '12', '11:04:03', '2023-09-10', '2023-09-10 16:04:02', '2023-09-10 16:04:03'),
(538, '167.172.232.142', '1', '11:04:18', '2023-09-10', '2023-09-10 16:04:18', '2023-09-10 16:04:18'),
(539, '172.104.102.196', '1', '11:04:23', '2023-09-10', '2023-09-10 16:04:23', '2023-09-10 16:04:23'),
(540, '143.198.90.249', '1', '12:37:18', '2023-09-10', '2023-09-10 17:37:18', '2023-09-10 17:37:18'),
(541, '137.184.89.81', '1', '12:59:46', '2023-09-10', '2023-09-10 17:59:46', '2023-09-10 17:59:46'),
(542, '159.89.26.128', '1', '13:22:05', '2023-09-10', '2023-09-10 18:22:05', '2023-09-10 18:22:05'),
(543, '143.110.222.19', '1', '13:55:54', '2023-09-10', '2023-09-10 18:55:54', '2023-09-10 18:55:54'),
(544, '198.251.73.110', '3', '15:06:36', '2023-09-10', '2023-09-10 20:06:21', '2023-09-10 20:06:36'),
(545, '198.251.73.66', '3', '15:06:40', '2023-09-10', '2023-09-10 20:06:22', '2023-09-10 20:06:40'),
(546, '198.251.73.96', '2', '15:06:28', '2023-09-10', '2023-09-10 20:06:26', '2023-09-10 20:06:28'),
(547, '198.251.73.118', '3', '15:06:33', '2023-09-10', '2023-09-10 20:06:27', '2023-09-10 20:06:33'),
(548, '198.251.73.114', '1', '15:06:28', '2023-09-10', '2023-09-10 20:06:28', '2023-09-10 20:06:28'),
(549, '198.251.73.76', '3', '15:06:36', '2023-09-10', '2023-09-10 20:06:32', '2023-09-10 20:06:36'),
(550, '198.251.73.106', '1', '15:06:32', '2023-09-10', '2023-09-10 20:06:32', '2023-09-10 20:06:32'),
(551, '198.251.73.86', '2', '15:06:38', '2023-09-10', '2023-09-10 20:06:34', '2023-09-10 20:06:38'),
(552, '159.65.246.39', '1', '15:32:23', '2023-09-10', '2023-09-10 20:32:23', '2023-09-10 20:32:23'),
(553, '45.127.245.82', '17', '16:19:32', '2023-09-10', '2023-09-10 20:40:16', '2023-09-10 21:19:32'),
(554, '40.77.167.63', '1', '16:04:19', '2023-09-10', '2023-09-10 21:04:19', '2023-09-10 21:04:19'),
(555, '167.99.82.244', '1', '20:55:58', '2023-09-10', '2023-09-11 01:55:58', '2023-09-11 01:55:58'),
(556, '161.35.88.124', '1', '01:08:34', '2023-09-11', '2023-09-11 06:08:34', '2023-09-11 06:08:34'),
(557, '159.65.242.228', '1', '03:37:27', '2023-09-11', '2023-09-11 08:37:27', '2023-09-11 08:37:27'),
(558, '143.198.84.201', '1', '04:13:44', '2023-09-11', '2023-09-11 09:13:44', '2023-09-11 09:13:44'),
(559, '167.99.81.239', '1', '04:58:11', '2023-09-11', '2023-09-11 09:58:11', '2023-09-11 09:58:11'),
(560, '159.89.24.63', '1', '05:43:26', '2023-09-11', '2023-09-11 10:43:25', '2023-09-11 10:43:26'),
(561, '103.230.107.52', '3', '09:09:08', '2023-09-11', '2023-09-11 14:07:37', '2023-09-11 14:09:08'),
(562, '45.127.245.82', '5', '20:08:36', '2023-09-11', '2023-09-11 22:45:26', '2023-09-12 01:08:36'),
(563, '138.197.133.252', '1', '20:20:31', '2023-09-11', '2023-09-12 01:20:31', '2023-09-12 01:20:31'),
(564, '164.92.81.219', '1', '22:16:19', '2023-09-11', '2023-09-12 03:16:19', '2023-09-12 03:16:19'),
(565, '159.89.31.242', '1', '03:44:23', '2023-09-12', '2023-09-12 08:44:23', '2023-09-12 08:44:23'),
(566, '40.77.167.29', '1', '09:30:16', '2023-09-12', '2023-09-12 14:30:16', '2023-09-12 14:30:16'),
(567, '52.167.144.123', '1', '10:19:09', '2023-09-12', '2023-09-12 15:19:09', '2023-09-12 15:19:09'),
(568, '103.240.249.62', '3', '10:24:04', '2023-09-12', '2023-09-12 15:21:45', '2023-09-12 15:24:04'),
(569, '137.184.39.236', '1', '11:48:38', '2023-09-12', '2023-09-12 16:48:38', '2023-09-12 16:48:38'),
(570, '103.96.104.51', '9', '12:19:32', '2023-09-12', '2023-09-12 16:58:21', '2023-09-12 17:19:32'),
(571, '40.77.167.10', '1', '12:57:03', '2023-09-12', '2023-09-12 17:57:03', '2023-09-12 17:57:03'),
(572, '173.252.83.1', '1', '18:08:16', '2023-09-12', '2023-09-12 23:08:16', '2023-09-12 23:08:16'),
(573, '143.198.86.204', '1', '18:33:35', '2023-09-12', '2023-09-12 23:33:35', '2023-09-12 23:33:35'),
(574, '167.99.94.183', '1', '06:35:07', '2023-09-13', '2023-09-13 11:35:07', '2023-09-13 11:35:07'),
(575, '138.197.137.22', '1', '07:21:30', '2023-09-13', '2023-09-13 12:21:30', '2023-09-13 12:21:30'),
(576, '167.99.81.223', '1', '09:43:31', '2023-09-13', '2023-09-13 14:43:31', '2023-09-13 14:43:31'),
(577, '66.249.69.103', '1', '09:45:36', '2023-09-13', '2023-09-13 14:45:36', '2023-09-13 14:45:36'),
(578, '45.127.245.82', '31', '17:50:52', '2023-09-13', '2023-09-13 16:43:31', '2023-09-13 22:50:52'),
(579, '40.77.167.151', '1', '11:46:08', '2023-09-13', '2023-09-13 16:46:08', '2023-09-13 16:46:08'),
(580, '52.167.144.25', '1', '12:16:41', '2023-09-13', '2023-09-13 17:16:41', '2023-09-13 17:16:41'),
(581, '167.71.172.84', '1', '13:20:38', '2023-09-13', '2023-09-13 18:20:38', '2023-09-13 18:20:38'),
(582, '167.71.164.63', '1', '17:07:58', '2023-09-13', '2023-09-13 22:07:58', '2023-09-13 22:07:58'),
(583, '52.167.144.186', '1', '23:36:35', '2023-09-13', '2023-09-14 04:36:35', '2023-09-14 04:36:35'),
(584, '167.71.164.52', '1', '00:11:24', '2023-09-14', '2023-09-14 05:11:24', '2023-09-14 05:11:24'),
(585, '146.190.134.222', '1', '01:46:58', '2023-09-14', '2023-09-14 06:46:58', '2023-09-14 06:46:58'),
(586, '138.197.18.72', '1', '05:45:01', '2023-09-14', '2023-09-14 10:45:01', '2023-09-14 10:45:01'),
(587, '71.34.96.63', '1', '10:08:18', '2023-09-14', '2023-09-14 15:08:18', '2023-09-14 15:08:18'),
(588, '103.87.251.26', '5', '11:47:31', '2023-09-14', '2023-09-14 16:44:53', '2023-09-14 16:47:31'),
(589, '103.15.42.71', '1', '11:45:29', '2023-09-14', '2023-09-14 16:45:29', '2023-09-14 16:45:29'),
(590, '167.71.164.68', '1', '14:35:11', '2023-09-14', '2023-09-14 19:35:11', '2023-09-14 19:35:11'),
(591, '66.249.66.163', '1', '15:33:56', '2023-09-14', '2023-09-14 20:33:56', '2023-09-14 20:33:56'),
(592, '66.249.66.164', '1', '15:36:56', '2023-09-14', '2023-09-14 20:36:56', '2023-09-14 20:36:56'),
(593, '45.127.245.82', '92', '18:54:46', '2023-09-14', '2023-09-14 21:55:59', '2023-09-14 23:54:46'),
(594, '159.65.250.146', '1', '17:31:40', '2023-09-14', '2023-09-14 22:31:40', '2023-09-14 22:31:40'),
(595, '143.198.84.63', '1', '19:11:21', '2023-09-14', '2023-09-15 00:11:21', '2023-09-15 00:11:21'),
(596, '146.190.229.143', '1', '22:44:12', '2023-09-14', '2023-09-15 03:44:12', '2023-09-15 03:44:12'),
(597, '167.99.89.238', '1', '01:21:19', '2023-09-15', '2023-09-15 06:21:19', '2023-09-15 06:21:19'),
(598, '54.190.14.19', '3', '04:16:15', '2023-09-15', '2023-09-15 09:16:15', '2023-09-15 09:16:15'),
(599, '159.65.246.39', '1', '04:35:17', '2023-09-15', '2023-09-15 09:35:17', '2023-09-15 09:35:17'),
(600, '66.249.66.163', '3', '11:01:24', '2023-09-15', '2023-09-15 10:19:22', '2023-09-15 16:01:24'),
(601, '66.249.66.165', '2', '11:17:29', '2023-09-15', '2023-09-15 10:49:22', '2023-09-15 16:17:29'),
(602, '66.249.66.164', '3', '10:49:22', '2023-09-15', '2023-09-15 11:19:22', '2023-09-15 15:49:22'),
(603, '149.56.160.176', '8', '09:14:15', '2023-09-15', '2023-09-15 14:14:08', '2023-09-15 14:14:15'),
(604, '146.190.134.166', '1', '09:45:18', '2023-09-15', '2023-09-15 14:45:18', '2023-09-15 14:45:18'),
(605, '146.190.237.227', '1', '11:05:58', '2023-09-15', '2023-09-15 16:05:58', '2023-09-15 16:05:58'),
(606, '143.110.210.121', '1', '11:16:56', '2023-09-15', '2023-09-15 16:16:56', '2023-09-15 16:16:56'),
(607, '52.167.144.152', '1', '14:52:06', '2023-09-15', '2023-09-15 19:52:06', '2023-09-15 19:52:06'),
(608, '167.99.81.223', '1', '23:38:59', '2023-09-15', '2023-09-16 04:38:59', '2023-09-16 04:38:59'),
(609, '143.198.92.198', '1', '02:51:47', '2023-09-16', '2023-09-16 07:51:47', '2023-09-16 07:51:47'),
(610, '167.71.164.249', '1', '05:26:46', '2023-09-16', '2023-09-16 10:26:46', '2023-09-16 10:26:46'),
(611, '149.34.245.98', '3', '06:01:59', '2023-09-16', '2023-09-16 11:01:58', '2023-09-16 11:01:59'),
(612, '76.250.171.196', '2', '06:11:49', '2023-09-16', '2023-09-16 11:11:48', '2023-09-16 11:11:49'),
(613, '52.167.144.186', '1', '08:27:02', '2023-09-16', '2023-09-16 13:27:02', '2023-09-16 13:27:02'),
(614, '66.249.66.165', '1', '10:12:24', '2023-09-16', '2023-09-16 15:12:24', '2023-09-16 15:12:24'),
(615, '45.127.245.82', '29', '19:13:14', '2023-09-16', '2023-09-16 16:52:41', '2023-09-17 00:13:14'),
(616, '138.199.31.107', '2', '11:59:00', '2023-09-16', '2023-09-16 16:58:59', '2023-09-16 16:59:00'),
(617, '167.99.86.208', '1', '14:02:05', '2023-09-16', '2023-09-16 19:02:05', '2023-09-16 19:02:05'),
(618, '167.99.89.15', '1', '15:05:13', '2023-09-16', '2023-09-16 20:05:13', '2023-09-16 20:05:13'),
(619, '138.197.18.45', '1', '17:48:13', '2023-09-16', '2023-09-16 22:48:13', '2023-09-16 22:48:13'),
(620, '138.197.28.155', '1', '22:09:33', '2023-09-16', '2023-09-17 03:09:33', '2023-09-17 03:09:33'),
(621, '66.249.66.164', '1', '22:23:48', '2023-09-16', '2023-09-17 03:23:48', '2023-09-17 03:23:48'),
(622, '46.101.101.138', '1', '22:42:17', '2023-09-16', '2023-09-17 03:42:17', '2023-09-17 03:42:17'),
(623, '24.199.117.100', '1', '23:05:39', '2023-09-16', '2023-09-17 04:05:39', '2023-09-17 04:05:39'),
(624, '159.65.246.5', '1', '05:05:51', '2023-09-17', '2023-09-17 10:05:51', '2023-09-17 10:05:51'),
(625, '128.199.73.196', '1', '10:14:20', '2023-09-17', '2023-09-17 15:14:20', '2023-09-17 15:14:20'),
(626, '45.127.245.82', '126', '19:23:00', '2023-09-17', '2023-09-17 17:58:17', '2023-09-18 00:23:00'),
(627, '66.249.66.163', '1', '14:40:50', '2023-09-17', '2023-09-17 19:40:50', '2023-09-17 19:40:50'),
(628, '52.167.144.182', '1', '15:05:37', '2023-09-17', '2023-09-17 20:05:37', '2023-09-17 20:05:37'),
(629, '185.190.42.200', '4', '15:20:44', '2023-09-17', '2023-09-17 20:20:42', '2023-09-17 20:20:44'),
(630, '103.197.153.17', '15', '16:28:55', '2023-09-17', '2023-09-17 21:00:33', '2023-09-17 21:28:55'),
(631, '52.167.144.196', '1', '00:17:39', '2023-09-18', '2023-09-18 05:17:39', '2023-09-18 05:17:39'),
(632, '165.232.82.30', '1', '03:10:05', '2023-09-18', '2023-09-18 08:10:05', '2023-09-18 08:10:05'),
(633, '143.198.84.201', '1', '04:12:44', '2023-09-18', '2023-09-18 09:12:43', '2023-09-18 09:12:44'),
(634, '178.254.12.205', '1', '04:59:03', '2023-09-18', '2023-09-18 09:59:03', '2023-09-18 09:59:03'),
(635, '24.199.109.135', '1', '06:55:41', '2023-09-18', '2023-09-18 11:55:41', '2023-09-18 11:55:41'),
(636, '159.89.26.128', '1', '07:42:04', '2023-09-18', '2023-09-18 12:42:04', '2023-09-18 12:42:04'),
(637, '45.127.245.82', '11', '17:13:53', '2023-09-18', '2023-09-18 22:12:41', '2023-09-18 22:13:53'),
(638, '167.99.90.164', '1', '21:06:24', '2023-09-18', '2023-09-19 02:06:24', '2023-09-19 02:06:24'),
(639, '103.159.72.79', '6', '22:23:09', '2023-09-18', '2023-09-19 03:22:05', '2023-09-19 03:23:09'),
(640, '159.65.246.39', '1', '01:23:41', '2023-09-19', '2023-09-19 06:23:41', '2023-09-19 06:23:41'),
(641, '137.184.114.243', '1', '02:31:50', '2023-09-19', '2023-09-19 07:31:50', '2023-09-19 07:31:50'),
(642, '66.249.66.164', '1', '06:27:17', '2023-09-19', '2023-09-19 11:27:17', '2023-09-19 11:27:17'),
(643, '146.190.229.85', '1', '07:23:46', '2023-09-19', '2023-09-19 12:23:46', '2023-09-19 12:23:46'),
(644, '161.35.84.101', '1', '07:54:38', '2023-09-19', '2023-09-19 12:54:38', '2023-09-19 12:54:38'),
(645, '40.77.167.30', '3', '09:28:40', '2023-09-19', '2023-09-19 14:28:39', '2023-09-19 14:28:40'),
(646, '52.167.144.197', '2', '09:28:43', '2023-09-19', '2023-09-19 14:28:43', '2023-09-19 14:28:43'),
(647, '66.249.66.165', '1', '10:27:17', '2023-09-19', '2023-09-19 15:27:17', '2023-09-19 15:27:17'),
(648, '66.249.66.163', '1', '11:27:17', '2023-09-19', '2023-09-19 16:27:17', '2023-09-19 16:27:17'),
(649, '146.190.134.130', '1', '12:37:53', '2023-09-19', '2023-09-19 17:37:53', '2023-09-19 17:37:53'),
(650, '45.127.245.82', '32', '17:02:04', '2023-09-19', '2023-09-19 17:47:57', '2023-09-19 22:02:04'),
(651, '103.197.153.17', '3', '12:54:35', '2023-09-19', '2023-09-19 17:52:24', '2023-09-19 17:54:35'),
(652, '146.190.170.190', '1', '13:35:47', '2023-09-19', '2023-09-19 18:35:47', '2023-09-19 18:35:47'),
(653, '167.99.81.53', '1', '14:48:55', '2023-09-19', '2023-09-19 19:48:55', '2023-09-19 19:48:55'),
(654, '159.65.242.228', '1', '21:31:53', '2023-09-19', '2023-09-20 02:31:53', '2023-09-20 02:31:53'),
(655, '146.190.229.143', '1', '01:26:34', '2023-09-20', '2023-09-20 06:26:34', '2023-09-20 06:26:34'),
(656, '138.197.133.223', '1', '04:46:56', '2023-09-20', '2023-09-20 09:46:56', '2023-09-20 09:46:56'),
(657, '52.167.144.171', '1', '06:49:33', '2023-09-20', '2023-09-20 11:49:33', '2023-09-20 11:49:33'),
(658, '138.197.141.31', '1', '13:22:38', '2023-09-20', '2023-09-20 18:22:38', '2023-09-20 18:22:38'),
(659, '52.167.144.218', '1', '16:19:55', '2023-09-20', '2023-09-20 21:19:55', '2023-09-20 21:19:55'),
(660, '45.127.245.82', '2', '18:24:57', '2023-09-20', '2023-09-20 23:24:46', '2023-09-20 23:24:57'),
(661, '157.55.39.201', '1', '21:24:28', '2023-09-20', '2023-09-21 02:24:28', '2023-09-21 02:24:28'),
(662, '103.158.62.238', '3', '23:59:03', '2023-09-20', '2023-09-21 04:56:27', '2023-09-21 04:59:03'),
(663, '137.184.89.81', '1', '00:19:28', '2023-09-21', '2023-09-21 05:19:28', '2023-09-21 05:19:28'),
(664, '159.89.31.242', '1', '06:15:32', '2023-09-21', '2023-09-21 11:15:32', '2023-09-21 11:15:32'),
(665, '165.232.82.30', '1', '08:36:39', '2023-09-21', '2023-09-21 13:36:39', '2023-09-21 13:36:39'),
(666, '40.77.167.3', '1', '08:45:47', '2023-09-21', '2023-09-21 13:45:47', '2023-09-21 13:45:47'),
(667, '143.198.82.78', '1', '13:52:34', '2023-09-21', '2023-09-21 18:52:34', '2023-09-21 18:52:34'),
(668, '167.99.86.208', '1', '16:20:54', '2023-09-21', '2023-09-21 21:20:54', '2023-09-21 21:20:54'),
(669, '103.158.62.238', '1', '17:15:38', '2023-09-21', '2023-09-21 22:15:38', '2023-09-21 22:15:38'),
(670, '159.65.246.5', '1', '20:42:54', '2023-09-21', '2023-09-22 01:42:54', '2023-09-22 01:42:54'),
(671, '138.197.137.0', '1', '21:12:05', '2023-09-21', '2023-09-22 02:12:05', '2023-09-22 02:12:05'),
(672, '167.99.81.223', '1', '22:34:21', '2023-09-21', '2023-09-22 03:34:21', '2023-09-22 03:34:21'),
(673, '167.71.164.249', '1', '00:11:34', '2023-09-22', '2023-09-22 05:11:34', '2023-09-22 05:11:34'),
(674, '40.77.167.2', '1', '00:45:24', '2023-09-22', '2023-09-22 05:45:24', '2023-09-22 05:45:24'),
(675, '24.199.109.135', '1', '03:38:05', '2023-09-22', '2023-09-22 08:38:05', '2023-09-22 08:38:05'),
(676, '84.17.60.181', '2', '09:07:30', '2023-09-22', '2023-09-22 14:07:29', '2023-09-22 14:07:30'),
(677, '40.77.167.57', '1', '09:25:02', '2023-09-22', '2023-09-22 14:25:02', '2023-09-22 14:25:02'),
(678, '143.198.82.78', '1', '14:17:36', '2023-09-22', '2023-09-22 19:17:36', '2023-09-22 19:17:36'),
(679, '24.199.117.100', '1', '16:39:23', '2023-09-22', '2023-09-22 21:39:23', '2023-09-22 21:39:23'),
(680, '138.197.28.155', '1', '21:15:40', '2023-09-22', '2023-09-23 02:15:40', '2023-09-23 02:15:40'),
(681, '5.38.109.162', '1', '21:21:57', '2023-09-22', '2023-09-23 02:21:57', '2023-09-23 02:21:57'),
(682, '40.77.167.61', '1', '02:41:25', '2023-09-23', '2023-09-23 07:41:25', '2023-09-23 07:41:25'),
(683, '173.252.83.1', '1', '10:22:41', '2023-09-23', '2023-09-23 15:22:41', '2023-09-23 15:22:41'),
(684, '173.252.83.4', '1', '10:22:41', '2023-09-23', '2023-09-23 15:22:41', '2023-09-23 15:22:41'),
(685, '45.127.245.82', '17', '16:56:39', '2023-09-23', '2023-09-23 21:26:09', '2023-09-23 21:56:39'),
(686, '198.251.73.30', '4', '19:08:48', '2023-09-23', '2023-09-24 00:08:32', '2023-09-24 00:08:48'),
(687, '198.251.73.14', '6', '19:08:52', '2023-09-23', '2023-09-24 00:08:34', '2023-09-24 00:08:52'),
(688, '198.251.73.54', '6', '19:08:54', '2023-09-23', '2023-09-24 00:08:35', '2023-09-24 00:08:54'),
(689, '198.251.73.41', '2', '19:08:49', '2023-09-23', '2023-09-24 00:08:39', '2023-09-24 00:08:49'),
(690, '198.251.73.46', '2', '19:08:51', '2023-09-23', '2023-09-24 00:08:40', '2023-09-24 00:08:51'),
(691, '198.251.73.22', '3', '19:08:56', '2023-09-23', '2023-09-24 00:08:50', '2023-09-24 00:08:56'),
(692, '198.251.73.38', '1', '19:08:52', '2023-09-23', '2023-09-24 00:08:52', '2023-09-24 00:08:52'),
(693, '198.251.73.6', '2', '19:08:56', '2023-09-23', '2023-09-24 00:08:54', '2023-09-24 00:08:56'),
(694, '40.77.167.243', '1', '21:09:56', '2023-09-23', '2023-09-24 02:09:56', '2023-09-24 02:09:56'),
(695, '103.96.104.215', '1', '22:22:29', '2023-09-23', '2023-09-24 03:22:29', '2023-09-24 03:22:29'),
(696, '115.127.93.218', '2', '12:40:44', '2023-09-24', '2023-09-24 17:39:29', '2023-09-24 17:40:44'),
(697, '52.167.144.192', '1', '14:40:05', '2023-09-24', '2023-09-24 19:40:05', '2023-09-24 19:40:05'),
(698, '45.127.245.82', '5', '16:12:04', '2023-09-24', '2023-09-24 21:09:15', '2023-09-24 21:12:04'),
(699, '37.111.218.79', '9', '17:27:23', '2023-09-24', '2023-09-24 22:20:13', '2023-09-24 22:27:23'),
(700, '103.96.104.215', '1', '23:39:28', '2023-09-24', '2023-09-25 04:39:28', '2023-09-25 04:39:28'),
(701, '45.127.245.82', '5', '14:06:02', '2023-09-25', '2023-09-25 19:03:58', '2023-09-25 19:06:02'),
(702, '46.101.9.216', '5', '06:18:34', '2023-09-26', '2023-09-26 11:18:30', '2023-09-26 11:18:34'),
(703, '20.15.133.185', '1', '10:39:09', '2023-09-26', '2023-09-26 15:39:09', '2023-09-26 15:39:09'),
(704, '40.77.167.8', '1', '10:45:19', '2023-09-26', '2023-09-26 15:45:19', '2023-09-26 15:45:19'),
(705, '40.77.167.230', '1', '12:03:31', '2023-09-26', '2023-09-26 17:03:31', '2023-09-26 17:03:31'),
(706, '104.28.120.1', '3', '14:46:55', '2023-09-26', '2023-09-26 19:46:34', '2023-09-26 19:46:55'),
(707, '54.224.13.214', '1', '16:13:39', '2023-09-26', '2023-09-26 21:13:39', '2023-09-26 21:13:39'),
(708, '40.77.167.255', '1', '17:26:42', '2023-09-26', '2023-09-26 22:26:42', '2023-09-26 22:26:42'),
(709, '103.197.153.17', '14', '18:46:16', '2023-09-26', '2023-09-26 23:22:52', '2023-09-26 23:46:16'),
(710, '40.77.167.73', '1', '04:19:54', '2023-09-27', '2023-09-27 09:19:54', '2023-09-27 09:19:54'),
(711, '181.214.218.183', '2', '18:53:11', '2023-09-27', '2023-09-27 23:53:10', '2023-09-27 23:53:11'),
(712, '52.167.144.186', '1', '19:21:15', '2023-09-27', '2023-09-28 00:21:15', '2023-09-28 00:21:15'),
(713, '40.77.167.48', '1', '02:59:19', '2023-09-28', '2023-09-28 07:59:19', '2023-09-28 07:59:19'),
(714, '82.80.249.249', '24', '09:38:25', '2023-09-28', '2023-09-28 14:38:06', '2023-09-28 14:38:25'),
(715, '27.147.205.147', '4', '11:23:20', '2023-09-28', '2023-09-28 16:22:37', '2023-09-28 16:23:20'),
(716, '40.77.167.65', '1', '11:39:19', '2023-09-28', '2023-09-28 16:39:19', '2023-09-28 16:39:19'),
(717, '40.77.167.1', '1', '23:01:52', '2023-09-28', '2023-09-29 04:01:52', '2023-09-29 04:01:52'),
(718, '98.113.240.110', '1', '12:55:18', '2023-09-29', '2023-09-29 17:55:18', '2023-09-29 17:55:18'),
(719, '52.167.144.216', '1', '17:46:27', '2023-09-29', '2023-09-29 22:46:27', '2023-09-29 22:46:27'),
(720, '178.168.115.145', '3', '18:26:46', '2023-09-29', '2023-09-29 23:26:39', '2023-09-29 23:26:46'),
(721, '52.167.144.190', '1', '20:13:19', '2023-09-29', '2023-09-30 01:13:19', '2023-09-30 01:13:19'),
(722, '52.167.144.24', '1', '04:22:43', '2023-09-30', '2023-09-30 09:22:43', '2023-09-30 09:22:43'),
(723, '52.167.144.205', '1', '08:08:26', '2023-09-30', '2023-09-30 13:08:26', '2023-09-30 13:08:26'),
(724, '52.167.144.139', '1', '10:56:38', '2023-09-30', '2023-09-30 15:56:38', '2023-09-30 15:56:38'),
(725, '52.167.144.203', '1', '09:02:28', '2023-10-01', '2023-10-01 14:02:28', '2023-10-01 14:02:28'),
(726, '52.167.144.180', '1', '10:59:04', '2023-10-01', '2023-10-01 15:59:04', '2023-10-01 15:59:04'),
(727, '122.144.12.107', '1', '14:52:30', '2023-10-01', '2023-10-01 19:52:30', '2023-10-01 19:52:30'),
(728, '15.204.182.106', '1', '20:25:19', '2023-10-01', '2023-10-02 01:25:19', '2023-10-02 01:25:19'),
(729, '15.204.182.106', '1', '20:25:19', '2023-10-01', '2023-10-02 01:25:19', '2023-10-02 01:25:19'),
(730, '15.204.206.70', '2', '03:09:47', '2023-10-02', '2023-10-02 08:08:57', '2023-10-02 08:09:47'),
(731, '45.127.245.82', '6', '20:49:27', '2023-10-02', '2023-10-02 19:28:47', '2023-10-03 01:49:27'),
(732, '40.77.167.61', '1', '14:48:25', '2023-10-02', '2023-10-02 19:48:25', '2023-10-02 19:48:25'),
(733, '103.20.141.6', '1', '16:55:31', '2023-10-02', '2023-10-02 21:55:31', '2023-10-02 21:55:31'),
(734, '103.197.153.17', '13', '17:29:37', '2023-10-02', '2023-10-02 21:56:02', '2023-10-02 22:29:37'),
(735, '103.15.42.196', '2', '16:58:04', '2023-10-02', '2023-10-02 21:58:02', '2023-10-02 21:58:04'),
(736, '40.77.167.28', '1', '20:37:49', '2023-10-02', '2023-10-03 01:37:49', '2023-10-03 01:37:49'),
(737, '66.249.66.170', '1', '20:38:18', '2023-10-02', '2023-10-03 01:38:18', '2023-10-03 01:38:18'),
(738, '66.249.66.168', '1', '21:07:36', '2023-10-02', '2023-10-03 02:07:36', '2023-10-03 02:07:36'),
(739, '154.201.44.215', '1', '00:28:20', '2023-10-03', '2023-10-03 05:28:20', '2023-10-03 05:28:20'),
(740, '154.84.137.48', '1', '00:28:22', '2023-10-03', '2023-10-03 05:28:22', '2023-10-03 05:28:22'),
(741, '52.167.144.222', '1', '09:43:23', '2023-10-03', '2023-10-03 14:43:23', '2023-10-03 14:43:23'),
(742, '45.127.245.82', '9', '19:12:37', '2023-10-03', '2023-10-03 22:02:03', '2023-10-04 00:12:37'),
(743, '52.167.144.209', '1', '18:11:33', '2023-10-03', '2023-10-03 23:11:33', '2023-10-03 23:11:33'),
(744, '103.197.153.17', '4', '18:16:01', '2023-10-03', '2023-10-03 23:15:26', '2023-10-03 23:16:01'),
(745, '2a06:98c0:3600::103', '2', '22:08:03', '2023-10-03', '2023-10-04 00:11:15', '2023-10-04 03:08:03'),
(746, '66.249.66.170', '1', '20:38:49', '2023-10-03', '2023-10-04 01:38:49', '2023-10-04 01:38:49'),
(747, '52.167.144.22', '1', '22:20:23', '2023-10-03', '2023-10-04 03:20:23', '2023-10-04 03:20:23'),
(748, '103.143.243.9', '7', '02:43:07', '2023-10-04', '2023-10-04 07:36:48', '2023-10-04 07:43:07'),
(749, '38.7.165.15', '5', '06:22:33', '2023-10-04', '2023-10-04 11:22:32', '2023-10-04 11:22:33'),
(750, '38.7.165.15', '1', '06:22:32', '2023-10-04', '2023-10-04 11:22:32', '2023-10-04 11:22:32'),
(751, '52.167.144.137', '1', '15:16:37', '2023-10-04', '2023-10-04 20:16:37', '2023-10-04 20:16:37'),
(752, '45.127.245.82', '6', '18:50:09', '2023-10-04', '2023-10-04 23:11:54', '2023-10-04 23:50:09'),
(753, '157.55.39.54', '1', '20:21:39', '2023-10-04', '2023-10-05 01:21:39', '2023-10-05 01:21:39'),
(754, '52.167.144.204', '1', '02:39:29', '2023-10-05', '2023-10-05 07:39:29', '2023-10-05 07:39:29'),
(755, '66.249.66.168', '2', '08:41:16', '2023-10-05', '2023-10-05 10:25:47', '2023-10-05 13:41:16'),
(756, '45.127.245.82', '4', '11:39:11', '2023-10-05', '2023-10-05 16:38:58', '2023-10-05 16:39:11'),
(757, '40.77.167.25', '1', '17:17:24', '2023-10-05', '2023-10-05 22:17:24', '2023-10-05 22:17:24'),
(758, '178.18.44.42', '3', '21:09:18', '2023-10-05', '2023-10-06 02:09:17', '2023-10-06 02:09:18'),
(759, '178.254.12.205', '1', '23:13:13', '2023-10-05', '2023-10-06 04:13:13', '2023-10-06 04:13:13'),
(760, '34.79.244.205', '95', '03:34:30', '2023-10-06', '2023-10-06 08:31:06', '2023-10-06 08:34:30'),
(761, '34.79.244.205', '1', '03:31:06', '2023-10-06', '2023-10-06 08:31:06', '2023-10-06 08:31:06'),
(762, '52.167.144.209', '1', '09:57:13', '2023-10-06', '2023-10-06 14:57:13', '2023-10-06 14:57:13'),
(763, '120.82.174.128', '3', '10:38:59', '2023-10-06', '2023-10-06 15:38:56', '2023-10-06 15:38:59'),
(764, '178.254.12.205', '1', '11:42:20', '2023-10-06', '2023-10-06 16:42:20', '2023-10-06 16:42:20'),
(765, '45.127.245.82', '13', '16:39:47', '2023-10-06', '2023-10-06 21:22:10', '2023-10-06 21:39:47'),
(766, '103.55.146.215', '1', '02:04:47', '2023-10-07', '2023-10-07 07:04:47', '2023-10-07 07:04:47'),
(767, '120.82.174.128', '3', '04:24:35', '2023-10-07', '2023-10-07 09:24:30', '2023-10-07 09:24:35'),
(768, '207.46.13.128', '1', '06:19:09', '2023-10-07', '2023-10-07 11:19:09', '2023-10-07 11:19:09'),
(769, '40.77.167.27', '1', '07:21:43', '2023-10-07', '2023-10-07 12:21:43', '2023-10-07 12:21:43'),
(770, '66.249.66.168', '1', '10:49:48', '2023-10-07', '2023-10-07 15:49:48', '2023-10-07 15:49:48'),
(771, '66.249.66.169', '2', '15:26:38', '2023-10-07', '2023-10-07 15:50:13', '2023-10-07 20:26:38'),
(772, '45.127.245.82', '10', '18:31:39', '2023-10-07', '2023-10-07 18:09:58', '2023-10-07 23:31:39'),
(773, '66.249.66.170', '1', '14:56:16', '2023-10-07', '2023-10-07 19:56:16', '2023-10-07 19:56:16'),
(774, '52.167.144.218', '1', '17:34:14', '2023-10-07', '2023-10-07 22:34:14', '2023-10-07 22:34:14'),
(775, '69.171.230.1', '1', '19:31:48', '2023-10-07', '2023-10-08 00:31:48', '2023-10-08 00:31:48'),
(776, '69.171.230.118', '1', '19:31:48', '2023-10-07', '2023-10-08 00:31:48', '2023-10-08 00:31:48'),
(777, '3.22.194.220', '3', '00:13:07', '2023-10-08', '2023-10-08 05:13:04', '2023-10-08 05:13:07'),
(778, '173.252.87.11', '1', '03:09:32', '2023-10-08', '2023-10-08 08:09:32', '2023-10-08 08:09:32'),
(779, '173.252.87.9', '1', '03:09:32', '2023-10-08', '2023-10-08 08:09:32', '2023-10-08 08:09:32'),
(780, '45.127.245.82', '4', '12:21:18', '2023-10-08', '2023-10-08 17:19:47', '2023-10-08 17:21:18'),
(781, '66.249.66.170', '1', '14:58:40', '2023-10-08', '2023-10-08 19:58:40', '2023-10-08 19:58:40'),
(782, '207.46.13.116', '1', '16:19:07', '2023-10-08', '2023-10-08 21:19:07', '2023-10-08 21:19:07'),
(783, '52.167.144.175', '1', '18:57:17', '2023-10-08', '2023-10-08 23:57:17', '2023-10-08 23:57:17'),
(784, '207.46.13.92', '1', '21:32:20', '2023-10-08', '2023-10-09 02:32:20', '2023-10-09 02:32:20'),
(785, '52.167.144.22', '1', '04:39:31', '2023-10-09', '2023-10-09 09:39:31', '2023-10-09 09:39:31'),
(786, '52.167.144.136', '1', '07:35:47', '2023-10-09', '2023-10-09 12:35:47', '2023-10-09 12:35:47'),
(787, '103.197.153.17', '26', '15:13:03', '2023-10-09', '2023-10-09 16:49:48', '2023-10-09 20:13:03'),
(788, '114.31.31.69', '2', '11:50:56', '2023-10-09', '2023-10-09 16:50:53', '2023-10-09 16:50:56'),
(789, '157.55.39.62', '1', '12:43:17', '2023-10-09', '2023-10-09 17:43:17', '2023-10-09 17:43:17'),
(790, '66.249.66.170', '1', '14:58:45', '2023-10-09', '2023-10-09 19:58:45', '2023-10-09 19:58:45'),
(791, '45.127.245.82', '4', '16:50:19', '2023-10-09', '2023-10-09 21:49:42', '2023-10-09 21:50:19'),
(792, '52.167.144.203', '1', '23:28:22', '2023-10-09', '2023-10-10 04:28:22', '2023-10-10 04:28:22'),
(793, '40.77.167.15', '1', '04:53:05', '2023-10-10', '2023-10-10 09:53:05', '2023-10-10 09:53:05'),
(794, '45.127.245.82', '1', '11:30:22', '2023-10-10', '2023-10-10 16:30:22', '2023-10-10 16:30:22'),
(795, '66.249.66.170', '1', '14:57:24', '2023-10-10', '2023-10-10 19:57:24', '2023-10-10 19:57:24'),
(796, '191.101.209.134', '3', '16:31:54', '2023-10-10', '2023-10-10 21:31:53', '2023-10-10 21:31:54'),
(797, '207.46.13.116', '1', '19:45:29', '2023-10-10', '2023-10-11 00:45:29', '2023-10-11 00:45:29'),
(798, '52.167.144.163', '1', '02:53:27', '2023-10-11', '2023-10-11 07:53:27', '2023-10-11 07:53:27'),
(799, '52.167.144.210', '1', '05:05:08', '2023-10-11', '2023-10-11 10:05:08', '2023-10-11 10:05:08'),
(800, '52.167.144.20', '1', '11:02:21', '2023-10-11', '2023-10-11 16:02:21', '2023-10-11 16:02:21'),
(801, '66.249.66.170', '1', '14:28:09', '2023-10-11', '2023-10-11 19:28:09', '2023-10-11 19:28:09'),
(802, '45.127.245.82', '15', '21:20:21', '2023-10-11', '2023-10-11 22:34:44', '2023-10-12 02:20:21'),
(803, '160.202.147.5', '1', '21:18:03', '2023-10-11', '2023-10-12 02:18:03', '2023-10-12 02:18:03'),
(804, '157.55.39.201', '1', '21:53:21', '2023-10-11', '2023-10-12 02:53:21', '2023-10-12 02:53:21'),
(805, '207.46.13.141', '1', '03:09:30', '2023-10-12', '2023-10-12 08:09:30', '2023-10-12 08:09:30'),
(806, '52.167.144.186', '1', '04:33:56', '2023-10-12', '2023-10-12 09:33:56', '2023-10-12 09:33:56'),
(807, '37.111.219.206', '3', '13:57:30', '2023-10-12', '2023-10-12 18:55:32', '2023-10-12 18:57:30'),
(808, '66.249.66.168', '1', '14:28:05', '2023-10-12', '2023-10-12 19:28:05', '2023-10-12 19:28:05'),
(809, '207.46.13.6', '1', '16:57:22', '2023-10-12', '2023-10-12 21:57:22', '2023-10-12 21:57:22'),
(810, '207.46.13.127', '1', '17:04:46', '2023-10-12', '2023-10-12 22:04:46', '2023-10-12 22:04:46'),
(811, '154.83.9.26', '1', '01:43:17', '2023-10-13', '2023-10-13 06:43:17', '2023-10-13 06:43:17'),
(812, '166.88.244.215', '1', '01:43:18', '2023-10-13', '2023-10-13 06:43:18', '2023-10-13 06:43:18'),
(813, '157.55.39.15', '1', '04:54:55', '2023-10-13', '2023-10-13 09:54:55', '2023-10-13 09:54:55'),
(814, '207.46.13.154', '1', '06:56:04', '2023-10-13', '2023-10-13 11:56:04', '2023-10-13 11:56:04'),
(815, '66.249.66.168', '1', '14:28:53', '2023-10-13', '2023-10-13 19:28:53', '2023-10-13 19:28:53'),
(816, '207.46.13.155', '1', '14:56:47', '2023-10-13', '2023-10-13 19:56:47', '2023-10-13 19:56:47'),
(817, '157.55.39.205', '1', '20:49:42', '2023-10-13', '2023-10-14 01:49:42', '2023-10-14 01:49:42'),
(818, '157.55.39.9', '1', '01:11:05', '2023-10-14', '2023-10-14 06:11:05', '2023-10-14 06:11:05'),
(819, '66.249.66.168', '1', '08:58:48', '2023-10-14', '2023-10-14 13:58:48', '2023-10-14 13:58:48'),
(820, '157.55.39.50', '1', '09:57:43', '2023-10-14', '2023-10-14 14:57:43', '2023-10-14 14:57:43'),
(821, '66.249.66.169', '2', '14:28:15', '2023-10-14', '2023-10-14 18:24:53', '2023-10-14 19:28:15'),
(822, '157.55.39.13', '1', '17:42:32', '2023-10-14', '2023-10-14 22:42:32', '2023-10-14 22:42:32'),
(823, '157.55.39.205', '1', '23:30:28', '2023-10-14', '2023-10-15 04:30:28', '2023-10-15 04:30:28'),
(824, '40.77.167.16', '1', '01:28:04', '2023-10-15', '2023-10-15 06:28:04', '2023-10-15 06:28:04'),
(825, '144.217.135.186', '8', '09:53:36', '2023-10-15', '2023-10-15 14:53:29', '2023-10-15 14:53:36'),
(826, '207.46.13.116', '1', '17:56:15', '2023-10-15', '2023-10-15 22:56:15', '2023-10-15 22:56:15'),
(827, '207.46.13.111', '1', '23:18:55', '2023-10-15', '2023-10-16 04:18:55', '2023-10-16 04:18:55'),
(828, '159.255.188.134', '2', '07:41:57', '2023-10-16', '2023-10-16 12:41:56', '2023-10-16 12:41:57'),
(829, '207.46.13.127', '1', '08:47:59', '2023-10-16', '2023-10-16 13:47:59', '2023-10-16 13:47:59'),
(830, '40.77.167.52', '1', '09:28:13', '2023-10-16', '2023-10-16 14:28:13', '2023-10-16 14:28:13'),
(831, '52.167.144.210', '1', '15:55:04', '2023-10-16', '2023-10-16 20:55:04', '2023-10-16 20:55:04'),
(832, '52.167.144.23', '1', '21:18:02', '2023-10-16', '2023-10-17 02:18:02', '2023-10-17 02:18:02'),
(833, '202.134.9.145', '5', '22:14:09', '2023-10-16', '2023-10-17 03:07:06', '2023-10-17 03:14:09'),
(834, '40.77.167.32', '1', '23:32:20', '2023-10-16', '2023-10-17 04:32:20', '2023-10-17 04:32:20'),
(835, '157.55.39.51', '1', '13:07:43', '2023-10-17', '2023-10-17 18:07:43', '2023-10-17 18:07:43'),
(836, '157.55.39.61', '1', '18:00:01', '2023-10-17', '2023-10-17 23:00:01', '2023-10-17 23:00:01'),
(837, '52.167.144.214', '1', '03:54:32', '2023-10-18', '2023-10-18 08:54:32', '2023-10-18 08:54:32'),
(838, '52.167.144.205', '1', '04:32:32', '2023-10-18', '2023-10-18 09:32:32', '2023-10-18 09:32:32'),
(839, '40.77.167.50', '1', '07:50:23', '2023-10-18', '2023-10-18 12:50:23', '2023-10-18 12:50:23'),
(840, '40.77.167.5', '1', '08:38:58', '2023-10-18', '2023-10-18 13:38:58', '2023-10-18 13:38:58'),
(841, '52.167.144.145', '1', '08:56:49', '2023-10-18', '2023-10-18 13:56:49', '2023-10-18 13:56:49'),
(842, '40.77.167.230', '1', '03:30:03', '2023-10-19', '2023-10-19 08:30:03', '2023-10-19 08:30:03'),
(843, '40.77.167.235', '1', '15:22:51', '2023-10-19', '2023-10-19 20:22:51', '2023-10-19 20:22:51'),
(844, '207.46.13.141', '1', '21:51:21', '2023-10-19', '2023-10-20 02:51:21', '2023-10-20 02:51:21'),
(845, '207.46.13.155', '1', '22:37:45', '2023-10-19', '2023-10-20 03:37:45', '2023-10-20 03:37:45'),
(846, '52.167.144.232', '1', '02:28:41', '2023-10-20', '2023-10-20 07:28:41', '2023-10-20 07:28:41'),
(847, '52.167.144.170', '1', '06:13:06', '2023-10-20', '2023-10-20 11:13:06', '2023-10-20 11:13:06'),
(848, '74.208.2.235', '6', '07:08:35', '2023-10-20', '2023-10-20 12:08:15', '2023-10-20 12:08:35'),
(849, '74.208.2.237', '4', '07:08:32', '2023-10-20', '2023-10-20 12:08:15', '2023-10-20 12:08:32'),
(850, '74.208.2.236', '3', '07:08:21', '2023-10-20', '2023-10-20 12:08:15', '2023-10-20 12:08:21'),
(851, '74.208.2.239', '7', '07:08:32', '2023-10-20', '2023-10-20 12:08:15', '2023-10-20 12:08:32'),
(852, '74.208.2.238', '6', '07:08:34', '2023-10-20', '2023-10-20 12:08:18', '2023-10-20 12:08:34'),
(853, '69.171.230.8', '1', '17:41:10', '2023-10-20', '2023-10-20 22:41:10', '2023-10-20 22:41:10'),
(854, '40.77.167.19', '2', '23:12:03', '2023-10-20', '2023-10-21 00:19:42', '2023-10-21 04:12:03'),
(855, '52.167.144.161', '1', '03:03:39', '2023-10-21', '2023-10-21 08:03:39', '2023-10-21 08:03:39'),
(856, '195.181.161.24', '2', '11:43:35', '2023-10-21', '2023-10-21 16:43:35', '2023-10-21 16:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'openhouse@gmail.com', NULL, '$2y$10$fyZSONniJE4GeBnzWsZ7eOOE22UdWqenMjLyZz2GFnVnbXW0ctuC6', 'F0omKnUOA3uPq3ICzz9dk6An4KAybe6jHYSkDjKkDNikDp1YP0Nw1rzb8pqv', '2023-04-25 23:35:33', '2023-04-26 03:18:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_principals`
--
ALTER TABLE `about_principals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_queries`
--
ALTER TABLE `client_queries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_images`
--
ALTER TABLE `project_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_headings`
--
ALTER TABLE `team_headings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trackers`
--
ALTER TABLE `trackers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_principals`
--
ALTER TABLE `about_principals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `client_queries`
--
ALTER TABLE `client_queries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `project_images`
--
ALTER TABLE `project_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `team_headings`
--
ALTER TABLE `team_headings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trackers`
--
ALTER TABLE `trackers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=857;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
